"""Create isolated local accounts and sample tournament records."""
import json
from werkzeug.security import generate_password_hash
from app import app,init_db,getdb

ROLES=['Administrator','Tournament Organizer','Team Captain','Scorekeeper','Player','Viewer']
def seed_demo():
    with app.app_context():
        init_db(); c=getdb()
        for i,role in enumerate(ROLES):
            email=f'{role.lower().replace(" ",".")}@arena.local'; pw='ArenaDemo2026!'
            c.execute('INSERT OR IGNORE INTO users(email,password_hash,name,roles,is_demo) VALUES(?,?,?,?,1)',(email,generate_password_hash(pw),f'Demo {role}',json.dumps([role])))
            u=c.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone()['id']
            c.execute('INSERT OR IGNORE INTO players(user_id,player_code,game) VALUES(?,?,?)',(u,f'DEMO-P{i+1}','Valorant'))
        captain=c.execute("SELECT id FROM users WHERE email='team.captain@arena.local'").fetchone()['id']
        c.execute("INSERT OR IGNORE INTO teams(team_code,name,captain_id,game,roster_limit) VALUES('DEMO-T1','Demo Sentinels',?,'Valorant',5)",(captain,))
        organizer=c.execute("SELECT id FROM users WHERE email='tournament.organizer@arena.local'").fetchone()['id']
        c.execute("INSERT OR IGNORE INTO tournaments(owner_id,name,game,format,game_type,max_teams,invite_code) VALUES(?, 'Demo Cup','Valorant','round_robin','head_to_head',8,'DEMO-CUP-2026')",(organizer,))
        c.commit()

if __name__=='__main__':
    seed_demo()
    print('Demo seed ready. All roles use password ArenaDemo2026!.')
