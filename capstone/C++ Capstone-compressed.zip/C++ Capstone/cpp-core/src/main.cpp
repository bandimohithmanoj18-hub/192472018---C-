#include "arena.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace arena;for(int n:{4,5,8}){std::vector<int> ids;for(int i=1;i<=n;++i)ids.push_back(i);assert((int)RoundRobinScheduler::schedule(ids).size()==n*(n-1)/2);}BattleRoyaleScoring br({15,12,10,8},2);assert(br.score({1,12,4,2,true})==20);HeadToHeadScoring h;assert(h.score({1,1,0,0,true})==3);auto ranked=Leaderboard::rank({{1,0,0,0,true},{2,1,0,0,true}},h);assert(ranked.front().teamId==2);assert(RankingService::points(h,{1,2,0,0,false})==0);assert(ChampionService::champion(ranked,h)==2);assert(KnockoutScheduler::firstRound({1,2,3}).size()==1);std::cout<<"C++ core checks passed\n";}
