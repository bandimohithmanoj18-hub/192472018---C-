#pragma once
#include <algorithm>
#include <cmath>
#include <fstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
namespace arena {
struct Player { int id; std::string name; Player(int i,std::string n):id(i),name(std::move(n)){if(id<1||name.empty())throw std::invalid_argument("invalid player");} };
struct Team { int id; std::string name; std::vector<Player> roster; Team(int i,std::string n):id(i),name(std::move(n)){if(id<1||name.empty())throw std::invalid_argument("invalid team");} void add(const Player&p){if(std::any_of(roster.begin(),roster.end(),[&](auto&x){return x.id==p.id;}))throw std::invalid_argument("duplicate player");roster.push_back(p);} };
struct Match { int id,round,teamA,teamB; Match(int i,int r,int a,int b):id(i),round(r),teamA(a),teamB(b){if(a<0||b<0||a==b)throw std::invalid_argument("invalid pairing");} };
struct MatchResult { int teamId,score,eliminations,placement; bool verified=false; };
struct Tournament { std::string name,format; std::vector<Team> teams; Tournament(std::string n,std::string f):name(std::move(n)),format(std::move(f)){} };
class ScoringStrategy { public: virtual ~ScoringStrategy()=default; virtual int score(const MatchResult&)const=0; };
class BattleRoyaleScoring final:public ScoringStrategy { std::vector<int> points_;int elimination_;public:BattleRoyaleScoring(std::vector<int>p,int e):points_(std::move(p)),elimination_(e){if(e<0)throw std::invalid_argument("negative elim value");}int score(const MatchResult&r)const override{if(r.placement<1||static_cast<size_t>(r.placement)>points_.size()||r.eliminations<0)throw std::invalid_argument("invalid result");return points_[r.placement-1]+r.eliminations*elimination_;}};
class HeadToHeadScoring final:public ScoringStrategy {int win_,draw_,loss_;public:HeadToHeadScoring(int w=3,int d=1,int l=0):win_(w),draw_(d),loss_(l){}int score(const MatchResult&r)const override{return r.score>0?win_:r.score==0?draw_:loss_;}};
class RoundRobinScheduler {public:static std::vector<Match> schedule(const std::vector<int>&ids){std::vector<Match> out;int id=1;for(size_t i=0;i<ids.size();++i)for(size_t j=i+1;j<ids.size();++j)out.emplace_back(id++,1,ids[i],ids[j]);return out;}};
class KnockoutScheduler {public:static std::vector<Match> firstRound(const std::vector<int>&ids){std::vector<Match> out;int id=1;for(size_t i=0;i<ids.size();i+=2)if(i+1<ids.size())out.emplace_back(id++,1,ids[i],ids[i+1]);return out;}};
class Leaderboard {public:static std::vector<MatchResult> rank(std::vector<MatchResult> rows,const ScoringStrategy&s){std::sort(rows.begin(),rows.end(),[&](auto&a,auto&b){return s.score(a)>s.score(b);});return rows;}};
class RankingService {public:static int points(const ScoringStrategy&s,const MatchResult&r){if(!r.verified)return 0;return s.score(r);}};
class ChampionService {public:static int champion(const std::vector<MatchResult>&rows,const ScoringStrategy&s){int id=-1,best=-1;for(const auto&r:rows)if(r.verified&&s.score(r)>best){id=r.teamId;best=s.score(r);}if(id<0)throw std::runtime_error("no verified winner");return id;}};
inline void saveSchedule(const std::vector<Match>&m,const std::string&path){std::ofstream f(path);if(!f)throw std::runtime_error("cannot open schedule file");for(auto&x:m)f<<x.id<<','<<x.round<<','<<x.teamA<<','<<x.teamB<<'\n';}
}
