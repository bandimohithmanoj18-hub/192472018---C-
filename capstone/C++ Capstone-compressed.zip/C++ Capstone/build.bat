@echo off
echo ======================================
echo   ESPORTS ARENA - Build Script
echo ======================================
echo.

REM Check if LLVM-MinGW exists in WinGet packages
if exist "%LOCALAPPDATA%\Microsoft\WinGet\Packages\MartinStorsjo.LLVM-MinGW.UCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\llvm-mingw-20261020-ucrt-x86_64\bin\clang++.exe" (
    set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Packages\MartinStorsjo.LLVM-MinGW.UCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\llvm-mingw-20261020-ucrt-x86_64\bin;%PATH%"
)

REM Try to find clang++ in PATH or common locations
where clang++ >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set CXX=clang++
    set CC=clang
) else (
    where g++ >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        set CXX=g++
        set CC=gcc
    ) else (
        echo ERROR: No C++ compiler found. Install LLVM MinGW or MinGW-w64.
        echo   winget install MartinStorsjo.LLVM-MinGW.UCRT
        exit /b 1
    )
)

echo Using compiler: %CXX%
echo.

REM Step 1: Compile SQLite3 as C
echo [1/3] Compiling SQLite3 (C)...
%CC% -c -O1 -DSQLITE_THREADSAFE=1 -DSQLITE_ENABLE_JSON1 backend\include\third_party\sqlite3.c -o backend\sqlite3.o
if %ERRORLEVEL% NEQ 0 (
    echo FAILED to compile sqlite3.c
    exit /b 1
)
echo       OK

REM Step 2: Compile and link C++ backend
echo [2/3] Compiling C++ backend...
%CXX% -std=c++17 -O1 -DSQLITE_THREADSAFE=1 -DSQLITE_ENABLE_JSON1 ^
    -Ibackend/include -Ibackend/include/third_party ^
    backend\src\DatabaseService.cpp ^
    backend\src\AuthenticationService.cpp ^
    backend\src\PlayerService.cpp ^
    backend\src\TeamService.cpp ^
    backend\src\TournamentService.cpp ^
    backend\src\MatchService.cpp ^
    backend\src\ScoreService.cpp ^
    backend\src\LeaderboardService.cpp ^
    backend\src\NotificationService.cpp ^
    backend\src\DisputeService.cpp ^
    backend\main.cpp ^
    backend\sqlite3.o ^
    -o backend\esports_server.exe ^
    -lws2_32 -lpthread
if %ERRORLEVEL% NEQ 0 (
    echo FAILED to compile backend
    exit /b 1
)
echo       OK

REM Step 3: Create database directory
echo [3/3] Creating database directory...
if not exist "database" mkdir database
echo       OK

echo.
echo ======================================
echo   BUILD SUCCESSFUL!
echo ======================================
echo.
echo Run the server:
echo   backend\esports_server.exe
echo.
echo Then open: http://localhost:8080
echo.
echo Demo credentials:
echo   Admin:   admin / Admin@123
echo   Captain: shahzam / Captain@123
echo   Player:  tenz / Player@123
echo.
