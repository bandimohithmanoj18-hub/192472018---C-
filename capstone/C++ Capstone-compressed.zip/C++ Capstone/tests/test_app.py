import pytest
import app as arena

@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(arena,'DB',tmp_path/'test.sqlite3')
    arena.app.config.update(TESTING=True,SECRET_KEY='test')
    with arena.app.app_context(): arena.init_db()
    return arena.app.test_client()

def register(client,email='captain@test.local',name='Captain'):
    return client.post('/api/register',json={'email':email,'password':'LongPass123!','name':name,'game':'Valorant'})

def test_registration_duplicate_and_login(client):
    assert register(client).status_code==200
    assert register(client).status_code==409
    client.post('/api/logout')
    assert client.post('/api/login',json={'email':'captain@test.local','password':'bad'}).status_code==401
    assert client.post('/api/login',json={'email':'captain@test.local','password':'LongPass123!'}).status_code==200

def test_team_roster_and_duplicate(client):
    register(client)
    r=client.post('/api/teams',json={'name':'Test Squad','game':'Valorant'}); assert r.status_code==201
    with arena.app.app_context(): pid=arena.getdb().execute('SELECT id FROM players').fetchone()[0]
    assert client.post(f"/api/teams/{r.json['id']}/members",json={'player_id':pid}).status_code==409

def test_round_robin_counts():
    assert len(arena.round_robin([1,2,3,4]))==6
    assert len(arena.round_robin([1,2,3,4,5]))==10
    assert len(arena.round_robin(list(range(8))))==28

def test_access_and_settings(client):
    assert client.get('/api/dashboard').status_code==401
    register(client); assert client.post('/api/settings',json={'theme':'light'}).status_code==200
    assert client.get('/api/settings').json['theme']=='light'
