import json
import tempfile
import unittest
from pathlib import Path
import app as arena

class CoreWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        arena.DB=Path(self.temp.name)/'arena.sqlite3'
        arena.app.config.update(TESTING=True,SECRET_KEY='test')
        with arena.app.app_context(): arena.init_db()
        self.client=arena.app.test_client()

    def tearDown(self): self.temp.cleanup()

    def signup(self,email,name,role):
        r=self.client.post('/api/register',json={'email':email,'name':name,'password':'StrongPass123!','game':'Valorant'})
        self.assertEqual(r.status_code,200)
        with arena.app.app_context(): arena.getdb().execute('UPDATE users SET roles=? WHERE email=?',(json.dumps([role]),email)); arena.getdb().commit()

    def test_tournament_to_verified_champion(self):
        self.signup('org@demo.test','Organizer','Administrator')
        org=self.client
        team_ids=[]
        for n in (1,2):
            self.client.post('/api/logout')
            email=f'captain{n}@demo.test'
            self.signup(email,f'Captain {n}','Team Captain')
            r=self.client.post('/api/teams',json={'name':f'Team {n}','game':'Valorant'})
            self.assertEqual(r.status_code,201); team_ids.append(r.json['id'])
        self.client.post('/api/logout'); self.assertEqual(self.client.post('/api/login',json={'email':'org@demo.test','password':'StrongPass123!'}).status_code,200)
        t=self.client.post('/api/tournaments',json={'name':'Workflow Cup','game':'Valorant','format':'round_robin','game_type':'head_to_head','max_teams':4})
        self.assertEqual(t.status_code,201); tid=t.json['id']
        for team in team_ids:
            self.assertEqual(self.client.post(f"/api/tournament-invites/{t.json['invite_code']}/register",json={'team_id':team}).status_code,201)
            self.assertEqual(self.client.post(f'/api/registrations/{tid}/{team}/review',json={'status':'approved'}).status_code,200)
        self.assertEqual(self.client.post(f'/api/tournaments/{tid}/schedule',json={}).json['match_count'],1)
        match=self.client.get('/api/matches').json['matches'][0]
        result=self.client.post(f"/api/matches/{match['id']}/results",json={'results':[{'team_id':team_ids[0],'score':2},{'team_id':team_ids[1],'score':1}]})
        self.assertEqual(result.status_code,200)
        self.assertEqual(self.client.get(f'/api/tournaments/{tid}/leaderboard').json['standings'],[])
        self.assertEqual(self.client.post(f"/api/matches/{match['id']}/verify",json={}).status_code,200)
        standings=self.client.get(f'/api/tournaments/{tid}/leaderboard').json['standings']
        self.assertEqual(standings[0]['team'],'Team 1'); self.assertEqual(standings[0]['points'],3)
        self.assertEqual(self.client.post(f'/api/tournaments/{tid}/champion',json={}).json['champion'],'Team 1')

    def test_round_robin_reference_counts(self):
        for n,count in ((4,6),(5,10),(8,28)):
            self.assertEqual(len(arena.round_robin(list(range(n)))),count)

    def test_responsive_pages_favicon_and_contact_links(self):
        self.assertEqual(self.client.get('/missing-route').status_code,404)
        self.assertIn(b'Page not found',self.client.get('/missing-route').data)
        self.assertEqual(self.client.get('/help').status_code,200)
        icon=self.client.get('/assets/images/favicon.svg'); self.assertEqual(icon.status_code,200); icon.close()
        css_response=self.client.get('/assets/css/arena-polish.css'); css=css_response.get_data(as_text=True); css_response.close()
        self.assertIn('mobile-toggle',css); self.assertIn('overflow-x:clip',css)
        self.assertEqual(self.client.post('/api/register',json={'email':'with-phone@test.local','password':'StrongPass123!','name':'Phone User','phone':'+15551234567'}).status_code,200)
        page=self.client.get('/').get_data(as_text=True)
        self.assertIn('href="mailto:with-phone@test.local"',page)
        self.assertIn('href="tel:+15551234567"',page)

if __name__=='__main__': unittest.main()
