# ============================================================
# ESPORTS ARENA — Instant Public HTTPS Deployment
# Uses Cloudflare Tunnel for Free Automatic SSL
# ============================================================

$ErrorActionPreference = "Stop"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   ESPORTS ARENA - Instant Public HTTPS Deployment Tool     " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Verify C++ backend is running on port 8080
Write-Host "[1/3] Checking C++ backend server on http://localhost:8080..." -ForegroundColor Yellow
try {
    $test = Invoke-WebRequest -Uri "http://localhost:8080/api/tournaments" -Method Get -UseBasicParsing -TimeoutSec 3
    Write-Host "      Server is ACTIVE and responding on port 8080!" -ForegroundColor Green
} catch {
    Write-Host "      Server not running. Starting backend\esports_server.exe..." -ForegroundColor Yellow
    Start-Process -FilePath "backend\esports_server.exe" -ArgumentList "8080"
    Start-Sleep -Seconds 2
}

# 2. Check or download cloudflared standalone binary
$toolsDir = Join-Path $PSScriptRoot "tools"
if (!(Test-Path $toolsDir)) { New-Item -ItemType Directory -Path $toolsDir | Out-Null }
$cloudflared = Join-Path $toolsDir "cloudflared.exe"

if (!(Test-Path $cloudflared)) {
    Write-Host "[2/3] Downloading cloudflared tunneling client..." -ForegroundColor Yellow
    $url = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
    Invoke-WebRequest -Uri $url -OutFile $cloudflared -UseBasicParsing
    Write-Host "      cloudflared downloaded successfully!" -ForegroundColor Green
} else {
    Write-Host "[2/3] cloudflared is ready." -ForegroundColor Green
}

# 3. Launch the public tunnel
Write-Host ""
Write-Host "[3/3] Creating secure public HTTPS tunnel to port 8080..." -ForegroundColor Yellow
Write-Host "      Generating your free public URL (e.g., https://*.trycloudflare.com)..." -ForegroundColor Cyan
Write-Host "      Press Ctrl+C to stop sharing when done." -ForegroundColor DarkGray
Write-Host ""

& $cloudflared tunnel --url http://localhost:8080
