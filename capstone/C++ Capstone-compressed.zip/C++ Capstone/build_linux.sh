#!/usr/bin/env bash
# ============================================================
# ESPORTS ARENA — Linux Build & Run Script
# ============================================================

set -e

echo "=== Building Esports Arena for Linux ==="

# Check for compiler
if command -v g++ >/dev/null 2>&1; then
    CXX=g++
    CC=gcc
elif command -v clang++ >/dev/null 2>&1; then
    CXX=clang++
    CC=clang
else
    echo "Error: Neither g++ nor clang++ found. Please install build-essential."
    echo "  Ubuntu/Debian: sudo apt update && sudo apt install -y build-essential"
    exit 1
fi

echo "Using compiler: $CXX"

mkdir -p database
cd backend
make -f Makefile.linux clean
make -f Makefile.linux CXX=$CXX CC=$CC

echo "=== Build Complete! ==="
echo "To start the server, run: ./backend/esports_server 8080"
