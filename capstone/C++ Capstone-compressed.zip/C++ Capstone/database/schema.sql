-- ============================================================================
-- Esports Tournament Management System - Database Schema (SQLite & MySQL)
-- ============================================================================

-- 1. Users Table (Base authentication & role-based credentials)
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK(role IN ('admin', 'captain', 'player')),
    full_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(25),
    country VARCHAR(50) DEFAULT 'India',
    avatar_url VARCHAR(255) DEFAULT '/assets/images/default-avatar.svg',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Players Table (Profile extensions for individual players)
CREATE TABLE IF NOT EXISTS players (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    game_id VARCHAR(50) NOT NULL,
    selected_game VARCHAR(50) NOT NULL,
    player_role VARCHAR(50) DEFAULT 'Rifler / Assaulter',
    team_id INTEGER DEFAULT NULL,
    matches_played INTEGER DEFAULT 0,
    matches_won INTEGER DEFAULT 0,
    matches_lost INTEGER DEFAULT 0,
    mvp_awards INTEGER DEFAULT 0,
    rating REAL DEFAULT 1200.0,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL
);

-- 3. Teams Table
CREATE TABLE IF NOT EXISTS teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_code VARCHAR(16) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL UNIQUE,
    logo_url VARCHAR(255) DEFAULT '/assets/images/default-team.svg',
    captain_id INTEGER NOT NULL,
    game_category VARCHAR(50) NOT NULL,
    description TEXT,
    invitation_code VARCHAR(12) NOT NULL UNIQUE,
    max_players INTEGER DEFAULT 5,
    contact_email VARCHAR(100),
    contact_phone VARCHAR(25),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (captain_id) REFERENCES users(id)
);

-- 4. Team Members (Junction table linking players to teams)
CREATE TABLE IF NOT EXISTS team_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    team_id INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    role_in_team VARCHAR(50) DEFAULT 'Starter',
    joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(team_id, player_id),
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
    FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
);

-- 5. Tournaments Table
CREATE TABLE IF NOT EXISTS tournaments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(150) NOT NULL,
    game_category VARCHAR(50) NOT NULL,
    description TEXT,
    format VARCHAR(50) NOT NULL CHECK(format IN ('Single Elimination', 'Double Elimination', 'Round Robin', 'Group Stage + Knockout')),
    status VARCHAR(30) NOT NULL DEFAULT 'Upcoming' CHECK(status IN ('Upcoming', 'Registration Open', 'Ongoing', 'Completed')),
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    registration_deadline DATETIME NOT NULL,
    max_teams INTEGER NOT NULL DEFAULT 8,
    prize_pool REAL NOT NULL DEFAULT 0.0,
    banner_url VARCHAR(255) DEFAULT '/assets/images/default-banner.svg',
    rules TEXT,
    winner_team_id INTEGER DEFAULT NULL,
    runner_up_team_id INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (winner_team_id) REFERENCES teams(id),
    FOREIGN KEY (runner_up_team_id) REFERENCES teams(id)
);

-- 6. Tournament Registrations (Team registration with admin approval workflow)
CREATE TABLE IF NOT EXISTS tournament_registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER NOT NULL,
    team_id INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'Approved', 'Rejected')),
    registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    reviewed_by INTEGER DEFAULT NULL,
    review_notes TEXT,
    reviewed_at DATETIME DEFAULT NULL,
    UNIQUE(tournament_id, team_id),
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id)
);

-- 7. Matches Table
CREATE TABLE IF NOT EXISTS matches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER NOT NULL,
    round_number INTEGER NOT NULL DEFAULT 1,
    match_number INTEGER NOT NULL DEFAULT 1,
    bracket_type VARCHAR(30) DEFAULT 'Winners', -- 'Winners', 'Losers', 'Group', 'Finals'
    team_a_id INTEGER DEFAULT NULL,
    team_b_id INTEGER DEFAULT NULL,
    team_a_score INTEGER DEFAULT 0,
    team_b_score INTEGER DEFAULT 0,
    scheduled_time DATETIME NOT NULL,
    slot_info VARCHAR(100) DEFAULT 'Main Stage Arena 1',
    status VARCHAR(30) NOT NULL DEFAULT 'Upcoming' CHECK(status IN ('Upcoming', 'Live', 'Under Review', 'Completed')),
    winner_team_id INTEGER DEFAULT NULL,
    mvp_player_id INTEGER DEFAULT NULL,
    submitted_by INTEGER DEFAULT NULL,
    submission_notes TEXT,
    is_verified INTEGER NOT NULL DEFAULT 0,
    verified_by INTEGER DEFAULT NULL,
    next_match_id INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (team_a_id) REFERENCES teams(id),
    FOREIGN KEY (team_b_id) REFERENCES teams(id),
    FOREIGN KEY (winner_team_id) REFERENCES teams(id),
    FOREIGN KEY (mvp_player_id) REFERENCES players(id),
    FOREIGN KEY (submitted_by) REFERENCES users(id),
    FOREIGN KEY (verified_by) REFERENCES users(id)
);

-- 8. Match Results & Timeline Events
CREATE TABLE IF NOT EXISTS match_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    map_name VARCHAR(100),
    round_details TEXT,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    evidence_screenshot VARCHAR(255),
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
);

-- 9. Leaderboards Table (Points & statistics calculated by C++ ranking engine)
CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER DEFAULT NULL,
    team_id INTEGER NOT NULL,
    game_category VARCHAR(50) NOT NULL,
    matches_played INTEGER DEFAULT 0,
    wins INTEGER DEFAULT 0,
    losses INTEGER DEFAULT 0,
    draws INTEGER DEFAULT 0,
    points INTEGER DEFAULT 0,
    total_score INTEGER DEFAULT 0,
    score_against INTEGER DEFAULT 0,
    win_percentage REAL DEFAULT 0.0,
    recent_form VARCHAR(20) DEFAULT '-----',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE
);

-- 10. Disputes Table (For fair play & cheating/result complaints)
CREATE TABLE IF NOT EXISTS disputes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    match_id INTEGER NOT NULL,
    raised_by INTEGER NOT NULL,
    team_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    evidence_url VARCHAR(255),
    status VARCHAR(20) NOT NULL DEFAULT 'Open' CHECK(status IN ('Open', 'Under Review', 'Resolved', 'Dismissed')),
    admin_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME DEFAULT NULL,
    resolved_by INTEGER DEFAULT NULL,
    FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
    FOREIGN KEY (raised_by) REFERENCES users(id),
    FOREIGN KEY (team_id) REFERENCES teams(id),
    FOREIGN KEY (resolved_by) REFERENCES users(id)
);

-- 11. Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(30) DEFAULT 'general',
    is_read INTEGER DEFAULT 0,
    link_url VARCHAR(255) DEFAULT '#',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 12. Activity Logs Table (Audit trail for actions)
CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action VARCHAR(100) NOT NULL,
    details TEXT,
    ip_address VARCHAR(50) DEFAULT '127.0.0.1',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- 13. Prizes Table
CREATE TABLE IF NOT EXISTS prizes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tournament_id INTEGER NOT NULL,
    place INTEGER NOT NULL CHECK(place IN (1, 2, 3)),
    reward_title VARCHAR(100) NOT NULL,
    reward_amount REAL NOT NULL,
    team_id INTEGER DEFAULT NULL,
    FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
    FOREIGN KEY (team_id) REFERENCES teams(id)
);

-- Indices for rapid query performance
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_teams_game ON teams(game_category);
CREATE INDEX IF NOT EXISTS idx_matches_tourn ON matches(tournament_id);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_tourn_status ON tournaments(status);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);

