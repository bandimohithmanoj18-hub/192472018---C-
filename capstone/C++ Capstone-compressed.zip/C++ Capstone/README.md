# 🏆 ARENA MANAGER — Capstone Demonstration

## Local Flask edition

This repository includes the original C++ REST application and frontend, plus a lightweight Flask/SQLite local demonstration entry point (`app.py`) as required by the capstone brief. The Flask app is the easiest way to run the classroom demonstration and uses Python's SQLite driver, Werkzeug password hashing, signed Flask sessions, and no cloud service.

### Run on Windows

For a one-click launch, double-click `run_arena.bat`. It seeds the local demo accounts, opens the app in your browser, and keeps a console open so you can stop the server with Ctrl+C.

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python seed_demo.py
python app.py
```

Open `http://127.0.0.1:5000`. The app stores its data in `database/arena_manager.sqlite3`; set `ARENA_DB` to select another database path and `ARENA_SECRET` to replace the local demonstration session key. No real email delivery is configured. Password recovery and email verification are production extensions.

### Demonstration accounts

All seeded roles use password `ArenaDemo2026!`:

| Role | Email |
|---|---|
| Administrator | `administrator@arena.local` |
| Tournament Organizer | `tournament.organizer@arena.local` |
| Team Captain | `team.captain@arena.local` |
| Scorekeeper | `scorekeeper@arena.local` |
| Player | `player@arena.local` |
| Viewer | `viewer@arena.local` |

Seeded accounts and records are marked as demonstration data. Use the `Demo login` button for the admin demo account. This isolated database is intended for local demonstration; use the production extension notes below before exposing it outside localhost.

### Tests and C++ core

```powershell
python -m unittest discover -s tests -p test_workflow_unittest.py -v
python -m pytest
g++ -std=c++17 -I cpp-core/include cpp-core/src/main.cpp -o cpp-core/arena_core.exe
cpp-core\arena_core.exe
```

The C++17 source in `cpp-core/` genuinely implements player/team validation, battle-royale and head-to-head score strategies, round-robin/first-round knockout scheduling, ranking, champion selection, and schedule file output. The Python Flask app is the web backend; it is not represented as C++.

The original C++ HTTP server and its static frontend remain in `backend/` and `frontend/`. The Flask edition is the currently documented local demonstration path.

### Demonstration scope

Implemented local flows include account creation and login with show/hide password and remember-me, role-gated endpoints, player search, team creation/rosters/invites and join request review, tournament registration code entry/approval/waitlist, fixture generation, match result entry and verification, verified standings, champion declaration, and persisted display preferences. The dashboard now includes responsive card layouts and a mobile menu, page titles and descriptions, local favicon, custom 404 and help pages, footer contact links, 3D card tilt, click feedback, and morph/slide/flip transitions with reduced-motion controls. Existing image assets are compact SVGs. A local QR PNG endpoint uses the included `qrcode[pil]` dependency. Screenshot upload handling, advanced knockout winner progression, certificate rendering, and full reports remain incomplete; these are listed in `DEVELOPMENT_STATUS.md`.

The demo credentials and predictable local secret are for offline classroom use only. Change the secret and add deployment hardening before any network exposure. Demo data isolation is represented by separate demo accounts and seed records; do not use demo accounts to alter non-demo records.

---

# Original C++ Esports Arena System

> **Compete. Conquer. Become a Champion.**

A full-stack Esports Tournament Management System built with **C++ backend** and a **modern gaming-themed web frontend**. Designed as a B.Tech CSE Capstone Project demonstrating Object-Oriented Programming, REST API design, and full-stack web development.

![Platform](https://img.shields.io/badge/Platform-Windows-blue)
![Backend](https://img.shields.io/badge/Backend-C%2B%2B17-00599C)
![Frontend](https://img.shields.io/badge/Frontend-HTML%2FCSS%2FJS-orange)
![Database](https://img.shields.io/badge/Database-SQLite3-003B57)
![License](https://img.shields.io/badge/License-MIT-green)

---

## ✨ Features

### 🔐 Authentication & Authorization
- Three user roles: **Admin**, **Team Captain**, **Player**
- Secure password hashing (SHA-256)
- Session-based token authentication
- Role-based access control on all API endpoints

### 🎮 Tournament Management
- Create and manage tournaments with multiple formats:
  - Single Elimination
  - Double Elimination
  - Round Robin
  - Group Stage + Knockout
- Automatic bracket generation with random seeding
- Tournament registration with admin approval workflow
- Prize pool management

### ⚔️ Match System
- Match scheduling and management
- Live score updates
- Score submission by team captains
- Admin verification of results
- Automatic winner advancement in brackets
- MVP selection per match

### 🏅 Leaderboard & Rankings (C++ Engine)
- **Ranking logic implemented entirely in C++** using STL containers
- Points system: Win = 3pts, Draw = 1pt, Loss = 0pt
- Automatic recalculation after match verification
- Global and per-tournament leaderboards
- Player individual rankings
- Recent form tracking (W/L/D)

### 👥 Team & Player Management
- Team registration with unique invitation codes
- Player profile management
- Roster management by team captains
- Cross-team participation prevention

### 📊 Analytics Dashboard
- Platform-wide statistics
- Tournament participation charts
- Activity logging and audit trail
- Tournament reports generation

### 🔔 Notifications
- Registration approvals/rejections
- Match scheduling updates
- Result notifications
- Tournament announcements

### ⚖️ Dispute System
- Captains can raise disputes on match results
- Admin investigation and resolution workflow
- Evidence URL submission support

---

## 🛠 Technology Stack

| Component | Technology |
|-----------|-----------|
| **Backend** | C++17 with [cpp-httplib](https://github.com/yhirose/cpp-httplib) v0.14.3 |
| **Database** | [SQLite3](https://sqlite.org/) (amalgamation, compiled as C) |
| **JSON** | [nlohmann/json](https://github.com/nlohmann/json) v3.11.3 |
| **Frontend** | HTML5, CSS3, Vanilla JavaScript |
| **API** | RESTful JSON API |
| **Hashing** | Pure C++ SHA-256 implementation |
| **Compiler** | Clang++ (LLVM MinGW) or g++ (MinGW-w64) |

### OOP Concepts Used
- **Classes & Objects**: User, Player, Team, Tournament, Match, Leaderboard, etc.
- **Inheritance**: `User → Admin`, `User → TeamCaptain`, `User → PlayerUser`
- **Encapsulation**: Private data members with public service methods
- **Polymorphism**: Service pattern with singleton instances
- **STL Containers**: `vector`, `unordered_map`, `map`, `sort` with custom comparators
- **Constructors**: Parameterized constructors for all model classes

---

## 📁 Project Structure

```
C++ Capstone/
├── backend/
│   ├── main.cpp                          # Server entry point, REST API routes
│   ├── include/
│   │   ├── models/
│   │   │   ├── User.h                    # User base class + Admin, Captain, Player
│   │   │   ├── Player.h                  # Player model
│   │   │   ├── Team.h                    # Team model + TeamMemberInfo
│   │   │   ├── Tournament.h              # Tournament model with format enums
│   │   │   ├── Match.h                   # Match model with calculateWinner()
│   │   │   ├── Leaderboard.h             # LeaderboardEntry + STL comparator
│   │   │   ├── Dispute.h                 # Dispute model
│   │   │   ├── Notification.h            # Notification model
│   │   │   └── ActivityLog.h             # Activity log + Prize model
│   │   ├── services/
│   │   │   ├── DatabaseService.h         # SQLite wrapper
│   │   │   ├── AuthenticationService.h   # Auth + session management
│   │   │   ├── PlayerService.h           # Player CRUD
│   │   │   ├── TeamService.h             # Team management
│   │   │   ├── TournamentService.h       # Tournament + bracket logic
│   │   │   ├── MatchService.h            # Match scheduling
│   │   │   ├── ScoreService.h            # Score management
│   │   │   ├── LeaderboardService.h      # C++ ranking engine
│   │   │   ├── NotificationService.h     # Notification dispatch
│   │   │   ├── DisputeService.h          # Dispute handling
│   │   │   └── Sha256.h                  # Pure C++ SHA-256
│   │   └── third_party/
│   │       ├── httplib.h                 # cpp-httplib v0.14.3
│   │       ├── json.hpp                  # nlohmann/json v3.11.3
│   │       ├── sqlite3.h                 # SQLite3 header
│   │       └── sqlite3.c                 # SQLite3 amalgamation
│   └── src/
│       ├── DatabaseService.cpp           # DB init, migrations, demo data seeding
│       ├── AuthenticationService.cpp     # Login, register, sessions
│       ├── PlayerService.cpp             # Player operations
│       ├── TeamService.cpp               # Team operations
│       ├── TournamentService.cpp         # Tournament + bracket generation
│       ├── MatchService.cpp              # Match CRUD
│       ├── ScoreService.cpp              # Score submission + verification
│       ├── LeaderboardService.cpp        # C++ ranking with STL sort
│       ├── NotificationService.cpp       # Notification management
│       └── DisputeService.cpp            # Dispute management
├── frontend/
│   ├── index.html                        # Landing page
│   ├── login.html                        # Login page
│   ├── register-player.html              # Player registration
│   ├── register-team.html                # Team captain registration
│   ├── admin-dashboard.html              # Admin dashboard
│   ├── captain-dashboard.html            # Captain dashboard
│   ├── player-dashboard.html             # Player dashboard
│   ├── tournaments.html                  # Tournament listing
│   ├── tournament-detail.html            # Tournament details
│   ├── tournament-bracket.html           # Visual bracket
│   ├── match-schedule.html               # Match scheduling (admin)
│   ├── scoreboard.html                   # Live scoreboard
│   ├── leaderboard.html                  # Leaderboard & rankings
│   ├── team-profile.html                 # Team profile
│   ├── player-profile.html               # Player profile
│   ├── notifications.html                # Notifications
│   ├── match-history.html                # Match history
│   ├── admin-reports.html                # Reports & analytics
│   ├── disputes.html                     # Dispute management
│   └── settings.html                     # User settings
├── assets/
│   ├── css/
│   │   └── main.css                      # Complete dark gaming theme CSS
│   └── js/
│       └── app.js                        # Shared JS utilities
├── database/
│   └── schema.sql                        # Database schema (13 tables)
├── build.bat                             # Windows build script
└── README.md                             # This file
```

---

## 🚀 Getting Started

### Prerequisites

1. **C++ Compiler** — LLVM MinGW (recommended) or MinGW-w64 with C++17 support:
   ```
   winget install MartinStorsjo.LLVM-MinGW.UCRT
   ```

2. **No other dependencies required** — all libraries are included as single-header files.

### Build

```cmd
cd "C++ Capstone"
build.bat
```

Or manually with PowerShell:
```powershell
# Step 1: Compile SQLite3 as C
clang -c -O1 -DSQLITE_THREADSAFE=1 -DSQLITE_ENABLE_JSON1 backend\include\third_party\sqlite3.c -o backend\sqlite3.o

# Step 2: Compile and link C++ backend
clang++ -std=c++17 -O1 -DSQLITE_THREADSAFE=1 -DSQLITE_ENABLE_JSON1 `
    -Ibackend/include -Ibackend/include/third_party `
    backend\src\DatabaseService.cpp `
    backend\src\AuthenticationService.cpp `
    backend\src\PlayerService.cpp `
    backend\src\TeamService.cpp `
    backend\src\TournamentService.cpp `
    backend\src\MatchService.cpp `
    backend\src\ScoreService.cpp `
    backend\src\LeaderboardService.cpp `
    backend\src\NotificationService.cpp `
    backend\src\DisputeService.cpp `
    backend\main.cpp `
    backend\sqlite3.o `
    -o backend\esports_server.exe `
    -lws2_32 -lpthread
```

### Run

```cmd
backend\esports_server.exe
```

Then open your browser to: **http://localhost:8080**

The server automatically:
- Creates the SQLite database (`database/esports_arena.db`)
- Runs schema migrations
- Seeds demo data (8 teams, 30 players, 3 tournaments)

---

## 🔑 Demo Credentials

| Role | Username | Password | Description |
|------|----------|----------|-------------|
| **Admin** | `admin` | `Admin@123` | Full platform control |
| **Captain** | `shahzam` | `Captain@123` | Team captain for Sentinels |
| **Player** | `tenz` | `Player@123` | Player on Sentinels |

Additional captain accounts: `fallen` (LOUD), `karrigan` (FaZe Clan)

---

## 📡 API Reference

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/register/player` | Register as player |
| POST | `/api/auth/register/captain` | Register as captain |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/logout` | Logout |
| PUT | `/api/auth/profile` | Update profile |
| PUT | `/api/auth/change-password` | Change password |

### Players
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/players` | List all players |
| GET | `/api/players/me` | Get my player profile |
| GET | `/api/players/:id` | Get player by ID |
| POST | `/api/players/join-team` | Join team with invite code |
| POST | `/api/players/leave-team` | Leave current team |

### Teams
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/teams` | List all teams |
| GET | `/api/teams/my` | Get my team (captain) |
| GET | `/api/teams/:id` | Get team by ID |
| POST | `/api/teams` | Register new team |
| PUT | `/api/teams/:id` | Update team |
| GET | `/api/teams/:id/matches` | Get team's matches |
| GET | `/api/teams/:id/tournaments` | Get team's tournaments |

### Tournaments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tournaments` | List tournaments (filter: game, status, search) |
| GET | `/api/tournaments/:id` | Get tournament details |
| POST | `/api/tournaments` | Create tournament (admin) |
| PUT | `/api/tournaments/:id` | Update tournament (admin) |
| DELETE | `/api/tournaments/:id` | Delete tournament (admin) |
| POST | `/api/tournaments/:id/register` | Register team for tournament |
| GET | `/api/tournaments/:id/registrations` | Get registrations |
| PUT | `/api/registrations/:id` | Approve/reject registration (admin) |
| POST | `/api/tournaments/:id/generate-bracket` | Generate bracket (admin) |
| GET | `/api/tournaments/:id/bracket` | Get bracket data |
| GET | `/api/tournaments/:id/report` | Get tournament report (admin) |

### Matches
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/matches` | List matches (filter: tournamentId, status, game) |
| GET | `/api/matches/upcoming` | Upcoming matches |
| GET | `/api/matches/live` | Live matches |
| GET | `/api/matches/history` | Match history |
| GET | `/api/matches/:id` | Get match by ID |
| POST | `/api/matches` | Schedule match (admin) |
| PUT | `/api/matches/:id/schedule` | Update schedule (admin) |

### Scoreboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/scoreboard/live` | All live scoreboards |
| GET | `/api/scoreboard/:id` | Match scoreboard |
| POST | `/api/matches/:id/submit-score` | Submit score (captain) |
| PUT | `/api/matches/:id/live-score` | Update live score (admin) |
| POST | `/api/matches/:id/verify` | Verify result (admin) |

### Leaderboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/leaderboard` | Global team leaderboard |
| GET | `/api/leaderboard/top3` | Top 3 teams |
| GET | `/api/leaderboard/players` | Player rankings |
| GET | `/api/leaderboard/tournament/:id` | Tournament leaderboard |
| POST | `/api/leaderboard/recalculate` | Force recalculation (admin) |

### Notifications & Disputes
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/notifications` | Get user notifications |
| PUT | `/api/notifications/:id/read` | Mark as read |
| PUT | `/api/notifications/read-all` | Mark all as read |
| GET | `/api/disputes` | List disputes (admin) |
| POST | `/api/matches/:id/dispute` | Raise dispute (captain) |
| PUT | `/api/disputes/:id/resolve` | Resolve dispute (admin) |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/analytics` | Platform analytics |
| GET | `/api/admin/activity-logs` | Activity logs |
| GET | `/api/admin/users` | List users |

---

## 🎨 Design

- **Dark Gaming Theme** with navy/black backgrounds
- **Accent Colors**: Neon purple (#9b27ff), Electric blue (#6366f1), Cyan (#00e5ff)
- **Responsive Design** for desktop, tablet, and mobile
- **Gaming-style UI**: Glowing borders, animated cards, live pulse indicators
- **Professional Dashboard** with sidebar navigation
- **Interactive Tournament Bracket** visualization

---

## 📋 Database Schema

13 tables including:
- `users` — User accounts with role-based access
- `players` — Extended player profiles
- `teams` — Team information
- `team_members` — Team roster management
- `tournaments` — Tournament configuration
- `tournament_registrations` — Team tournament registrations
- `matches` — Match scheduling and results
- `leaderboard` — Computed rankings
- `notifications` — User notifications
- `disputes` — Match dispute tracking
- `activity_logs` — Audit trail
- `prizes` — Tournament prize distribution

---

## 🎯 Demo Data

The system seeds with realistic esports data:
- **8 Teams**: Sentinels, Cloud9, FaZe Clan, LOUD, Team Liquid, NaVi, Fnatic, T1
- **30 Players**: Inspired by real esports professionals
- **3 Tournaments**: Valorant Champions, CS2 Major, Apex Legends Championship
- Pre-configured matches, leaderboard entries, and notifications

---

## 📜 License

This project is part of a B.Tech CSE Capstone submission. MIT License.

---

<div align="center">

**Built with ❤️ using C++ | Esports Arena © 2024**

</div>
