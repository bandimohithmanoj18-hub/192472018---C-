# Development status

## Completed

- Flask local entry point with persistent SQLite database and foreign-key enforcement.
- Secure Werkzeug password hashing, signed sessions, registration, login, logout, role checks, and seeded demo accounts.
- Player profile creation/search, teams, captain ownership, unique roster membership, roster limits, team invitation codes, and captain join approval workflow.
- Tournament creation, team registration review, waitlist queue positions, round-robin pair generation, simple knockout first round/byes, and battle-royale lobby participants.
- Result submission and revision history, verification gating, configurable head-to-head and battle-royale standings, and champion declaration only from verified results.
- Check-in and dispute persistence endpoints, user preference persistence, and dashboard statistics sourced from SQLite.
- Responsive single-page dashboard with a collapsible mobile menu, card-style mobile tables, page-specific titles/descriptions, local favicon, working help and custom 404 pages, footer account links, and the current copyright year.
- Mouse-driven 3D card tilt, clickable press feedback, and user-selectable morph/slide/flip transitions with reduced-motion support.
- Dedicated mobile-friendly sign-in and account creation panels with show/hide password, remember-me session option, and honest offline password-reset guidance.
- Optional contact phone is stored on registration and rendered as a `tel:` link; email uses a `mailto:` link. Existing image assets are small SVG vectors (all below 1.4 KB), so no large raster image compression was needed.
- Genuine C++17 academic core with models, scoring strategies, schedulers, ranking/champion services, file output, and assertion-based checks.
- Local run/build/test commands and six demonstration role accounts documented in README.

## Incomplete

- QR PNG endpoint requires the included `qrcode[pil]` dependency to be installed.
- Evidence upload validation/storage and dispute review UI.
- Full knockout round progression and interactive bracket.
- Printable certificate, player/team history screens, full reports, and notification center.
- Demo write isolation is not comprehensive across every endpoint; use only the isolated seeded demo database for presentations.

## Tests executed

- `python -m py_compile app.py seed_demo.py tests\\test_app.py` — passed.
- Flask test-client smoke: demo login, dashboard/team retrieval, account registration, and team creation — passed.
- `python -m unittest discover -s tests -p test_workflow_unittest.py -v` — passed (workflow, responsive assets, help, custom 404, and mailto/tel links).
- Latest `python app.py` server is reachable in the local browser at `http://127.0.0.1:5000`; overview, tournament, and match pages were verified.
- C++17 core compiled using the installed LLVM MinGW compiler and ran its assertions — passed (`C++ core checks passed`).
- `python -m pytest -q` — not run: pytest is not installed. `python -m pip install pytest` was attempted, but package index DNS resolution failed in this environment.
- The default `C:\\MinGW\\bin\\g++.exe` could not start because Windows reported an illegal system DLL relocation; an installed Clang compiler successfully built the core.
- The initial restricted server process could not accept browser connections; restarting with local network access resolved it. `run_arena.bat` is included for repeatable desktop launch.

## Errors remaining

- Pytest suite remains unexecuted until pytest is installed in an environment with package access. The README includes `python -m pytest` for that environment.
- Local QR generation endpoint depends on the `qrcode[pil]` requirement being installed; invitation URL/code creation itself works without it.

## Run commands

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python seed_demo.py
python app.py
```

```powershell
python -m pytest
g++ -std=c++17 -I cpp-core/include cpp-core/src/main.cpp -o cpp-core/arena_core.exe
cpp-core\arena_core.exe
```
