@echo off
title ESPORTS ARENA - Instant Public HTTPS Deployment
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy_public_tunnel.ps1"
pause
