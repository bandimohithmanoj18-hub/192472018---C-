#pragma once
#include <string>

namespace Esports {

class Player {
private:
    int m_id;
    int m_userId;
    std::string m_username;
    std::string m_fullName;
    std::string m_gameId;
    std::string m_selectedGame;
    std::string m_playerRole;
    int m_teamId;
    std::string m_teamName;
    int m_matchesPlayed;
    int m_matchesWon;
    int m_matchesLost;
    int m_mvpAwards;
    double m_rating;
    std::string m_country;
    std::string m_avatarUrl;

public:
    Player()
        : m_id(0), m_userId(0), m_playerRole("Rifler / Assaulter"),
          m_teamId(0), m_matchesPlayed(0), m_matchesWon(0),
          m_matchesLost(0), m_mvpAwards(0), m_rating(1200.0),
          m_country("India"), m_avatarUrl("/assets/images/default-avatar.svg") {}

    Player(int id, int userId, const std::string& username, const std::string& fullName,
           const std::string& gameId, const std::string& selectedGame,
           const std::string& playerRole = "Rifler / Assaulter", int teamId = 0,
           const std::string& teamName = "", int matchesPlayed = 0, int matchesWon = 0,
           int matchesLost = 0, int mvpAwards = 0, double rating = 1200.0,
           const std::string& country = "India", const std::string& avatarUrl = "/assets/images/default-avatar.svg")
        : m_id(id), m_userId(userId), m_username(username), m_fullName(fullName),
          m_gameId(gameId), m_selectedGame(selectedGame), m_playerRole(playerRole),
          m_teamId(teamId), m_teamName(teamName), m_matchesPlayed(matchesPlayed),
          m_matchesWon(matchesWon), m_matchesLost(matchesLost), m_mvpAwards(mvpAwards),
          m_rating(rating), m_country(country), m_avatarUrl(avatarUrl) {}

    // Getters
    int getId() const { return m_id; }
    int getUserId() const { return m_userId; }
    const std::string& getUsername() const { return m_username; }
    const std::string& getFullName() const { return m_fullName; }
    const std::string& getGameId() const { return m_gameId; }
    const std::string& getSelectedGame() const { return m_selectedGame; }
    const std::string& getPlayerRole() const { return m_playerRole; }
    int getTeamId() const { return m_teamId; }
    const std::string& getTeamName() const { return m_teamName; }
    int getMatchesPlayed() const { return m_matchesPlayed; }
    int getMatchesWon() const { return m_matchesWon; }
    int getMatchesLost() const { return m_matchesLost; }
    int getMvpAwards() const { return m_mvpAwards; }
    double getRating() const { return m_rating; }
    const std::string& getCountry() const { return m_country; }
    const std::string& getAvatarUrl() const { return m_avatarUrl; }

    double getWinPercentage() const {
        if (m_matchesPlayed == 0) return 0.0;
        return (static_cast<double>(m_matchesWon) / m_matchesPlayed) * 100.0;
    }

    // Setters
    void setId(int id) { m_id = id; }
    void setUserId(int uid) { m_userId = uid; }
    void setUsername(const std::string& un) { m_username = un; }
    void setFullName(const std::string& fn) { m_fullName = fn; }
    void setGameId(const std::string& gid) { m_gameId = gid; }
    void setSelectedGame(const std::string& sg) { m_selectedGame = sg; }
    void setPlayerRole(const std::string& pr) { m_playerRole = pr; }
    void setTeamId(int tid) { m_teamId = tid; }
    void setTeamName(const std::string& tn) { m_teamName = tn; }
    void setMatchesPlayed(int mp) { m_matchesPlayed = mp; }
    void setMatchesWon(int mw) { m_matchesWon = mw; }
    void setMatchesLost(int ml) { m_matchesLost = ml; }
    void setMvpAwards(int mvp) { m_mvpAwards = mvp; }
    void setRating(double r) { m_rating = r; }
    void setCountry(const std::string& c) { m_country = c; }
    void setAvatarUrl(const std::string& a) { m_avatarUrl = a; }

    void recordMatchOutcome(bool won, bool isMvp = false) {
        m_matchesPlayed++;
        if (won) {
            m_matchesWon++;
            m_rating += 25.0;
        } else {
            m_matchesLost++;
            m_rating = (m_rating > 1025.0) ? (m_rating - 15.0) : 1000.0;
        }
        if (isMvp) {
            m_mvpAwards++;
            m_rating += 15.0;
        }
    }
};

} // namespace Esports

