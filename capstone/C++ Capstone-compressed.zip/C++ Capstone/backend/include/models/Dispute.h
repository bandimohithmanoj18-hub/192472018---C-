#pragma once
#include <string>

namespace Esports {

enum class DisputeStatus {
    Open,
    UnderReview,
    Resolved,
    Dismissed
};

inline std::string disputeStatusToString(DisputeStatus s) {
    switch (s) {
        case DisputeStatus::Open: return "Open";
        case DisputeStatus::UnderReview: return "Under Review";
        case DisputeStatus::Resolved: return "Resolved";
        case DisputeStatus::Dismissed: return "Dismissed";
        default: return "Open";
    }
}

inline DisputeStatus stringToDisputeStatus(const std::string& str) {
    if (str == "Under Review") return DisputeStatus::UnderReview;
    if (str == "Resolved") return DisputeStatus::Resolved;
    if (str == "Dismissed") return DisputeStatus::Dismissed;
    return DisputeStatus::Open;
}

class Dispute {
private:
    int m_id;
    int m_matchId;
    std::string m_matchDetails;
    int m_raisedBy;
    std::string m_raisedByName;
    int m_teamId;
    std::string m_teamName;
    std::string m_reason;
    std::string m_evidenceUrl;
    DisputeStatus m_status;
    std::string m_adminNotes;
    std::string m_createdAt;
    std::string m_resolvedAt;
    int m_resolvedBy;

public:
    Dispute()
        : m_id(0), m_matchId(0), m_raisedBy(0), m_teamId(0),
          m_status(DisputeStatus::Open), m_resolvedBy(0) {}

    Dispute(int id, int matchId, int raisedBy, const std::string& raisedByName,
            int teamId, const std::string& teamName, const std::string& reason,
            const std::string& evidenceUrl, DisputeStatus status = DisputeStatus::Open,
            const std::string& adminNotes = "", const std::string& createdAt = "")
        : m_id(id), m_matchId(matchId), m_raisedBy(raisedBy),
          m_raisedByName(raisedByName), m_teamId(teamId), m_teamName(teamName),
          m_reason(reason), m_evidenceUrl(evidenceUrl), m_status(status),
          m_adminNotes(adminNotes), m_createdAt(createdAt), m_resolvedBy(0) {}

    // Getters
    int getId() const { return m_id; }
    int getMatchId() const { return m_matchId; }
    const std::string& getMatchDetails() const { return m_matchDetails; }
    int getRaisedBy() const { return m_raisedBy; }
    const std::string& getRaisedByName() const { return m_raisedByName; }
    int getTeamId() const { return m_teamId; }
    const std::string& getTeamName() const { return m_teamName; }
    const std::string& getReason() const { return m_reason; }
    const std::string& getEvidenceUrl() const { return m_evidenceUrl; }
    DisputeStatus getStatus() const { return m_status; }
    std::string getStatusString() const { return disputeStatusToString(m_status); }
    const std::string& getAdminNotes() const { return m_adminNotes; }
    const std::string& getCreatedAt() const { return m_createdAt; }
    const std::string& getResolvedAt() const { return m_resolvedAt; }
    int getResolvedBy() const { return m_resolvedBy; }

    // Setters
    void setId(int id) { m_id = id; }
    void setMatchId(int mid) { m_matchId = mid; }
    void setMatchDetails(const std::string& md) { m_matchDetails = md; }
    void setRaisedBy(int uid) { m_raisedBy = uid; }
    void setRaisedByName(const std::string& n) { m_raisedByName = n; }
    void setTeamId(int tid) { m_teamId = tid; }
    void setTeamName(const std::string& tn) { m_teamName = tn; }
    void setReason(const std::string& r) { m_reason = r; }
    void setEvidenceUrl(const std::string& eu) { m_evidenceUrl = eu; }
    void setStatus(DisputeStatus s) { m_status = s; }
    void setAdminNotes(const std::string& an) { m_adminNotes = an; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }
    void setResolvedAt(const std::string& ra) { m_resolvedAt = ra; }
    void setResolvedBy(int uid) { m_resolvedBy = uid; }
};

} // namespace Esports

