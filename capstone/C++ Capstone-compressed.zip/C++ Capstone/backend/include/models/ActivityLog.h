#pragma once
#include <string>

namespace Esports {

class ActivityLog {
private:
    int m_id;
    int m_userId;
    std::string m_userName;
    std::string m_action;
    std::string m_details;
    std::string m_ipAddress;
    std::string m_createdAt;

public:
    ActivityLog()
        : m_id(0), m_userId(0), m_ipAddress("127.0.0.1") {}

    ActivityLog(int id, int userId, const std::string& userName,
                const std::string& action, const std::string& details,
                const std::string& ip = "127.0.0.1", const std::string& createdAt = "")
        : m_id(id), m_userId(userId), m_userName(userName),
          m_action(action), m_details(details), m_ipAddress(ip),
          m_createdAt(createdAt) {}

    int getId() const { return m_id; }
    int getUserId() const { return m_userId; }
    const std::string& getUserName() const { return m_userName; }
    const std::string& getAction() const { return m_action; }
    const std::string& getDetails() const { return m_details; }
    const std::string& getIpAddress() const { return m_ipAddress; }
    const std::string& getCreatedAt() const { return m_createdAt; }

    void setId(int id) { m_id = id; }
    void setUserId(int uid) { m_userId = uid; }
    void setUserName(const std::string& un) { m_userName = un; }
    void setAction(const std::string& a) { m_action = a; }
    void setDetails(const std::string& d) { m_details = d; }
    void setIpAddress(const std::string& ip) { m_ipAddress = ip; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }
};

class Prize {
private:
    int m_id;
    int m_tournamentId;
    int m_place; // 1, 2, 3
    std::string m_rewardTitle;
    double m_rewardAmount;
    int m_teamId;
    std::string m_teamName;

public:
    Prize() : m_id(0), m_tournamentId(0), m_place(1), m_rewardAmount(0.0), m_teamId(0) {}
    Prize(int id, int tid, int place, const std::string& title, double amount, int teamId = 0, const std::string& teamName = "")
        : m_id(id), m_tournamentId(tid), m_place(place), m_rewardTitle(title),
          m_rewardAmount(amount), m_teamId(teamId), m_teamName(teamName) {}

    int getId() const { return m_id; }
    int getTournamentId() const { return m_tournamentId; }
    int getPlace() const { return m_place; }
    const std::string& getRewardTitle() const { return m_rewardTitle; }
    double getRewardAmount() const { return m_rewardAmount; }
    int getTeamId() const { return m_teamId; }
    const std::string& getTeamName() const { return m_teamName; }

    void setId(int id) { m_id = id; }
    void setTournamentId(int tid) { m_tournamentId = tid; }
    void setPlace(int p) { m_place = p; }
    void setRewardTitle(const std::string& t) { m_rewardTitle = t; }
    void setRewardAmount(double a) { m_rewardAmount = a; }
    void setTeamId(int tid) { m_teamId = tid; }
    void setTeamName(const std::string& tn) { m_teamName = tn; }
};

} // namespace Esports

