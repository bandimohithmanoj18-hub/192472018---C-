#pragma once
#include <string>

namespace Esports {

enum class MatchStatus {
    Upcoming,
    Live,
    UnderReview,
    Completed
};

inline std::string matchStatusToString(MatchStatus s) {
    switch (s) {
        case MatchStatus::Upcoming: return "Upcoming";
        case MatchStatus::Live: return "Live";
        case MatchStatus::UnderReview: return "Under Review";
        case MatchStatus::Completed: return "Completed";
        default: return "Upcoming";
    }
}

inline MatchStatus stringToMatchStatus(const std::string& str) {
    if (str == "Live") return MatchStatus::Live;
    if (str == "Under Review") return MatchStatus::UnderReview;
    if (str == "Completed") return MatchStatus::Completed;
    return MatchStatus::Upcoming;
}

class Match {
private:
    int m_id;
    int m_tournamentId;
    std::string m_tournamentName;
    int m_roundNumber;
    int m_matchNumber;
    std::string m_bracketType; // 'Winners', 'Losers', 'Group', 'Finals'
    int m_teamAId;
    std::string m_teamAName;
    std::string m_teamALogo;
    int m_teamBId;
    std::string m_teamBName;
    std::string m_teamBLogo;
    int m_teamAScore;
    int m_teamBScore;
    std::string m_scheduledTime;
    std::string m_slotInfo;
    MatchStatus m_status;
    int m_winnerTeamId;
    std::string m_winnerTeamName;
    int m_mvpPlayerId;
    std::string m_mvpPlayerName;
    int m_submittedBy;
    std::string m_submissionNotes;
    bool m_isVerified;
    int m_verifiedBy;
    int m_nextMatchId;
    std::string m_createdAt;

public:
    Match()
        : m_id(0), m_tournamentId(0), m_roundNumber(1), m_matchNumber(1),
          m_bracketType("Winners"), m_teamAId(0), m_teamBId(0),
          m_teamAScore(0), m_teamBScore(0), m_status(MatchStatus::Upcoming),
          m_winnerTeamId(0), m_mvpPlayerId(0), m_submittedBy(0),
          m_isVerified(false), m_verifiedBy(0), m_nextMatchId(0),
          m_teamALogo("/assets/images/default-team.svg"),
          m_teamBLogo("/assets/images/default-team.svg") {}

    // Getters
    int getId() const { return m_id; }
    int getTournamentId() const { return m_tournamentId; }
    const std::string& getTournamentName() const { return m_tournamentName; }
    int getRoundNumber() const { return m_roundNumber; }
    int getMatchNumber() const { return m_matchNumber; }
    const std::string& getBracketType() const { return m_bracketType; }
    int getTeamAId() const { return m_teamAId; }
    const std::string& getTeamAName() const { return m_teamAName; }
    const std::string& getTeamALogo() const { return m_teamALogo; }
    int getTeamBId() const { return m_teamBId; }
    const std::string& getTeamBName() const { return m_teamBName; }
    const std::string& getTeamBLogo() const { return m_teamBLogo; }
    int getTeamAScore() const { return m_teamAScore; }
    int getTeamBScore() const { return m_teamBScore; }
    const std::string& getScheduledTime() const { return m_scheduledTime; }
    const std::string& getSlotInfo() const { return m_slotInfo; }
    MatchStatus getStatus() const { return m_status; }
    std::string getStatusString() const { return matchStatusToString(m_status); }
    int getWinnerTeamId() const { return m_winnerTeamId; }
    const std::string& getWinnerTeamName() const { return m_winnerTeamName; }
    int getMvpPlayerId() const { return m_mvpPlayerId; }
    const std::string& getMvpPlayerName() const { return m_mvpPlayerName; }
    int getSubmittedBy() const { return m_submittedBy; }
    const std::string& getSubmissionNotes() const { return m_submissionNotes; }
    bool isVerified() const { return m_isVerified; }
    int getVerifiedBy() const { return m_verifiedBy; }
    int getNextMatchId() const { return m_nextMatchId; }
    const std::string& getCreatedAt() const { return m_createdAt; }

    // Setters
    void setId(int id) { m_id = id; }
    void setTournamentId(int tid) { m_tournamentId = tid; }
    void setTournamentName(const std::string& tn) { m_tournamentName = tn; }
    void setRoundNumber(int rn) { m_roundNumber = rn; }
    void setMatchNumber(int mn) { m_matchNumber = mn; }
    void setBracketType(const std::string& bt) { m_bracketType = bt; }
    void setTeamAId(int id) { m_teamAId = id; }
    void setTeamAName(const std::string& n) { m_teamAName = n; }
    void setTeamALogo(const std::string& l) { m_teamALogo = l; }
    void setTeamBId(int id) { m_teamBId = id; }
    void setTeamBName(const std::string& n) { m_teamBName = n; }
    void setTeamBLogo(const std::string& l) { m_teamBLogo = l; }
    void setTeamAScore(int s) { m_teamAScore = s; }
    void setTeamBScore(int s) { m_teamBScore = s; }
    void setScheduledTime(const std::string& st) { m_scheduledTime = st; }
    void setSlotInfo(const std::string& si) { m_slotInfo = si; }
    void setStatus(MatchStatus s) { m_status = s; }
    void setWinnerTeamId(int wid) { m_winnerTeamId = wid; }
    void setWinnerTeamName(const std::string& wn) { m_winnerTeamName = wn; }
    void setMvpPlayerId(int pid) { m_mvpPlayerId = pid; }
    void setMvpPlayerName(const std::string& pn) { m_mvpPlayerName = pn; }
    void setSubmittedBy(int uid) { m_submittedBy = uid; }
    void setSubmissionNotes(const std::string& sn) { m_submissionNotes = sn; }
    void setIsVerified(bool v) { m_isVerified = v; }
    void setVerifiedBy(int uid) { m_verifiedBy = uid; }
    void setNextMatchId(int nmid) { m_nextMatchId = nmid; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }

    // C++ business logic: calculate winner
    int calculateWinner() const {
        if (m_teamAScore > m_teamBScore) return m_teamAId;
        if (m_teamBScore > m_teamAScore) return m_teamBId;
        return 0; // Draw or undecided
    }
};

} // namespace Esports

