#pragma once
#include <string>
#include <vector>

namespace Esports {

enum class TournamentFormat {
    SingleElimination,
    DoubleElimination,
    RoundRobin,
    GroupStageKnockout
};

enum class TournamentStatus {
    Upcoming,
    RegistrationOpen,
    Ongoing,
    Completed
};

inline std::string formatToString(TournamentFormat f) {
    switch (f) {
        case TournamentFormat::SingleElimination: return "Single Elimination";
        case TournamentFormat::DoubleElimination: return "Double Elimination";
        case TournamentFormat::RoundRobin: return "Round Robin";
        case TournamentFormat::GroupStageKnockout: return "Group Stage + Knockout";
        default: return "Single Elimination";
    }
}

inline TournamentFormat stringToFormat(const std::string& str) {
    if (str == "Double Elimination") return TournamentFormat::DoubleElimination;
    if (str == "Round Robin") return TournamentFormat::RoundRobin;
    if (str == "Group Stage + Knockout") return TournamentFormat::GroupStageKnockout;
    return TournamentFormat::SingleElimination;
}

inline std::string statusToString(TournamentStatus s) {
    switch (s) {
        case TournamentStatus::Upcoming: return "Upcoming";
        case TournamentStatus::RegistrationOpen: return "Registration Open";
        case TournamentStatus::Ongoing: return "Ongoing";
        case TournamentStatus::Completed: return "Completed";
        default: return "Upcoming";
    }
}

inline TournamentStatus stringToStatus(const std::string& str) {
    if (str == "Registration Open") return TournamentStatus::RegistrationOpen;
    if (str == "Ongoing") return TournamentStatus::Ongoing;
    if (str == "Completed") return TournamentStatus::Completed;
    return TournamentStatus::Upcoming;
}

struct TournamentRegistrationInfo {
    int registrationId;
    int teamId;
    std::string teamName;
    std::string teamLogo;
    std::string captainName;
    std::string status; // 'Pending', 'Approved', 'Rejected'
    std::string registeredAt;
};

class Tournament {
private:
    int m_id;
    std::string m_name;
    std::string m_gameCategory;
    std::string m_description;
    TournamentFormat m_format;
    TournamentStatus m_status;
    std::string m_startDate;
    std::string m_endDate;
    std::string m_registrationDeadline;
    int m_maxTeams;
    double m_prizePool;
    std::string m_bannerUrl;
    std::string m_rules;
    int m_winnerTeamId;
    std::string m_winnerTeamName;
    int m_runnerUpTeamId;
    std::string m_runnerUpTeamName;
    std::string m_createdAt;
    int m_approvedTeamsCount;
    int m_totalRegistrationsCount;

public:
    Tournament()
        : m_id(0), m_format(TournamentFormat::SingleElimination),
          m_status(TournamentStatus::Upcoming), m_maxTeams(8),
          m_prizePool(0.0), m_winnerTeamId(0), m_runnerUpTeamId(0),
          m_approvedTeamsCount(0), m_totalRegistrationsCount(0),
          m_bannerUrl("/assets/images/default-banner.svg") {}

    Tournament(int id, const std::string& name, const std::string& gameCategory,
               const std::string& desc, TournamentFormat format, TournamentStatus status,
               const std::string& start, const std::string& end, const std::string& deadline,
               int maxTeams, double prizePool, const std::string& banner,
               const std::string& rules = "", int winnerId = 0, int runnerUpId = 0,
               const std::string& createdAt = "")
        : m_id(id), m_name(name), m_gameCategory(gameCategory),
          m_description(desc), m_format(format), m_status(status),
          m_startDate(start), m_endDate(end), m_registrationDeadline(deadline),
          m_maxTeams(maxTeams), m_prizePool(prizePool), m_bannerUrl(banner),
          m_rules(rules), m_winnerTeamId(winnerId), m_runnerUpTeamId(runnerUpId),
          m_createdAt(createdAt), m_approvedTeamsCount(0), m_totalRegistrationsCount(0) {}

    // Getters
    int getId() const { return m_id; }
    const std::string& getName() const { return m_name; }
    const std::string& getGameCategory() const { return m_gameCategory; }
    const std::string& getDescription() const { return m_description; }
    TournamentFormat getFormat() const { return m_format; }
    std::string getFormatString() const { return formatToString(m_format); }
    TournamentStatus getStatus() const { return m_status; }
    std::string getStatusString() const { return statusToString(m_status); }
    const std::string& getStartDate() const { return m_startDate; }
    const std::string& getEndDate() const { return m_endDate; }
    const std::string& getRegistrationDeadline() const { return m_registrationDeadline; }
    int getMaxTeams() const { return m_maxTeams; }
    double getPrizePool() const { return m_prizePool; }
    const std::string& getBannerUrl() const { return m_bannerUrl; }
    const std::string& getRules() const { return m_rules; }
    int getWinnerTeamId() const { return m_winnerTeamId; }
    const std::string& getWinnerTeamName() const { return m_winnerTeamName; }
    int getRunnerUpTeamId() const { return m_runnerUpTeamId; }
    const std::string& getRunnerUpTeamName() const { return m_runnerUpTeamName; }
    const std::string& getCreatedAt() const { return m_createdAt; }
    int getApprovedTeamsCount() const { return m_approvedTeamsCount; }
    int getTotalRegistrationsCount() const { return m_totalRegistrationsCount; }

    bool isRegistrationOpen() const {
        return (m_status == TournamentStatus::RegistrationOpen || m_status == TournamentStatus::Upcoming) &&
               (m_approvedTeamsCount < m_maxTeams);
    }

    // Setters
    void setId(int id) { m_id = id; }
    void setName(const std::string& n) { m_name = n; }
    void setGameCategory(const std::string& gc) { m_gameCategory = gc; }
    void setDescription(const std::string& d) { m_description = d; }
    void setFormat(TournamentFormat f) { m_format = f; }
    void setStatus(TournamentStatus s) { m_status = s; }
    void setStartDate(const std::string& s) { m_startDate = s; }
    void setEndDate(const std::string& e) { m_endDate = e; }
    void setRegistrationDeadline(const std::string& rd) { m_registrationDeadline = rd; }
    void setMaxTeams(int mt) { m_maxTeams = mt; }
    void setPrizePool(double pp) { m_prizePool = pp; }
    void setBannerUrl(const std::string& b) { m_bannerUrl = b; }
    void setRules(const std::string& r) { m_rules = r; }
    void setWinnerTeamId(int wid) { m_winnerTeamId = wid; }
    void setWinnerTeamName(const std::string& wn) { m_winnerTeamName = wn; }
    void setRunnerUpTeamId(int rid) { m_runnerUpTeamId = rid; }
    void setRunnerUpTeamName(const std::string& rn) { m_runnerUpTeamName = rn; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }
    void setApprovedTeamsCount(int c) { m_approvedTeamsCount = c; }
    void setTotalRegistrationsCount(int c) { m_totalRegistrationsCount = c; }
};

} // namespace Esports

