#pragma once
#include <string>
#include <vector>
#include <algorithm>

namespace Esports {

class LeaderboardEntry {
private:
    int m_rank;
    int m_teamId;
    std::string m_teamName;
    std::string m_teamLogo;
    std::string m_gameCategory;
    int m_tournamentId;
    int m_matchesPlayed;
    int m_wins;
    int m_losses;
    int m_draws;
    int m_points;
    int m_totalScore;
    int m_scoreAgainst;
    double m_winPercentage;
    std::string m_recentForm; // e.g., "W-W-L-W-W"

public:
    LeaderboardEntry()
        : m_rank(0), m_teamId(0), m_tournamentId(0),
          m_matchesPlayed(0), m_wins(0), m_losses(0),
          m_draws(0), m_points(0), m_totalScore(0),
          m_scoreAgainst(0), m_winPercentage(0.0),
          m_recentForm("-----"),
          m_teamLogo("/assets/images/default-team.svg") {}

    LeaderboardEntry(int teamId, const std::string& teamName, const std::string& logo,
                     const std::string& gameCategory, int tournamentId,
                     int matchesPlayed, int wins, int losses, int draws,
                     int totalScore, int scoreAgainst = 0, const std::string& form = "-----")
        : m_rank(0), m_teamId(teamId), m_teamName(teamName), m_teamLogo(logo),
          m_gameCategory(gameCategory), m_tournamentId(tournamentId),
          m_matchesPlayed(matchesPlayed), m_wins(wins), m_losses(losses),
          m_draws(draws), m_totalScore(totalScore), m_scoreAgainst(scoreAgainst),
          m_recentForm(form) {
        calculatePointsAndPercentage();
    }

    void calculatePointsAndPercentage() {
        // C++ Points Formula: Win = 3 pts, Draw = 1 pt, Loss = 0 pts
        m_points = (m_wins * 3) + (m_draws * 1);
        m_winPercentage = (m_matchesPlayed > 0)
            ? ((static_cast<double>(m_wins) + (0.5 * m_draws)) / m_matchesPlayed * 100.0)
            : 0.0;
    }

    // Getters
    int getRank() const { return m_rank; }
    int getTeamId() const { return m_teamId; }
    const std::string& getTeamName() const { return m_teamName; }
    const std::string& getTeamLogo() const { return m_teamLogo; }
    const std::string& getGameCategory() const { return m_gameCategory; }
    int getTournamentId() const { return m_tournamentId; }
    int getMatchesPlayed() const { return m_matchesPlayed; }
    int getWins() const { return m_wins; }
    int getLosses() const { return m_losses; }
    int getDraws() const { return m_draws; }
    int getPoints() const { return m_points; }
    int getTotalScore() const { return m_totalScore; }
    int getScoreAgainst() const { return m_scoreAgainst; }
    int getScoreDifference() const { return m_totalScore - m_scoreAgainst; }
    double getWinPercentage() const { return m_winPercentage; }
    const std::string& getRecentForm() const { return m_recentForm; }

    // Setters
    void setRank(int r) { m_rank = r; }
    void setTeamId(int id) { m_teamId = id; }
    void setTeamName(const std::string& n) { m_teamName = n; }
    void setTeamLogo(const std::string& l) { m_teamLogo = l; }
    void setGameCategory(const std::string& gc) { m_gameCategory = gc; }
    void setTournamentId(int tid) { m_tournamentId = tid; }
    void setMatchesPlayed(int mp) { m_matchesPlayed = mp; }
    void setWins(int w) { m_wins = w; }
    void setLosses(int l) { m_losses = l; }
    void setDraws(int d) { m_draws = d; }
    void setPoints(int p) { m_points = p; }
    void setTotalScore(int s) { m_totalScore = s; }
    void setScoreAgainst(int sa) { m_scoreAgainst = sa; }
    void setWinPercentage(double wp) { m_winPercentage = wp; }
    void setRecentForm(const std::string& rf) { m_recentForm = rf; }

    void addMatchResult(char outcome, int scored, int conceded) {
        m_matchesPlayed++;
        if (outcome == 'W') m_wins++;
        else if (outcome == 'D') m_draws++;
        else if (outcome == 'L') m_losses++;

        m_totalScore += scored;
        m_scoreAgainst += conceded;
        calculatePointsAndPercentage();

        // Update form queue (keep last 5 results)
        if (m_recentForm == "-----") m_recentForm = "";
        m_recentForm += outcome;
        if (m_recentForm.length() > 5) {
            m_recentForm = m_recentForm.substr(m_recentForm.length() - 5);
        }
    }
};

// C++ STL Ranking Comparator
inline bool compareLeaderboardEntries(const LeaderboardEntry& a, const LeaderboardEntry& b) {
    // 1. Points descending
    if (a.getPoints() != b.getPoints())
        return a.getPoints() > b.getPoints();

    // 2. Win percentage descending
    if (std::abs(a.getWinPercentage() - b.getWinPercentage()) > 0.001)
        return a.getWinPercentage() > b.getWinPercentage();

    // 3. Goal / Score Difference descending
    if (a.getScoreDifference() != b.getScoreDifference())
        return a.getScoreDifference() > b.getScoreDifference();

    // 4. Total Score descending
    if (a.getTotalScore() != b.getTotalScore())
        return a.getTotalScore() > b.getTotalScore();

    // 5. Matches won descending
    return a.getWins() > b.getWins();
}

} // namespace Esports

