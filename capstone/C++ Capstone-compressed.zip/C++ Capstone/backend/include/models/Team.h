#pragma once
#include <string>
#include <vector>
#include "Player.h"

namespace Esports {

struct TeamMemberInfo {
    int playerId;
    std::string playerName;
    std::string gameId;
    std::string playerRole;
    std::string roleInTeam;
    std::string joinedAt;
};

class Team {
private:
    int m_id;
    std::string m_teamCode;
    std::string m_name;
    std::string m_logoUrl;
    int m_captainId;
    std::string m_captainName;
    std::string m_gameCategory;
    std::string m_description;
    std::string m_invitationCode;
    int m_maxPlayers;
    std::string m_contactEmail;
    std::string m_contactPhone;
    std::string m_createdAt;
    std::vector<TeamMemberInfo> m_members;

    // Team stats calculated in C++
    int m_totalMatches;
    int m_wins;
    int m_losses;
    int m_draws;
    int m_points;
    int m_totalScore;
    double m_winPercentage;

public:
    Team()
        : m_id(0), m_captainId(0), m_maxPlayers(5),
          m_totalMatches(0), m_wins(0), m_losses(0), m_draws(0),
          m_points(0), m_totalScore(0), m_winPercentage(0.0),
          m_logoUrl("/assets/images/default-team.svg") {}

    Team(int id, const std::string& code, const std::string& name,
         const std::string& logo, int captainId, const std::string& captainName,
         const std::string& gameCategory, const std::string& desc,
         const std::string& invCode, int maxPlayers = 5,
         const std::string& email = "", const std::string& phone = "",
         const std::string& createdAt = "")
        : m_id(id), m_teamCode(code), m_name(name), m_logoUrl(logo),
          m_captainId(captainId), m_captainName(captainName),
          m_gameCategory(gameCategory), m_description(desc),
          m_invitationCode(invCode), m_maxPlayers(maxPlayers),
          m_contactEmail(email), m_contactPhone(phone),
          m_createdAt(createdAt), m_totalMatches(0), m_wins(0),
          m_losses(0), m_draws(0), m_points(0), m_totalScore(0),
          m_winPercentage(0.0) {}

    // Getters
    int getId() const { return m_id; }
    const std::string& getTeamCode() const { return m_teamCode; }
    const std::string& getName() const { return m_name; }
    const std::string& getLogoUrl() const { return m_logoUrl; }
    int getCaptainId() const { return m_captainId; }
    const std::string& getCaptainName() const { return m_captainName; }
    const std::string& getGameCategory() const { return m_gameCategory; }
    const std::string& getDescription() const { return m_description; }
    const std::string& getInvitationCode() const { return m_invitationCode; }
    int getMaxPlayers() const { return m_maxPlayers; }
    const std::string& getContactEmail() const { return m_contactEmail; }
    const std::string& getContactPhone() const { return m_contactPhone; }
    const std::string& getCreatedAt() const { return m_createdAt; }
    const std::vector<TeamMemberInfo>& getMembers() const { return m_members; }

    int getTotalMatches() const { return m_totalMatches; }
    int getWins() const { return m_wins; }
    int getLosses() const { return m_losses; }
    int getDraws() const { return m_draws; }
    int getPoints() const { return m_points; }
    int getTotalScore() const { return m_totalScore; }
    double getWinPercentage() const { return m_winPercentage; }

    // Setters
    void setId(int id) { m_id = id; }
    void setTeamCode(const std::string& c) { m_teamCode = c; }
    void setName(const std::string& n) { m_name = n; }
    void setLogoUrl(const std::string& l) { m_logoUrl = l; }
    void setCaptainId(int cid) { m_captainId = cid; }
    void setCaptainName(const std::string& cn) { m_captainName = cn; }
    void setGameCategory(const std::string& gc) { m_gameCategory = gc; }
    void setDescription(const std::string& d) { m_description = d; }
    void setInvitationCode(const std::string& ic) { m_invitationCode = ic; }
    void setMaxPlayers(int mp) { m_maxPlayers = mp; }
    void setContactEmail(const std::string& ce) { m_contactEmail = ce; }
    void setContactPhone(const std::string& cp) { m_contactPhone = cp; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }

    void setStats(int matches, int wins, int losses, int draws, int points, int score) {
        m_totalMatches = matches;
        m_wins = wins;
        m_losses = losses;
        m_draws = draws;
        m_points = points;
        m_totalScore = score;
        m_winPercentage = (matches > 0) ? (static_cast<double>(wins) / matches * 100.0) : 0.0;
    }

    void addMember(const TeamMemberInfo& member) {
        m_members.push_back(member);
    }

    void clearMembers() {
        m_members.clear();
    }
};

} // namespace Esports

