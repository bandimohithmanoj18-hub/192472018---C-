#pragma once
#include <string>
#include <memory>
#include <vector>

namespace Esports {

enum class UserRole {
    Admin,
    Captain,
    Player,
    Unknown
};

inline std::string roleToString(UserRole role) {
    switch (role) {
        case UserRole::Admin: return "admin";
        case UserRole::Captain: return "captain";
        case UserRole::Player: return "player";
        default: return "unknown";
    }
}

inline UserRole stringToRole(const std::string& roleStr) {
    if (roleStr == "admin") return UserRole::Admin;
    if (roleStr == "captain") return UserRole::Captain;
    if (roleStr == "player") return UserRole::Player;
    return UserRole::Unknown;
}

// Base User Class demonstrating OOP inheritance & encapsulation
class User {
protected:
    int m_id;
    std::string m_username;
    std::string m_email;
    std::string m_passwordHash;
    UserRole m_role;
    std::string m_fullName;
    std::string m_phoneNumber;
    std::string m_country;
    std::string m_avatarUrl;
    std::string m_createdAt;

public:
    User()
        : m_id(0), m_role(UserRole::Player), m_country("India"),
          m_avatarUrl("/assets/images/default-avatar.svg") {}

    User(int id, const std::string& username, const std::string& email,
         const std::string& passwordHash, UserRole role, const std::string& fullName,
         const std::string& phone = "", const std::string& country = "India",
         const std::string& avatar = "/assets/images/default-avatar.svg",
         const std::string& createdAt = "")
        : m_id(id), m_username(username), m_email(email),
          m_passwordHash(passwordHash), m_role(role), m_fullName(fullName),
          m_phoneNumber(phone), m_country(country), m_avatarUrl(avatar),
          m_createdAt(createdAt) {}

    virtual ~User() = default;

    // Getters
    int getId() const { return m_id; }
    const std::string& getUsername() const { return m_username; }
    const std::string& getEmail() const { return m_email; }
    const std::string& getPasswordHash() const { return m_passwordHash; }
    UserRole getRole() const { return m_role; }
    std::string getRoleString() const { return roleToString(m_role); }
    const std::string& getFullName() const { return m_fullName; }
    const std::string& getPhoneNumber() const { return m_phoneNumber; }
    const std::string& getCountry() const { return m_country; }
    const std::string& getAvatarUrl() const { return m_avatarUrl; }
    const std::string& getCreatedAt() const { return m_createdAt; }

    // Setters
    void setId(int id) { m_id = id; }
    void setUsername(const std::string& u) { m_username = u; }
    void setEmail(const std::string& e) { m_email = e; }
    void setPasswordHash(const std::string& p) { m_passwordHash = p; }
    void setRole(UserRole r) { m_role = r; }
    void setFullName(const std::string& fn) { m_fullName = fn; }
    void setPhoneNumber(const std::string& ph) { m_phoneNumber = ph; }
    void setCountry(const std::string& c) { m_country = c; }
    void setAvatarUrl(const std::string& av) { m_avatarUrl = av; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }

    // Polymorphic display / permissions
    virtual bool canManageTournaments() const { return false; }
    virtual bool canManageTeam() const { return false; }
    virtual bool canSubmitScores() const { return false; }
    virtual bool canVerifyScores() const { return false; }
    virtual bool canRaiseDisputes() const { return false; }
};

// Derived Admin Class
class Admin : public User {
public:
    Admin() : User() { m_role = UserRole::Admin; }
    Admin(int id, const std::string& username, const std::string& email,
          const std::string& passwordHash, const std::string& fullName,
          const std::string& phone = "", const std::string& country = "India")
        : User(id, username, email, passwordHash, UserRole::Admin, fullName, phone, country) {}

    bool canManageTournaments() const override { return true; }
    bool canManageTeam() const override { return true; }
    bool canSubmitScores() const override { return true; }
    bool canVerifyScores() const override { return true; }
    bool canRaiseDisputes() const override { return false; } // Admin resolves, does not raise
};

// Derived TeamCaptain Class
class TeamCaptain : public User {
private:
    int m_managedTeamId;

public:
    TeamCaptain() : User(), m_managedTeamId(0) { m_role = UserRole::Captain; }
    TeamCaptain(int id, const std::string& username, const std::string& email,
                const std::string& passwordHash, const std::string& fullName,
                int teamId = 0, const std::string& phone = "", const std::string& country = "India")
        : User(id, username, email, passwordHash, UserRole::Captain, fullName, phone, country),
          m_managedTeamId(teamId) {}

    int getManagedTeamId() const { return m_managedTeamId; }
    void setManagedTeamId(int id) { m_managedTeamId = id; }

    bool canManageTournaments() const override { return false; }
    bool canManageTeam() const override { return true; }
    bool canSubmitScores() const override { return true; }
    bool canVerifyScores() const override { return false; }
    virtual bool canRaiseDisputes() const override { return true; }
};

// Derived PlayerUser Class
class PlayerUser : public User {
private:
    int m_playerId;
    std::string m_gameId;
    std::string m_selectedGame;
    int m_teamId;

public:
    PlayerUser() : User(), m_playerId(0), m_teamId(0) { m_role = UserRole::Player; }
    PlayerUser(int id, const std::string& username, const std::string& email,
               const std::string& passwordHash, const std::string& fullName,
               const std::string& gameId, const std::string& selectedGame,
               int teamId = 0, const std::string& phone = "", const std::string& country = "India")
        : User(id, username, email, passwordHash, UserRole::Player, fullName, phone, country),
          m_playerId(0), m_gameId(gameId), m_selectedGame(selectedGame), m_teamId(teamId) {}

    int getPlayerId() const { return m_playerId; }
    void setPlayerId(int pid) { m_playerId = pid; }
    const std::string& getGameId() const { return m_gameId; }
    void setGameId(const std::string& gid) { m_gameId = gid; }
    const std::string& getSelectedGame() const { return m_selectedGame; }
    void setSelectedGame(const std::string& sg) { m_selectedGame = sg; }
    int getTeamId() const { return m_teamId; }
    void setTeamId(int tid) { m_teamId = tid; }

    bool canManageTournaments() const override { return false; }
    bool canManageTeam() const override { return false; }
    bool canSubmitScores() const override { return false; }
    bool canVerifyScores() const override { return false; }
    bool canRaiseDisputes() const override { return false; }
};

} // namespace Esports

