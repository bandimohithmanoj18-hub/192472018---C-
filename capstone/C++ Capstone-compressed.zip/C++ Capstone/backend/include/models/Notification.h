#pragma once
#include <string>

namespace Esports {

class Notification {
private:
    int m_id;
    int m_userId;
    std::string m_title;
    std::string m_message;
    std::string m_type; // 'registration', 'match', 'dispute', 'announcement', 'general'
    bool m_isRead;
    std::string m_linkUrl;
    std::string m_createdAt;

public:
    Notification()
        : m_id(0), m_userId(0), m_type("general"),
          m_isRead(false), m_linkUrl("#") {}

    Notification(int id, int userId, const std::string& title,
                 const std::string& message, const std::string& type = "general",
                 bool isRead = false, const std::string& linkUrl = "#",
                 const std::string& createdAt = "")
        : m_id(id), m_userId(userId), m_title(title),
          m_message(message), m_type(type), m_isRead(isRead),
          m_linkUrl(linkUrl), m_createdAt(createdAt) {}

    // Getters
    int getId() const { return m_id; }
    int getUserId() const { return m_userId; }
    const std::string& getTitle() const { return m_title; }
    const std::string& getMessage() const { return m_message; }
    const std::string& getType() const { return m_type; }
    bool isRead() const { return m_isRead; }
    const std::string& getLinkUrl() const { return m_linkUrl; }
    const std::string& getCreatedAt() const { return m_createdAt; }

    // Setters
    void setId(int id) { m_id = id; }
    void setUserId(int uid) { m_userId = uid; }
    void setTitle(const std::string& t) { m_title = t; }
    void setMessage(const std::string& m) { m_message = m; }
    void setType(const std::string& t) { m_type = t; }
    void setIsRead(bool r) { m_isRead = r; }
    void setLinkUrl(const std::string& u) { m_linkUrl = u; }
    void setCreatedAt(const std::string& ca) { m_createdAt = ca; }
};

} // namespace Esports

