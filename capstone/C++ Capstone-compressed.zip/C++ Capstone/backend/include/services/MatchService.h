#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class MatchService {
private:
    static std::shared_ptr<MatchService> s_instance;

public:
    MatchService();
    static std::shared_ptr<MatchService> getInstance();

    nlohmann::json getAllMatches(int tournamentId = 0, const std::string& status = "", const std::string& game = "");
    nlohmann::json getMatchById(int matchId);
    nlohmann::json scheduleMatch(int adminUserId, const nlohmann::json& payload);
    nlohmann::json updateSchedule(int matchId, int adminUserId, const std::string& scheduledTime, const std::string& slotInfo);
    nlohmann::json assignTeams(int matchId, int adminUserId, int teamAId, int teamBId);
    nlohmann::json getUpcomingMatches(int limit = 10);
    nlohmann::json getLiveMatches();
    nlohmann::json getMatchHistory(int teamId = 0, int limit = 20);
};

} // namespace Esports

