#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class DisputeService {
private:
    static std::shared_ptr<DisputeService> s_instance;

public:
    DisputeService();
    static std::shared_ptr<DisputeService> getInstance();

    nlohmann::json raiseDispute(int matchId, int captainUserId, const std::string& reason, const std::string& evidenceUrl);
    nlohmann::json getAllDisputes(const std::string& status = "");
    nlohmann::json getDisputeById(int disputeId);
    nlohmann::json getDisputesByTeam(int teamId);
    nlohmann::json resolveDispute(int disputeId, int adminUserId, const std::string& status, const std::string& adminNotes);
};

} // namespace Esports

