#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class PlayerService {
private:
    static std::shared_ptr<PlayerService> s_instance;

public:
    PlayerService();
    static std::shared_ptr<PlayerService> getInstance();

    nlohmann::json getAllPlayers(const std::string& game = "", const std::string& search = "", int limit = 50);
    nlohmann::json getPlayerById(int playerId);
    nlohmann::json getPlayerByUserId(int userId);
    nlohmann::json getPlayerStats(int playerId);
    nlohmann::json joinTeamWithInviteCode(int userId, const std::string& inviteCode);
    nlohmann::json leaveTeam(int userId);
    nlohmann::json updatePlayerProfile(int userId, const nlohmann::json& payload);
};

} // namespace Esports

