#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class NotificationService {
private:
    static std::shared_ptr<NotificationService> s_instance;

public:
    NotificationService();
    static std::shared_ptr<NotificationService> getInstance();

    bool sendNotification(int userId, const std::string& title, const std::string& message,
                          const std::string& type = "general", const std::string& linkUrl = "#");
    bool notifyTeam(int teamId, const std::string& title, const std::string& message,
                    const std::string& type = "team", const std::string& linkUrl = "#");
    bool notifyAllAdmins(const std::string& title, const std::string& message,
                         const std::string& type = "admin", const std::string& linkUrl = "#");
    bool notifyTournamentParticipants(int tournamentId, const std::string& title,
                                      const std::string& message, const std::string& type = "tournament");

    nlohmann::json getUserNotifications(int userId, bool unreadOnly = false, int limit = 30);
    bool markAsRead(int notificationId, int userId);
    bool markAllAsRead(int userId);
};

} // namespace Esports

