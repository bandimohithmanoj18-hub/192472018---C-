#pragma once
#include <string>
#include <vector>
#include <functional>
#include <memory>
#include <mutex>
#include "../third_party/sqlite3.h"
#include "../third_party/json.hpp"

namespace Esports {

class DatabaseService {
private:
    sqlite3* m_db;
    std::string m_dbPath;
    std::mutex m_mutex;
    static std::shared_ptr<DatabaseService> s_instance;

public:
    DatabaseService();
    ~DatabaseService();

    static std::shared_ptr<DatabaseService> getInstance();

    bool initialize(const std::string& dbPath = "database/esports_arena.db");
    void close();

    sqlite3* getDb() { return m_db; }
    std::mutex& getMutex() { return m_mutex; }

    bool execute(const std::string& sql);
    int executeInsert(const std::string& sql, const std::vector<std::string>& params = {});
    bool executeUpdate(const std::string& sql, const std::vector<std::string>& params = {});
    nlohmann::json queryJson(const std::string& sql, const std::vector<std::string>& params = {});

    bool runMigrations();
    bool seedDemoData();

    void logActivity(int userId, const std::string& action, const std::string& details, const std::string& ip = "127.0.0.1");
};

} // namespace Esports

