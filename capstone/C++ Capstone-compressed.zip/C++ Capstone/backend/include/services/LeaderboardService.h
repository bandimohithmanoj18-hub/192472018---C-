#pragma once
#include <string>
#include <memory>
#include <vector>
#include "../third_party/json.hpp"
#include "../models/Leaderboard.h"

namespace Esports {

class LeaderboardService {
private:
    static std::shared_ptr<LeaderboardService> s_instance;

public:
    LeaderboardService();
    static std::shared_ptr<LeaderboardService> getInstance();

    // Recalculates all leaderboards from match records using C++ sorting & scoring
    bool recalculateLeaderboard(int tournamentId = 0);

    nlohmann::json getGlobalLeaderboard(const std::string& gameCategory = "", int limit = 20);
    nlohmann::json getTournamentLeaderboard(int tournamentId);
    nlohmann::json getTopThreeTeams(const std::string& gameCategory = "");
    nlohmann::json getPlayerRankings(const std::string& gameCategory = "", int limit = 20);
};

} // namespace Esports

