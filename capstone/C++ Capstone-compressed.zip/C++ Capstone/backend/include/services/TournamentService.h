#pragma once
#include <string>
#include <memory>
#include <vector>
#include "../third_party/json.hpp"
#include "../models/Tournament.h"

namespace Esports {

class TournamentService {
private:
    static std::shared_ptr<TournamentService> s_instance;

public:
    TournamentService();
    static std::shared_ptr<TournamentService> getInstance();

    nlohmann::json getAllTournaments(const std::string& game = "", const std::string& status = "", const std::string& search = "");
    nlohmann::json getTournamentById(int tournamentId);
    nlohmann::json createTournament(int adminUserId, const nlohmann::json& payload);
    nlohmann::json updateTournament(int tournamentId, const nlohmann::json& payload);
    nlohmann::json deleteTournament(int tournamentId);

    // Registration workflow
    nlohmann::json registerTeamForTournament(int tournamentId, int teamId, int captainUserId);
    nlohmann::json getTournamentRegistrations(int tournamentId);
    nlohmann::json updateRegistrationStatus(int registrationId, int adminUserId, const std::string& status, const std::string& notes);

    // Bracket & Match generation algorithms implemented in C++
    nlohmann::json generateBracket(int tournamentId, int adminUserId);
    nlohmann::json getTournamentBracket(int tournamentId);
    bool advanceWinnerToNextRound(int matchId, int winnerTeamId);

    // Reports & Analytics
    nlohmann::json getTournamentReport(int tournamentId);
    nlohmann::json getPlatformAnalytics();
};

} // namespace Esports

