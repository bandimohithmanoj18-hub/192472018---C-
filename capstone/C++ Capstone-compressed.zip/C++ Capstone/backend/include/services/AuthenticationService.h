#pragma once
#include <string>
#include <memory>
#include <unordered_map>
#include <mutex>
#include "../models/User.h"
#include "../third_party/json.hpp"

namespace Esports {

struct SessionInfo {
    int userId;
    std::string username;
    std::string role;
    std::string expiresAt;
};

class AuthenticationService {
private:
    std::unordered_map<std::string, SessionInfo> m_sessions;
    std::mutex m_sessionMutex;
    static std::shared_ptr<AuthenticationService> s_instance;

public:
    AuthenticationService();
    static std::shared_ptr<AuthenticationService> getInstance();

    // Password hashing
    static std::string hashPassword(const std::string& password);
    static bool verifyPassword(const std::string& password, const std::string& hash);

    // Session management
    std::string createSession(int userId, const std::string& username, const std::string& role);
    bool validateSession(const std::string& token, SessionInfo& outSession);
    void invalidateSession(const std::string& token);

    // Authentication workflows
    nlohmann::json login(const std::string& usernameOrEmail, const std::string& password);
    nlohmann::json registerPlayer(const nlohmann::json& payload);
    nlohmann::json registerCaptain(const nlohmann::json& payload);
    nlohmann::json getCurrentUser(const std::string& token);
    nlohmann::json updateProfile(int userId, const nlohmann::json& payload);
    nlohmann::json changePassword(int userId, const std::string& oldPass, const std::string& newPass);

    // Authorization checks
    bool requireRole(const std::string& token, const std::string& requiredRole, SessionInfo& outSession);
};

} // namespace Esports

