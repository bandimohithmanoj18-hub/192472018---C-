#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class ScoreService {
private:
    static std::shared_ptr<ScoreService> s_instance;

public:
    ScoreService();
    static std::shared_ptr<ScoreService> getInstance();

    nlohmann::json submitScore(int matchId, int userId, int teamAScore, int teamBScore,
                               const std::string& notes, int mvpPlayerId = 0);
    nlohmann::json updateLiveScore(int matchId, int adminUserId, int teamAScore, int teamBScore, const std::string& status);
    nlohmann::json verifyResult(int matchId, int adminUserId, bool approve, int overrideTeamAScore = -1, int overrideTeamBScore = -1, int overrideMvpId = 0);
    nlohmann::json getScoreboard(int matchId);
    nlohmann::json getLiveScoreboard();
};

} // namespace Esports

