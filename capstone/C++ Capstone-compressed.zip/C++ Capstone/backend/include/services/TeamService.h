#pragma once
#include <string>
#include <memory>
#include "../third_party/json.hpp"

namespace Esports {

class TeamService {
private:
    static std::shared_ptr<TeamService> s_instance;

public:
    TeamService();
    static std::shared_ptr<TeamService> getInstance();

    nlohmann::json registerTeam(int captainUserId, const nlohmann::json& payload);
    nlohmann::json getAllTeams(const std::string& game = "", const std::string& search = "");
    nlohmann::json getTeamById(int teamId);
    nlohmann::json getTeamByCaptainId(int captainUserId);
    nlohmann::json updateTeam(int teamId, int captainUserId, const nlohmann::json& payload, bool isAdmin = false);
    nlohmann::json addTeamMember(int teamId, int playerId, const std::string& roleInTeam = "Starter");
    nlohmann::json removeTeamMember(int teamId, int playerId, int requestUserId);
    nlohmann::json getTeamTournaments(int teamId);
    nlohmann::json getTeamMatches(int teamId);
};

} // namespace Esports

