/**
 * ============================================================================
 * ESPORTS ARENA — C++ Backend Server
 * Technology: cpp-httplib (single-header), nlohmann/json, SQLite3
 * OOP Architecture: Services, Models, Inheritance, STL containers
 * ============================================================================
 */
#include <exception>
#include "include/third_party/httplib.h"
#include "include/third_party/json.hpp"
#include "include/third_party/sqlite3.h"

// Services
#include "include/services/DatabaseService.h"
#include "include/services/AuthenticationService.h"
#include "include/services/PlayerService.h"
#include "include/services/TeamService.h"
#include "include/services/TournamentService.h"
#include "include/services/MatchService.h"
#include "include/services/ScoreService.h"
#include "include/services/LeaderboardService.h"
#include "include/services/NotificationService.h"
#include "include/services/DisputeService.h"

// SQLite3 is compiled separately as C (sqlite3.o) and linked

#include <iostream>
#include <fstream>
#include <filesystem>
#include <functional>

using json = nlohmann::json;
namespace fs = std::filesystem;

// ─── Helpers ────────────────────────────────────────────────────────────────

static void addCORS(httplib::Response& res) {
    res.set_header("Access-Control-Allow-Origin", "*");
    res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.set_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Auth-Token");
}

static void jsonResponse(httplib::Response& res, const json& body, int status = 200) {
    addCORS(res);
    res.status = status;
    res.set_content(body.dump(), "application/json");
}

static std::string getToken(const httplib::Request& req) {
    std::string authHeader = req.get_header_value("Authorization");
    if (authHeader.substr(0, 7) == "Bearer ") return authHeader.substr(7);
    return req.get_header_value("X-Auth-Token");
}

static std::string queryParam(const httplib::Request& req, const std::string& key, const std::string& def = "") {
    if (req.has_param(key)) return req.get_param_value(key);
    return def;
}

static bool requireAuth(const httplib::Request& req, httplib::Response& res,
                         Esports::SessionInfo& session, const std::string& role = "") {
    auto auth = Esports::AuthenticationService::getInstance();
    std::string tok = getToken(req);
    if (!auth->requireRole(tok, role, session)) {
        jsonResponse(res, {{"success", false}, {"message", "Unauthorized. Please login."}}, 401);
        return false;
    }
    return true;
}

// ─── Main ───────────────────────────────────────────────────────────────────

int main(int argc, char** argv) {
    std::cout << "\n";
    std::cout << "  ███████╗███████╗██████╗  ██████╗ ██████╗ ████████╗███████╗     █████╗ ██████╗ ███████╗███╗   ██╗ █████╗ \n";
    std::cout << "  ██╔════╝██╔════╝██╔══██╗██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝   ██╔══██╗██╔══██╗██╔════╝████╗  ██║██╔══██╗\n";
    std::cout << "  █████╗  ███████╗██████╔╝██║   ██║██████╔╝   ██║   ███████╗   ███████║██████╔╝█████╗  ██╔██╗ ██║███████║\n";
    std::cout << "  ██╔══╝  ╚════██║██╔═══╝ ██║   ██║██╔══██╗   ██║   ╚════██║   ██╔══██║██╔══██╗██╔══╝  ██║╚██╗██║██╔══██║\n";
    std::cout << "  ███████╗███████║██║     ╚██████╔╝██║  ██║   ██║   ███████║   ██║  ██║██║  ██║███████╗██║ ╚████║██║  ██║\n";
    std::cout << "  ╚══════╝╚══════╝╚═╝      ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝\n";
    std::cout << "\n  == Esports Tournament Management System | C++ REST API Backend ==\n\n";

    // ── Database init ──
    auto db = Esports::DatabaseService::getInstance();
    if (!db->initialize("database/esports_arena.db")) {
        std::cerr << "FATAL: Failed to initialize database. Exiting.\n";
        return 1;
    }
    if (!db->runMigrations()) {
        std::cerr << "FATAL: Migration failed.\n";
        return 1;
    }
    db->seedDemoData();

    // ── Services ──
    auto authSvc   = Esports::AuthenticationService::getInstance();
    auto playerSvc = Esports::PlayerService::getInstance();
    auto teamSvc   = Esports::TeamService::getInstance();
    auto tournSvc  = Esports::TournamentService::getInstance();
    auto matchSvc  = Esports::MatchService::getInstance();
    auto scoreSvc  = Esports::ScoreService::getInstance();
    auto lbSvc     = Esports::LeaderboardService::getInstance();
    auto notifSvc  = Esports::NotificationService::getInstance();
    auto dispSvc   = Esports::DisputeService::getInstance();

    httplib::Server svr;

    // ── Static file serving (frontend) ──────────────────────────────────────
    svr.set_mount_point("/", "frontend/");
    svr.set_mount_point("/assets", "assets/");

    // ── CORS preflight ──
    svr.Options(".*", [](const httplib::Request&, httplib::Response& res) {
        addCORS(res);
        res.status = 204;
    });

    // ════════════════════════════════════════════════════════════════════════
    // AUTH ROUTES
    // ════════════════════════════════════════════════════════════════════════

    // POST /api/auth/login
    svr.Post("/api/auth/login", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            auto body = json::parse(req.body);
            auto result = authSvc->login(body.value("username", ""), body.value("password", ""));
            jsonResponse(res, result);
        } catch (...) { jsonResponse(res, {{"success",false},{"message","Invalid JSON"}}, 400); }
    });

    // POST /api/auth/register/player
    svr.Post("/api/auth/register/player", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, authSvc->registerPlayer(body));
        } catch (...) { jsonResponse(res, {{"success",false},{"message","Invalid JSON"}}, 400); }
    });

    // POST /api/auth/register/captain
    svr.Post("/api/auth/register/captain", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, authSvc->registerCaptain(body));
        } catch (...) { jsonResponse(res, {{"success",false},{"message","Invalid JSON"}}, 400); }
    });

    // GET /api/auth/me
    svr.Get("/api/auth/me", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, authSvc->getCurrentUser(getToken(req)));
    });

    // POST /api/auth/logout
    svr.Post("/api/auth/logout", [&](const httplib::Request& req, httplib::Response& res) {
        authSvc->invalidateSession(getToken(req));
        jsonResponse(res, {{"success",true},{"message","Logged out successfully"}});
    });

    // PUT /api/auth/profile
    svr.Put("/api/auth/profile", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try { jsonResponse(res, authSvc->updateProfile(s.userId, json::parse(req.body))); }
        catch(...) { jsonResponse(res, {{"success",false},{"message","Invalid JSON"}}, 400); }
    });

    // PUT /api/auth/change-password
    svr.Put("/api/auth/change-password", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, authSvc->changePassword(s.userId, body.value("oldPassword",""), body.value("newPassword","")));
        } catch(...) { jsonResponse(res, {{"success",false},{"message","Invalid JSON"}}, 400); }
    });

    // ════════════════════════════════════════════════════════════════════════
    // PLAYER ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/players", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, playerSvc->getAllPlayers(queryParam(req,"game"), queryParam(req,"search")));
    });
    svr.Get("/api/players/me", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        jsonResponse(res, playerSvc->getPlayerByUserId(s.userId));
    });
    svr.Get("/api/players/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, playerSvc->getPlayerById(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/players/join-team", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"player")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, playerSvc->joinTeamWithInviteCode(s.userId, body.value("inviteCode","")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Post("/api/players/leave-team", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"player")) return;
        jsonResponse(res, playerSvc->leaveTeam(s.userId));
    });
    svr.Put("/api/players/me", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try { jsonResponse(res, playerSvc->updatePlayerProfile(s.userId, json::parse(req.body))); }
        catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });

    // ════════════════════════════════════════════════════════════════════════
    // TEAM ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/teams", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, teamSvc->getAllTeams(queryParam(req,"game"), queryParam(req,"search")));
    });
    svr.Get("/api/teams/my", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        jsonResponse(res, teamSvc->getTeamByCaptainId(s.userId));
    });
    svr.Get("/api/teams/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, teamSvc->getTeamById(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/teams", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"captain")) return;
        try { jsonResponse(res, teamSvc->registerTeam(s.userId, json::parse(req.body))); }
        catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/teams/:id", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try {
            int tid = std::stoi(req.path_params.at("id"));
            bool isAdmin = (s.role == "admin");
            jsonResponse(res, teamSvc->updateTeam(tid, s.userId, json::parse(req.body), isAdmin));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Get("/api/teams/:id/tournaments", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, teamSvc->getTeamTournaments(std::stoi(req.path_params.at("id"))));
    });
    svr.Get("/api/teams/:id/matches", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, teamSvc->getTeamMatches(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/teams/:id/members", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try {
            auto body = json::parse(req.body);
            int tid = std::stoi(req.path_params.at("id"));
            jsonResponse(res, teamSvc->addTeamMember(tid, body.value("playerId",0), body.value("roleInTeam","Starter")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Delete("/api/teams/:tid/members/:pid", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        int tid = std::stoi(req.path_params.at("tid"));
        int pid = std::stoi(req.path_params.at("pid"));
        jsonResponse(res, teamSvc->removeTeamMember(tid, pid, s.userId));
    });

    // ════════════════════════════════════════════════════════════════════════
    // TOURNAMENT ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/tournaments", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, tournSvc->getAllTournaments(queryParam(req,"game"), queryParam(req,"status"), queryParam(req,"search")));
    });
    svr.Get("/api/tournaments/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, tournSvc->getTournamentById(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/tournaments", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try { jsonResponse(res, tournSvc->createTournament(s.userId, json::parse(req.body))); }
        catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/tournaments/:id", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try { jsonResponse(res, tournSvc->updateTournament(std::stoi(req.path_params.at("id")), json::parse(req.body))); }
        catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Delete("/api/tournaments/:id", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        jsonResponse(res, tournSvc->deleteTournament(std::stoi(req.path_params.at("id"))));
    });
    svr.Get("/api/tournaments/:id/registrations", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, tournSvc->getTournamentRegistrations(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/tournaments/:id/register", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try {
            auto body = json::parse(req.body);
            int tid = std::stoi(req.path_params.at("id"));
            int teamId = body.value("teamId", 0);
            int captainId = (s.role == "admin") ? 0 : s.userId;
            jsonResponse(res, tournSvc->registerTeamForTournament(tid, teamId, captainId));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/registrations/:id", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            int regId = std::stoi(req.path_params.at("id"));
            jsonResponse(res, tournSvc->updateRegistrationStatus(regId, s.userId, body.value("status","Approved"), body.value("notes","")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Post("/api/tournaments/:id/generate-bracket", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        jsonResponse(res, tournSvc->generateBracket(std::stoi(req.path_params.at("id")), s.userId));
    });
    svr.Get("/api/tournaments/:id/bracket", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, tournSvc->getTournamentBracket(std::stoi(req.path_params.at("id"))));
    });
    svr.Get("/api/tournaments/:id/report", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        jsonResponse(res, tournSvc->getTournamentReport(std::stoi(req.path_params.at("id"))));
    });

    // ════════════════════════════════════════════════════════════════════════
    // MATCH ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/matches", [&](const httplib::Request& req, httplib::Response& res) {
        int tId = queryParam(req,"tournamentId").empty() ? 0 : std::stoi(queryParam(req,"tournamentId"));
        jsonResponse(res, matchSvc->getAllMatches(tId, queryParam(req,"status"), queryParam(req,"game")));
    });
    svr.Get("/api/matches/upcoming", [&](const httplib::Request& req, httplib::Response& res) {
        int limit = queryParam(req,"limit").empty() ? 10 : std::stoi(queryParam(req,"limit"));
        jsonResponse(res, matchSvc->getUpcomingMatches(limit));
    });
    svr.Get("/api/matches/live", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, matchSvc->getLiveMatches());
    });
    svr.Get("/api/matches/history", [&](const httplib::Request& req, httplib::Response& res) {
        int teamId = queryParam(req,"teamId").empty() ? 0 : std::stoi(queryParam(req,"teamId"));
        int limit = queryParam(req,"limit").empty() ? 20 : std::stoi(queryParam(req,"limit"));
        jsonResponse(res, matchSvc->getMatchHistory(teamId, limit));
    });
    svr.Get("/api/matches/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, matchSvc->getMatchById(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/matches", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try { jsonResponse(res, matchSvc->scheduleMatch(s.userId, json::parse(req.body))); }
        catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/matches/:id/schedule", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, matchSvc->updateSchedule(std::stoi(req.path_params.at("id")), s.userId,
                body.value("scheduledTime",""), body.value("slotInfo","")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/matches/:id/teams", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, matchSvc->assignTeams(std::stoi(req.path_params.at("id")), s.userId,
                body.value("teamAId",0), body.value("teamBId",0)));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });

    // ════════════════════════════════════════════════════════════════════════
    // SCORE / SCOREBOARD ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/scoreboard/live", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, scoreSvc->getLiveScoreboard());
    });
    svr.Get("/api/scoreboard/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, scoreSvc->getScoreboard(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/matches/:id/submit-score", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, scoreSvc->submitScore(std::stoi(req.path_params.at("id")), s.userId,
                body.value("teamAScore",0), body.value("teamBScore",0),
                body.value("notes",""), body.value("mvpPlayerId",0)));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/matches/:id/live-score", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, scoreSvc->updateLiveScore(std::stoi(req.path_params.at("id")), s.userId,
                body.value("teamAScore",0), body.value("teamBScore",0), body.value("status","Live")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Post("/api/matches/:id/verify", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            bool approve = body.value("approve", true);
            int oA = body.value("overrideTeamAScore", -1);
            int oB = body.value("overrideTeamBScore", -1);
            int oMvp = body.value("overrideMvpId", 0);
            jsonResponse(res, scoreSvc->verifyResult(std::stoi(req.path_params.at("id")), s.userId, approve, oA, oB, oMvp));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });

    // ════════════════════════════════════════════════════════════════════════
    // LEADERBOARD ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/leaderboard", [&](const httplib::Request& req, httplib::Response& res) {
        int limit = queryParam(req,"limit").empty() ? 20 : std::stoi(queryParam(req,"limit"));
        jsonResponse(res, lbSvc->getGlobalLeaderboard(queryParam(req,"game"), limit));
    });
    svr.Get("/api/leaderboard/top3", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, lbSvc->getTopThreeTeams(queryParam(req,"game")));
    });
    svr.Get("/api/leaderboard/players", [&](const httplib::Request& req, httplib::Response& res) {
        int limit = queryParam(req,"limit").empty() ? 20 : std::stoi(queryParam(req,"limit"));
        jsonResponse(res, lbSvc->getPlayerRankings(queryParam(req,"game"), limit));
    });
    svr.Get("/api/leaderboard/tournament/:id", [&](const httplib::Request& req, httplib::Response& res) {
        jsonResponse(res, lbSvc->getTournamentLeaderboard(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/leaderboard/recalculate", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        int tId = queryParam(req,"tournamentId").empty() ? 0 : std::stoi(queryParam(req,"tournamentId"));
        bool ok = lbSvc->recalculateLeaderboard(tId);
        jsonResponse(res, {{"success",ok},{"message",ok ? "Leaderboard recalculated." : "Failed to recalculate."}});
    });

    // ════════════════════════════════════════════════════════════════════════
    // NOTIFICATION ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/notifications", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        bool unreadOnly = queryParam(req,"unread") == "true";
        int limit = queryParam(req,"limit").empty() ? 30 : std::stoi(queryParam(req,"limit"));
        jsonResponse(res, notifSvc->getUserNotifications(s.userId, unreadOnly, limit));
    });
    svr.Put("/api/notifications/:id/read", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        bool ok = notifSvc->markAsRead(std::stoi(req.path_params.at("id")), s.userId);
        jsonResponse(res, {{"success",ok},{"message",ok?"Marked as read.":"Not found."}});
    });
    svr.Put("/api/notifications/read-all", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        notifSvc->markAllAsRead(s.userId);
        jsonResponse(res, {{"success",true},{"message","All notifications marked as read."}});
    });

    // ════════════════════════════════════════════════════════════════════════
    // DISPUTE ROUTES
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/disputes", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        jsonResponse(res, dispSvc->getAllDisputes(queryParam(req,"status")));
    });
    svr.Get("/api/disputes/:id", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        jsonResponse(res, dispSvc->getDisputeById(std::stoi(req.path_params.at("id"))));
    });
    svr.Get("/api/teams/:id/disputes", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s)) return;
        jsonResponse(res, dispSvc->getDisputesByTeam(std::stoi(req.path_params.at("id"))));
    });
    svr.Post("/api/matches/:id/dispute", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"captain")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, dispSvc->raiseDispute(std::stoi(req.path_params.at("id")), s.userId,
                body.value("reason",""), body.value("evidenceUrl","")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });
    svr.Put("/api/disputes/:id/resolve", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        try {
            auto body = json::parse(req.body);
            jsonResponse(res, dispSvc->resolveDispute(std::stoi(req.path_params.at("id")), s.userId,
                body.value("status","Resolved"), body.value("adminNotes","")));
        } catch(...) { jsonResponse(res,{{"success",false},{"message","Invalid JSON"}},400); }
    });

    // ════════════════════════════════════════════════════════════════════════
    // ADMIN ANALYTICS
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/admin/analytics", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        jsonResponse(res, tournSvc->getPlatformAnalytics());
    });
    svr.Get("/api/admin/activity-logs", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        int limit = queryParam(req,"limit").empty() ? 50 : std::stoi(queryParam(req,"limit"));
        auto logs = db->queryJson(
            "SELECT a.*, u.username, u.role FROM activity_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT ?",
            {std::to_string(limit)}
        );
        jsonResponse(res, logs);
    });
    svr.Get("/api/admin/users", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        std::string role = queryParam(req,"role");
        std::string sql = "SELECT id, username, email, role, full_name, country, avatar_url, created_at FROM users ";
        std::vector<std::string> params;
        if (!role.empty()) { sql += "WHERE role = ? "; params.push_back(role); }
        sql += "ORDER BY created_at DESC";
        jsonResponse(res, db->queryJson(sql, params));
    });
    svr.Get("/api/admin/registrations", [&](const httplib::Request& req, httplib::Response& res) {
        Esports::SessionInfo s; if (!requireAuth(req,res,s,"admin")) return;
        std::string sql =
            "SELECT tr.*, t.name as tournament_name, t.game_category, tm.name as team_name, tm.logo_url as team_logo, "
            "u.full_name as captain_name, u.email as captain_email "
            "FROM tournament_registrations tr "
            "JOIN tournaments t ON tr.tournament_id = t.id "
            "JOIN teams tm ON tr.team_id = tm.id "
            "LEFT JOIN users u ON tm.captain_id = u.id "
            "ORDER BY tr.registered_at DESC";
        jsonResponse(res, db->queryJson(sql));
    });

    // ════════════════════════════════════════════════════════════════════════
    // HEALTH CHECK
    // ════════════════════════════════════════════════════════════════════════

    svr.Get("/api/health", [](const httplib::Request&, httplib::Response& res) {
        addCORS(res);
        res.set_content(json({{"status","ok"},{"server","Esports Arena C++ Backend"},{"version","1.0.0"}}).dump(), "application/json");
    });

    // ── Custom 404 Not Found Handler ─────────────────────────────────────────
    svr.set_error_handler([](const httplib::Request& req, httplib::Response& res) {
        if (res.status == 404) {
            addCORS(res);
            if (req.path.rfind("/api/", 0) == 0) {
                res.set_content(json({{"success", false}, {"message", "API endpoint not found: " + req.path}}).dump(), "application/json");
            } else {
                std::ifstream f("frontend/404.html");
                if (f.good()) {
                    std::string content((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
                    res.set_content(content, "text/html");
                } else {
                    res.set_content("<h1>404 Not Found — Esports Arena</h1><p>The requested page was not found.</p><a href='/index.html'>Return Home</a>", "text/html");
                }
            }
        }
    });

    // ── Launch ──
    int port = (argc > 1) ? std::stoi(argv[1]) : 8080;
    std::cout << "  >> Backend server running at:  http://localhost:" << port << "\n";
    std::cout << "  >> API documentation at:       http://localhost:" << port << "/api/health\n";
    std::cout << "  >> Open frontend at:           http://localhost:" << port << "/index.html\n\n";
    std::cout << "  Demo credentials:\n";
    std::cout << "     Admin   → admin / Admin@123\n";
    std::cout << "     Captain → shahzam / Captain@123\n";
    std::cout << "     Player  → tenz / Player@123\n\n";

    if (!svr.listen("0.0.0.0", port)) {
        std::cerr << "FATAL: Could not bind to port " << port << std::endl;
        return 1;
    }
    return 0;
}

