#include "../include/services/ScoreService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/LeaderboardService.h"
#include "../include/services/NotificationService.h"
#include "../include/services/TournamentService.h"

namespace Esports {

std::shared_ptr<ScoreService> ScoreService::s_instance = nullptr;
ScoreService::ScoreService() {}
std::shared_ptr<ScoreService> ScoreService::getInstance() {
    if (!s_instance) s_instance = std::make_shared<ScoreService>();
    return s_instance;
}

nlohmann::json ScoreService::submitScore(int matchId, int userId, int teamAScore, int teamBScore,
                                         const std::string& notes, int mvpPlayerId) {
    auto db = DatabaseService::getInstance();
    auto mRows = db->queryJson("SELECT * FROM matches WHERE id = ?", {std::to_string(matchId)});
    if (mRows.empty()) return {{"success", false}, {"message", "Match not found."}};

    std::string curStatus = mRows[0].value("status", "");
    if (curStatus == "Completed") {
        return {{"success", false}, {"message", "This match result has already been verified and locked."}};
    }

    // C++ winner determination logic
    int winnerTeamId = 0;
    if (teamAScore > teamBScore) winnerTeamId = static_cast<int>(mRows[0]["team_a_id"].get<int64_t>());
    else if (teamBScore > teamAScore) winnerTeamId = static_cast<int>(mRows[0]["team_b_id"].get<int64_t>());

    db->executeUpdate(
        "UPDATE matches SET team_a_score = ?, team_b_score = ?, winner_team_id = ?, "
        "mvp_player_id = ?, submitted_by = ?, submission_notes = ?, status = 'Under Review' WHERE id = ?",
        {std::to_string(teamAScore), std::to_string(teamBScore),
         winnerTeamId > 0 ? std::to_string(winnerTeamId) : "NULL",
         mvpPlayerId > 0 ? std::to_string(mvpPlayerId) : "NULL",
         std::to_string(userId), notes, std::to_string(matchId)}
    );

    db->executeInsert("INSERT INTO match_results (match_id, round_details) VALUES (?, ?)",
                      {std::to_string(matchId), notes});

    auto notif = NotificationService::getInstance();
    notif->notifyAllAdmins("Score Submitted for Review",
        "Match #" + std::to_string(matchId) + " score (" + std::to_string(teamAScore) + " - " + std::to_string(teamBScore) + ") submitted. Please verify.",
        "match", "/admin-dashboard.html");

    db->logActivity(userId, "SUBMIT_SCORE", "Score submitted for match #" + std::to_string(matchId));
    return {{"success", true}, {"message", "Score submitted. Awaiting admin verification."}};
}

nlohmann::json ScoreService::updateLiveScore(int matchId, int adminUserId, int teamAScore, int teamBScore, const std::string& status) {
    auto db = DatabaseService::getInstance();
    db->executeUpdate("UPDATE matches SET team_a_score = ?, team_b_score = ?, status = ? WHERE id = ?",
                      {std::to_string(teamAScore), std::to_string(teamBScore), status, std::to_string(matchId)});
    db->logActivity(adminUserId, "UPDATE_LIVE_SCORE", "Live score updated for match #" + std::to_string(matchId) + ": " + std::to_string(teamAScore) + "-" + std::to_string(teamBScore));
    return {{"success", true}, {"message", "Live score updated."}};
}

nlohmann::json ScoreService::verifyResult(int matchId, int adminUserId, bool approve,
                                          int overrideTeamAScore, int overrideTeamBScore, int overrideMvpId) {
    auto db = DatabaseService::getInstance();
    auto mRows = db->queryJson("SELECT * FROM matches WHERE id = ?", {std::to_string(matchId)});
    if (mRows.empty()) return {{"success", false}, {"message", "Match not found."}};

    auto match = mRows[0];

    if (!approve) {
        db->executeUpdate("UPDATE matches SET status = 'Upcoming', is_verified = 0 WHERE id = ?", {std::to_string(matchId)});
        return {{"success", true}, {"message", "Result rejected. Match reset to Upcoming status."}};
    }

    // Apply override scores if provided
    int finalA = (overrideTeamAScore >= 0) ? overrideTeamAScore : static_cast<int>(match["team_a_score"].get<int64_t>());
    int finalB = (overrideTeamBScore >= 0) ? overrideTeamBScore : static_cast<int>(match["team_b_score"].get<int64_t>());

    // C++ winner calculation
    int winnerTeamId = 0;
    if (finalA > finalB) winnerTeamId = static_cast<int>(match["team_a_id"].get<int64_t>());
    else if (finalB > finalA) winnerTeamId = static_cast<int>(match["team_b_id"].get<int64_t>());

    int mvpId = (overrideMvpId > 0) ? overrideMvpId : (!match["mvp_player_id"].is_null() ? static_cast<int>(match["mvp_player_id"].get<int64_t>()) : 0);

    db->executeUpdate(
        "UPDATE matches SET team_a_score = ?, team_b_score = ?, winner_team_id = ?, "
        "mvp_player_id = ?, status = 'Completed', is_verified = 1, verified_by = ? WHERE id = ?",
        {std::to_string(finalA), std::to_string(finalB),
         winnerTeamId > 0 ? std::to_string(winnerTeamId) : "NULL",
         mvpId > 0 ? std::to_string(mvpId) : "NULL",
         std::to_string(adminUserId), std::to_string(matchId)}
    );

    int teamAId = static_cast<int>(match["team_a_id"].get<int64_t>());
    int teamBId = static_cast<int>(match["team_b_id"].get<int64_t>());
    int tournamentId = static_cast<int>(match["tournament_id"].get<int64_t>());

    // Update player match records
    auto tAPlayers = db->queryJson("SELECT player_id FROM team_members WHERE team_id = ?", {std::to_string(teamAId)});
    auto tBPlayers = db->queryJson("SELECT player_id FROM team_members WHERE team_id = ?", {std::to_string(teamBId)});

    for (const auto& p : tAPlayers) {
        int pid = static_cast<int>(p["player_id"].get<int64_t>());
        bool pWon = (winnerTeamId == teamAId);
        bool isMvp = (mvpId > 0 && pid == mvpId);
        std::string matchesWonSql = pWon ? "matches_won = matches_won + 1," : "";
        std::string mvpSql = isMvp ? "mvp_awards = mvp_awards + 1," : "";
        db->executeUpdate("UPDATE players SET matches_played = matches_played + 1, " + matchesWonSql + mvpSql + " matches_lost = matches_lost + ? WHERE id = ?",
                          {pWon ? "0" : "1", std::to_string(pid)});
    }
    for (const auto& p : tBPlayers) {
        int pid = static_cast<int>(p["player_id"].get<int64_t>());
        bool pWon = (winnerTeamId == teamBId);
        bool isMvp = (mvpId > 0 && pid == mvpId);
        std::string matchesWonSql = pWon ? "matches_won = matches_won + 1," : "";
        std::string mvpSql = isMvp ? "mvp_awards = mvp_awards + 1," : "";
        db->executeUpdate("UPDATE players SET matches_played = matches_played + 1, " + matchesWonSql + mvpSql + " matches_lost = matches_lost + ? WHERE id = ?",
                          {pWon ? "0" : "1", std::to_string(pid)});
    }

    // Recalculate leaderboards using C++ engine
    LeaderboardService::getInstance()->recalculateLeaderboard(tournamentId);

    // Advance winner to next round
    if (winnerTeamId > 0) {
        TournamentService::getInstance()->advanceWinnerToNextRound(matchId, winnerTeamId);
    }

    // Notify captains
    auto notif = NotificationService::getInstance();
    auto tARow = db->queryJson("SELECT captain_id, name FROM teams WHERE id = ?", {std::to_string(teamAId)});
    auto tBRow = db->queryJson("SELECT captain_id, name FROM teams WHERE id = ?", {std::to_string(teamBId)});
    if (!tARow.empty()) notif->sendNotification(static_cast<int>(tARow[0]["captain_id"].get<int64_t>()), "Match Result Verified", "The result for your match has been officially verified.", "match", "/match-history.html");
    if (!tBRow.empty()) notif->sendNotification(static_cast<int>(tBRow[0]["captain_id"].get<int64_t>()), "Match Result Verified", "The result for your match has been officially verified.", "match", "/match-history.html");

    db->logActivity(adminUserId, "VERIFY_RESULT", "Verified match #" + std::to_string(matchId) + " result: " + std::to_string(finalA) + "-" + std::to_string(finalB));
    return {{"success", true}, {"message", "Match result verified. Leaderboard updated."},
            {"winnerId", winnerTeamId}, {"scoreA", finalA}, {"scoreB", finalB}};
}

nlohmann::json ScoreService::getScoreboard(int matchId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT m.*, t.name as tournament_name, t.game_category, t.rules as tournament_rules, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, tA.team_code as team_a_code, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, tB.team_code as team_b_code, "
        "w.name as winner_name, w.logo_url as winner_logo, "
        "mvpU.full_name as mvp_name, mvpU.username as mvp_username, mvpU.avatar_url as mvp_avatar, "
        "p.player_role as mvp_role, p.rating as mvp_rating "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "LEFT JOIN players p ON m.mvp_player_id = p.id "
        "LEFT JOIN users mvpU ON p.user_id = mvpU.id "
        "WHERE m.id = ?";
    auto rows = db->queryJson(sql, {std::to_string(matchId)});
    if (rows.empty()) return {{"success", false}, {"message", "Match not found."}};

    // Get team A players
    auto tAPlayers = db->queryJson(
        "SELECT u.full_name, u.avatar_url, p.player_role, p.game_id, p.rating, p.matches_won, p.mvp_awards "
        "FROM team_members tm JOIN players p ON tm.player_id = p.id JOIN users u ON p.user_id = u.id "
        "WHERE tm.team_id = ?", {rows[0]["team_a_id"].is_null() ? "0" : std::to_string(rows[0]["team_a_id"].get<int64_t>())}
    );
    auto tBPlayers = db->queryJson(
        "SELECT u.full_name, u.avatar_url, p.player_role, p.game_id, p.rating, p.matches_won, p.mvp_awards "
        "FROM team_members tm JOIN players p ON tm.player_id = p.id JOIN users u ON p.user_id = u.id "
        "WHERE tm.team_id = ?", {rows[0]["team_b_id"].is_null() ? "0" : std::to_string(rows[0]["team_b_id"].get<int64_t>())}
    );

    auto scoreboard = rows[0];
    scoreboard["team_a_roster"] = tAPlayers;
    scoreboard["team_b_roster"] = tBPlayers;
    return {{"success", true}, {"scoreboard", scoreboard}};
}

nlohmann::json ScoreService::getLiveScoreboard() {
    auto db = DatabaseService::getInstance();
    return db->queryJson(
        "SELECT m.*, t.name as tournament_name, t.game_category, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "WHERE m.status IN ('Live', 'Under Review') ORDER BY m.scheduled_time ASC"
    );
}

} // namespace Esports

