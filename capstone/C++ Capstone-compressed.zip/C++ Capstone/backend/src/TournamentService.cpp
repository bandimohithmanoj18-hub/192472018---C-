#include "../include/services/TournamentService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/NotificationService.h"
#include <algorithm>
#include <random>
#include <chrono>

namespace Esports {

std::shared_ptr<TournamentService> TournamentService::s_instance = nullptr;

TournamentService::TournamentService() {}

std::shared_ptr<TournamentService> TournamentService::getInstance() {
    if (!s_instance) {
        s_instance = std::make_shared<TournamentService>();
    }
    return s_instance;
}

nlohmann::json TournamentService::getAllTournaments(const std::string& game, const std::string& status, const std::string& search) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT t.*, "
        "(SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.tournament_id = t.id AND tr.status = 'Approved') as approved_teams_count, "
        "(SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.tournament_id = t.id) as total_registrations, "
        "w.name as winner_team_name, w.logo_url as winner_team_logo "
        "FROM tournaments t "
        "LEFT JOIN teams w ON t.winner_team_id = w.id "
        "WHERE 1=1 ";

    std::vector<std::string> params;
    if (!game.empty()) {
        sql += " AND t.game_category = ? ";
        params.push_back(game);
    }
    if (!status.empty()) {
        sql += " AND t.status = ? ";
        params.push_back(status);
    }
    if (!search.empty()) {
        sql += " AND (t.name LIKE ? OR t.description LIKE ?) ";
        params.push_back("%" + search + "%");
        params.push_back("%" + search + "%");
    }

    sql += " ORDER BY CASE t.status WHEN 'Live' THEN 1 WHEN 'Ongoing' THEN 2 WHEN 'Registration Open' THEN 3 WHEN 'Upcoming' THEN 4 ELSE 5 END, t.start_date ASC";
    return db->queryJson(sql, params);
}

nlohmann::json TournamentService::getTournamentById(int tournamentId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT t.*, "
        "w.name as winner_name, w.logo_url as winner_logo, "
        "ru.name as runner_up_name, ru.logo_url as runner_up_logo "
        "FROM tournaments t "
        "LEFT JOIN teams w ON t.winner_team_id = w.id "
        "LEFT JOIN teams ru ON t.runner_up_team_id = ru.id "
        "WHERE t.id = ?";
    auto rows = db->queryJson(sql, {std::to_string(tournamentId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "Tournament not found."}};
    }

    auto tourn = rows[0];

    // Registrations
    tourn["registrations"] = getTournamentRegistrations(tournamentId);

    // Matches
    std::string matchSql =
        "SELECT m.*, tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, "
        "w.name as winner_name, mvpU.full_name as mvp_name "
        "FROM matches m "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "LEFT JOIN players mvpP ON m.mvp_player_id = mvpP.id "
        "LEFT JOIN users mvpU ON mvpP.user_id = mvpU.id "
        "WHERE m.tournament_id = ? "
        "ORDER BY m.round_number ASC, m.match_number ASC";
    tourn["matches"] = db->queryJson(matchSql, {std::to_string(tournamentId)});

    // Prizes
    tourn["prizes"] = db->queryJson(
        "SELECT p.*, t.name as team_name, t.logo_url as team_logo FROM prizes p LEFT JOIN teams t ON p.team_id = t.id WHERE p.tournament_id = ? ORDER BY p.place ASC",
        {std::to_string(tournamentId)}
    );

    return {{"success", true}, {"tournament", tourn}};
}

nlohmann::json TournamentService::createTournament(int adminUserId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();

    std::string name = payload.value("name", "");
    std::string game = payload.value("gameCategory", "Valorant");
    std::string desc = payload.value("description", "");
    std::string format = payload.value("format", "Single Elimination");
    if (format == "Group Stage followed by Knockout" || format == "GroupStageKnockout" || format == "Group Stage Knockout") {
        format = "Group Stage + Knockout";
    }
    std::string status = payload.value("status", "Registration Open");
    std::string startDate = payload.value("startDate", "2026-11-20 18:00:00");
    std::string endDate = payload.value("endDate", "2026-11-30 22:00:00");
    std::string regDeadline = payload.value("registrationDeadline", "2026-11-18 23:59:59");

    if (startDate.length() == 10) startDate += " 18:00:00";
    if (endDate.length() == 10) endDate += " 22:00:00";
    if (regDeadline.length() == 10) regDeadline += " 23:59:59";
    int maxTeams = payload.value("maxTeams", 8);
    double prizePool = payload.value("prizePool", 25000.0);
    std::string bannerUrl = payload.value("bannerUrl", "/assets/images/default-banner.svg");
    std::string rules = payload.value("rules", "Official competitive fair-play tournament guidelines apply.");

    if (name.empty()) {
        return {{"success", false}, {"message", "Tournament name is required."}};
    }

    int tId = db->executeInsert(
        "INSERT INTO tournaments (name, game_category, description, format, status, start_date, end_date, registration_deadline, max_teams, prize_pool, banner_url, rules) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        {name, game, desc, format, status, startDate, endDate, regDeadline, std::to_string(maxTeams), std::to_string(prizePool), bannerUrl, rules}
    );

    if (tId <= 0) {
        return {{"success", false}, {"message", "Failed to create tournament."}};
    }

    // Configure standard prize breakdown (60% 1st, 25% 2nd, 15% 3rd)
    double p1 = prizePool * 0.60;
    double p2 = prizePool * 0.25;
    double p3 = prizePool * 0.15;

    db->executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount) VALUES (?, 1, '1st Place Champion', ?)", {std::to_string(tId), std::to_string(p1)});
    db->executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount) VALUES (?, 2, '2nd Place Runner-Up', ?)", {std::to_string(tId), std::to_string(p2)});
    db->executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount) VALUES (?, 3, '3rd Place Bronze Medal', ?)", {std::to_string(tId), std::to_string(p3)});

    db->logActivity(adminUserId, "CREATE_TOURNAMENT", "Created tournament: " + name + " (Prize Pool: $" + std::to_string(prizePool) + ")");

    return {{"success", true}, {"message", "Tournament created successfully!"}, {"tournamentId", tId}};
}

nlohmann::json TournamentService::updateTournament(int tournamentId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();

    std::string name = payload.value("name", "");
    std::string desc = payload.value("description", "");
    std::string format = payload.value("format", "");
    std::string status = payload.value("status", "");
    std::string startDate = payload.value("startDate", "");
    std::string endDate = payload.value("endDate", "");
    std::string regDeadline = payload.value("registrationDeadline", "");
    std::string bannerUrl = payload.value("bannerUrl", "");
    std::string rules = payload.value("rules", "");

    db->executeUpdate(
        "UPDATE tournaments SET "
        "name = COALESCE(NULLIF(?, ''), name), "
        "description = COALESCE(NULLIF(?, ''), description), "
        "format = COALESCE(NULLIF(?, ''), format), "
        "status = COALESCE(NULLIF(?, ''), status), "
        "start_date = COALESCE(NULLIF(?, ''), start_date), "
        "end_date = COALESCE(NULLIF(?, ''), end_date), "
        "registration_deadline = COALESCE(NULLIF(?, ''), registration_deadline), "
        "banner_url = COALESCE(NULLIF(?, ''), banner_url), "
        "rules = COALESCE(NULLIF(?, ''), rules) "
        "WHERE id = ?",
        {name, desc, format, status, startDate, endDate, regDeadline, bannerUrl, rules, std::to_string(tournamentId)}
    );

    return {{"success", true}, {"message", "Tournament updated successfully."}};
}

nlohmann::json TournamentService::deleteTournament(int tournamentId) {
    auto db = DatabaseService::getInstance();
    db->executeUpdate("DELETE FROM tournaments WHERE id = ?", {std::to_string(tournamentId)});
    db->logActivity(1, "DELETE_TOURNAMENT", "Deleted tournament #" + std::to_string(tournamentId));
    return {{"success", true}, {"message", "Tournament deleted successfully."}};
}

nlohmann::json TournamentService::registerTeamForTournament(int tournamentId, int teamId, int captainUserId) {
    auto db = DatabaseService::getInstance();

    // 1. Check tournament exists and allows registrations
    auto tRows = db->queryJson("SELECT id, name, game_category, status, max_teams FROM tournaments WHERE id = ?", {std::to_string(tournamentId)});
    if (tRows.empty()) {
        return {{"success", false}, {"message", "Tournament does not exist."}};
    }
    std::string tStatus = tRows[0].value("status", "");
    std::string tGame = tRows[0].value("game_category", "");
    int64_t maxTeams = tRows[0]["max_teams"].get<int64_t>();

    if (tStatus != "Registration Open" && tStatus != "Upcoming") {
        return {{"success", false}, {"message", "Registration is closed for this tournament."}};
    }

    // 2. Check current approved count
    auto approvedRows = db->queryJson("SELECT COUNT(*) as cnt FROM tournament_registrations WHERE tournament_id = ? AND status = 'Approved'", {std::to_string(tournamentId)});
    if (!approvedRows.empty() && approvedRows[0]["cnt"].get<int64_t>() >= maxTeams) {
        return {{"success", false}, {"message", "Tournament has reached its maximum team capacity (" + std::to_string(maxTeams) + " teams)."}};
    }

    // 3. Verify team exists, matches game, and captain owns it
    auto teamRows = db->queryJson("SELECT id, name, game_category, captain_id FROM teams WHERE id = ?", {std::to_string(teamId)});
    if (teamRows.empty()) {
        return {{"success", false}, {"message", "Team does not exist."}};
    }
    if (captainUserId > 0 && teamRows[0]["captain_id"].get<int64_t>() != captainUserId) {
        return {{"success", false}, {"message", "Unauthorized. You are not the captain of this team."}};
    }
    if (teamRows[0].value("game_category", "") != tGame) {
        return {{"success", false}, {"message", "Team game (" + teamRows[0].value("game_category", "") + ") does not match tournament game (" + tGame + ")."}};
    }

    // 4. Check if team already registered
    auto regCheck = db->queryJson("SELECT id, status FROM tournament_registrations WHERE tournament_id = ? AND team_id = ?",
                                  {std::to_string(tournamentId), std::to_string(teamId)});
    if (!regCheck.empty()) {
        return {{"success", false}, {"message", "Team is already registered for this tournament (Status: " + regCheck[0].value("status", "") + ")."}};
    }

    // 5. Check if any player in this team is already registered in another team in this tournament
    std::string playerConflictSql =
        "SELECT p.id, u.full_name, tOther.name as other_team "
        "FROM team_members tm "
        "JOIN players p ON tm.player_id = p.id "
        "JOIN users u ON p.user_id = u.id "
        "JOIN team_members tmOther ON tmOther.player_id = p.id AND tmOther.team_id != ? "
        "JOIN tournament_registrations trOther ON trOther.team_id = tmOther.team_id AND trOther.tournament_id = ? "
        "JOIN teams tOther ON trOther.team_id = tOther.id";
    auto conflicts = db->queryJson(playerConflictSql, {std::to_string(teamId), std::to_string(tournamentId)});
    if (!conflicts.empty()) {
        std::string pName = conflicts[0].value("full_name", "A player");
        std::string otherTeam = conflicts[0].value("other_team", "another team");
        return {{"success", false}, {"message", "Player '" + pName + "' is already competing in this tournament under " + otherTeam + ". A player cannot compete for multiple teams in the same tournament."}};
    }

    // 6. Insert registration
    int regId = db->executeInsert(
        "INSERT INTO tournament_registrations (tournament_id, team_id, status) VALUES (?, ?, 'Pending')",
        {std::to_string(tournamentId), std::to_string(teamId)}
    );

    // Notify admins
    auto notif = NotificationService::getInstance();
    notif->notifyAllAdmins("Tournament Registration Request", "Team '" + teamRows[0].value("name", "") + "' registered for '" + tRows[0].value("name", "") + "'. Awaiting approval.", "registration", "/admin-dashboard.html");

    db->logActivity(captainUserId, "TOURNAMENT_REGISTER", "Registered team #" + std::to_string(teamId) + " for tournament #" + std::to_string(tournamentId));

    return {{"success", true}, {"message", "Registration submitted successfully! Status is currently 'Pending' admin approval."}};
}

nlohmann::json TournamentService::getTournamentRegistrations(int tournamentId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT tr.*, t.name as team_name, t.logo_url as team_logo, t.team_code, "
        "u.full_name as captain_name, u.email as captain_email, "
        "(SELECT COUNT(*) FROM team_members tm WHERE tm.team_id = t.id) as roster_count "
        "FROM tournament_registrations tr "
        "JOIN teams t ON tr.team_id = t.id "
        "LEFT JOIN users u ON t.captain_id = u.id "
        "WHERE tr.tournament_id = ? "
        "ORDER BY tr.registered_at ASC";
    return db->queryJson(sql, {std::to_string(tournamentId)});
}

nlohmann::json TournamentService::updateRegistrationStatus(int registrationId, int adminUserId, const std::string& status, const std::string& notes) {
    auto db = DatabaseService::getInstance();

    auto regRows = db->queryJson(
        "SELECT tr.*, t.name as team_name, t.captain_id, tour.name as tournament_name "
        "FROM tournament_registrations tr "
        "JOIN teams t ON tr.team_id = t.id "
        "JOIN tournaments tour ON tr.tournament_id = tour.id "
        "WHERE tr.id = ?",
        {std::to_string(registrationId)}
    );

    if (regRows.empty()) {
        return {{"success", false}, {"message", "Registration record not found."}};
    }

    auto reg = regRows[0];
    int captainId = static_cast<int>(reg["captain_id"].get<int64_t>());
    std::string teamName = reg.value("team_name", "");
    std::string tournamentName = reg.value("tournament_name", "");

    db->executeUpdate(
        "UPDATE tournament_registrations SET status = ?, reviewed_by = ?, review_notes = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?",
        {status, std::to_string(adminUserId), notes, std::to_string(registrationId)}
    );

    // Notify team captain
    auto notif = NotificationService::getInstance();
    if (status == "Approved") {
        notif->sendNotification(captainId, "Registration Approved!", "Your team '" + teamName + "' has been approved for " + tournamentName + "!", "tournament", "/captain-dashboard.html");
    } else {
        notif->sendNotification(captainId, "Registration Rejected", "Your registration for " + tournamentName + " was rejected. Reason: " + notes, "tournament", "/captain-dashboard.html");
    }

    db->logActivity(adminUserId, "REVIEW_REGISTRATION", "Updated registration #" + std::to_string(registrationId) + " to: " + status);
    return {{"success", true}, {"message", "Registration status updated to " + status}};
}

nlohmann::json TournamentService::generateBracket(int tournamentId, int adminUserId) {
    auto db = DatabaseService::getInstance();

    // 1. Fetch approved teams
    auto approvedTeams = db->queryJson(
        "SELECT tr.team_id, t.name, t.logo_url FROM tournament_registrations tr "
        "JOIN teams t ON tr.team_id = t.id "
        "WHERE tr.tournament_id = ? AND tr.status = 'Approved'",
        {std::to_string(tournamentId)}
    );

    if (approvedTeams.size() < 2) {
        return {{"success", false}, {"message", "At least 2 approved teams are required to generate a bracket."}};
    }

    // 2. Fetch tournament format
    auto tRows = db->queryJson("SELECT name, format FROM tournaments WHERE id = ?", {std::to_string(tournamentId)});
    if (tRows.empty()) return {{"success", false}, {"message", "Tournament not found."}};
    std::string format = tRows[0].value("format", "Single Elimination");
    std::string tName = tRows[0].value("name", "");

    // 3. Clear existing matches for this tournament
    db->executeUpdate("DELETE FROM matches WHERE tournament_id = ?", {std::to_string(tournamentId)});

    // 4. Shuffle teams for fair randomized bracket allocation in C++
    std::vector<int> teamIds;
    for (const auto& tm : approvedTeams) {
        teamIds.push_back(static_cast<int>(tm["team_id"].get<int64_t>()));
    }
    unsigned seed = static_cast<unsigned>(std::chrono::system_clock::now().time_since_epoch().count());
    std::shuffle(teamIds.begin(), teamIds.end(), std::default_random_engine(seed));

    int generatedMatchCount = 0;

    if (format == "Round Robin") {
        // C++ Round Robin Scheduling Algorithm
        size_t n = teamIds.size();
        std::vector<int> teams = teamIds;
        if (n % 2 != 0) {
            teams.push_back(0); // Bye
            n++;
        }

        int roundNumber = 1;
        for (size_t r = 0; r < n - 1; r++) {
            for (size_t i = 0; i < n / 2; i++) {
                int t1 = teams[i];
                int t2 = teams[n - 1 - i];
                if (t1 != 0 && t2 != 0) {
                    db->executeInsert(
                        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, scheduled_time, slot_info, status) "
                        "VALUES (?, ?, ?, 'Group', ?, ?, datetime('now', '+' || ? || ' days'), 'Arena Stage', 'Upcoming')",
                        {std::to_string(tournamentId), std::to_string(roundNumber), std::to_string(static_cast<int>(i + 1)), std::to_string(t1), std::to_string(t2), std::to_string(roundNumber)}
                    );
                    generatedMatchCount++;
                }
            }
            roundNumber++;
            // Rotate teams (keep index 0 fixed, rotate others)
            int last = teams.back();
            teams.pop_back();
            teams.insert(teams.begin() + 1, last);
        }
    } else {
        // Single Elimination / Knockout Bracket Algorithm in C++
        // Determine number of rounds needed (log2)
        int numTeams = static_cast<int>(teamIds.size());
        int r1MatchCount = numTeams / 2;

        std::vector<int> round1MatchIds;

        for (int i = 0; i < r1MatchCount; i++) {
            int tA = teamIds[i * 2];
            int tB = teamIds[i * 2 + 1];

            int mId = db->executeInsert(
                "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, scheduled_time, slot_info, status) "
                "VALUES (?, 1, ?, 'Winners', ?, ?, datetime('now', '+1 hours'), 'Main Arena - Stream 1', 'Upcoming')",
                {std::to_string(tournamentId), std::to_string(i + 1), std::to_string(tA), std::to_string(tB)}
            );
            round1MatchIds.push_back(mId);
            generatedMatchCount++;
        }

        // Generate Subsequent Rounds placeholders and link `next_match_id`
        std::vector<int> prevRoundMatchIds = round1MatchIds;
        int currentRound = 2;

        while (prevRoundMatchIds.size() > 1) {
            std::vector<int> nextRoundMatchIds;
            int nextMatchCount = static_cast<int>(prevRoundMatchIds.size()) / 2;

            for (int j = 0; j < nextMatchCount; j++) {
                int nextMId = db->executeInsert(
                    "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, scheduled_time, slot_info, status) "
                    "VALUES (?, ?, ?, 'Winners', datetime('now', '+' || ? || ' days'), 'Championship Stage', 'Upcoming')",
                    {std::to_string(tournamentId), std::to_string(currentRound), std::to_string(j + 1), std::to_string(currentRound)}
                );

                // Link the two feeding matches to this next match
                int feed1 = prevRoundMatchIds[j * 2];
                int feed2 = prevRoundMatchIds[j * 2 + 1];
                db->executeUpdate("UPDATE matches SET next_match_id = ? WHERE id IN (?, ?)",
                                  {std::to_string(nextMId), std::to_string(feed1), std::to_string(feed2)});

                nextRoundMatchIds.push_back(nextMId);
                generatedMatchCount++;
            }

            prevRoundMatchIds = nextRoundMatchIds;
            currentRound++;
        }
    }

    // Set tournament status to 'Ongoing'
    db->executeUpdate("UPDATE tournaments SET status = 'Ongoing' WHERE id = ?", {std::to_string(tournamentId)});

    // Notify participants
    auto notif = NotificationService::getInstance();
    notif->notifyTournamentParticipants(tournamentId, "Tournament Bracket Generated!", "Matches have been generated for '" + tName + "'. Check your schedule now!", "match");

    db->logActivity(adminUserId, "GENERATE_BRACKET", "Generated " + std::to_string(generatedMatchCount) + " matches for tournament #" + std::to_string(tournamentId));

    return {
        {"success", true},
        {"message", "Tournament bracket successfully generated with " + std::to_string(generatedMatchCount) + " matches!"},
        {"matchCount", generatedMatchCount}
    };
}

nlohmann::json TournamentService::getTournamentBracket(int tournamentId) {
    auto db = DatabaseService::getInstance();

    std::string sql =
        "SELECT m.*, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, "
        "w.name as winner_name "
        "FROM matches m "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "WHERE m.tournament_id = ? "
        "ORDER BY m.round_number ASC, m.match_number ASC";

    auto matches = db->queryJson(sql, {std::to_string(tournamentId)});

    // Group matches by round for bracket rendering
    std::map<int, nlohmann::json> roundsMap;
    for (const auto& m : matches) {
        int r = static_cast<int>(m["round_number"].get<int64_t>());
        if (roundsMap.find(r) == roundsMap.end()) {
            roundsMap[r] = nlohmann::json::array();
        }
        roundsMap[r].push_back(m);
    }

    nlohmann::json roundsJson = nlohmann::json::array();
    for (const auto& pair : roundsMap) {
        roundsJson.push_back({
            {"roundNumber", pair.first},
            {"roundName", "Round " + std::to_string(pair.first)},
            {"matches", pair.second}
        });
    }

    return {
        {"success", true},
        {"tournamentId", tournamentId},
        {"rounds", roundsJson}
    };
}

bool TournamentService::advanceWinnerToNextRound(int matchId, int winnerTeamId) {
    auto db = DatabaseService::getInstance();

    auto mRows = db->queryJson("SELECT tournament_id, next_match_id, team_a_id, team_b_id FROM matches WHERE id = ?", {std::to_string(matchId)});
    if (mRows.empty()) return false;

    int tournamentId = static_cast<int>(mRows[0]["tournament_id"].get<int64_t>());

    if (mRows[0]["next_match_id"].is_null() || mRows[0]["next_match_id"].get<int64_t>() == 0) {
        // This was the Grand Finals match! Crown tournament champion!
        int runnerUpId = (mRows[0]["team_a_id"].get<int64_t>() == winnerTeamId)
            ? static_cast<int>(mRows[0]["team_b_id"].get<int64_t>())
            : static_cast<int>(mRows[0]["team_a_id"].get<int64_t>());

        db->executeUpdate(
            "UPDATE tournaments SET status = 'Completed', winner_team_id = ?, runner_up_team_id = ? WHERE id = ?",
            {std::to_string(winnerTeamId), std::to_string(runnerUpId), std::to_string(tournamentId)}
        );

        // Update prizes table
        db->executeUpdate("UPDATE prizes SET team_id = ? WHERE tournament_id = ? AND place = 1", {std::to_string(winnerTeamId), std::to_string(tournamentId)});
        db->executeUpdate("UPDATE prizes SET team_id = ? WHERE tournament_id = ? AND place = 2", {std::to_string(runnerUpId), std::to_string(tournamentId)});

        auto notif = NotificationService::getInstance();
        notif->notifyTournamentParticipants(tournamentId, "Tournament Concluded!", "We have a champion! Congratulations to the winners!", "announcement");
        return true;
    }

    int nextMatchId = static_cast<int>(mRows[0]["next_match_id"].get<int64_t>());

    // Inspect next match slot to place winner in either team_a or team_b
    auto nextMRows = db->queryJson("SELECT team_a_id, team_b_id FROM matches WHERE id = ?", {std::to_string(nextMatchId)});
    if (!nextMRows.empty()) {
        if (nextMRows[0]["team_a_id"].is_null() || nextMRows[0]["team_a_id"].get<int64_t>() == 0) {
            db->executeUpdate("UPDATE matches SET team_a_id = ? WHERE id = ?", {std::to_string(winnerTeamId), std::to_string(nextMatchId)});
        } else if (nextMRows[0]["team_b_id"].is_null() || nextMRows[0]["team_b_id"].get<int64_t>() == 0) {
            db->executeUpdate("UPDATE matches SET team_b_id = ? WHERE id = ?", {std::to_string(winnerTeamId), std::to_string(nextMatchId)});
        }
    }

    return true;
}

nlohmann::json TournamentService::getTournamentReport(int tournamentId) {
    auto db = DatabaseService::getInstance();
    auto tRows = db->queryJson("SELECT * FROM tournaments WHERE id = ?", {std::to_string(tournamentId)});
    if (tRows.empty()) return {{"success", false}, {"message", "Tournament not found."}};

    auto tourn = tRows[0];
    auto matches = db->queryJson("SELECT * FROM matches WHERE tournament_id = ?", {std::to_string(tournamentId)});
    auto teams = db->queryJson("SELECT tr.*, t.name FROM tournament_registrations tr JOIN teams t ON tr.team_id = t.id WHERE tr.tournament_id = ?", {std::to_string(tournamentId)});

    int completedMatches = 0;
    for (const auto& m : matches) {
        if (m.value("status", "") == "Completed") completedMatches++;
    }

    return {
        {"success", true},
        {"tournament", tourn},
        {"totalTeams", teams.size()},
        {"totalMatches", matches.size()},
        {"completedMatches", completedMatches},
        {"prizeDistribution", db->queryJson("SELECT * FROM prizes WHERE tournament_id = ? ORDER BY place ASC", {std::to_string(tournamentId)})}
    };
}

nlohmann::json TournamentService::getPlatformAnalytics() {
    auto db = DatabaseService::getInstance();

    auto playersCnt = db->queryJson("SELECT COUNT(*) as cnt FROM players");
    auto teamsCnt = db->queryJson("SELECT COUNT(*) as cnt FROM teams");
    auto tournsCnt = db->queryJson("SELECT COUNT(*) as cnt FROM tournaments");
    auto activeTournsCnt = db->queryJson("SELECT COUNT(*) as cnt FROM tournaments WHERE status = 'Ongoing' OR status = 'Live'");
    auto completedMatchesCnt = db->queryJson("SELECT COUNT(*) as cnt FROM matches WHERE status = 'Completed'");
    auto upcomingMatchesCnt = db->queryJson("SELECT COUNT(*) as cnt FROM matches WHERE status = 'Upcoming'");
    auto disputesCnt = db->queryJson("SELECT COUNT(*) as cnt FROM disputes WHERE status = 'Open'");

    // Game breakdown
    auto gameBreakdown = db->queryJson("SELECT game_category, COUNT(*) as team_count FROM teams GROUP BY game_category");

    // Recent activity logs
    auto logs = db->queryJson("SELECT a.*, u.username FROM activity_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 15");

    return {
        {"success", true},
        {"totalPlayers", playersCnt.empty() ? 0 : playersCnt[0]["cnt"].get<int64_t>()},
        {"totalTeams", teamsCnt.empty() ? 0 : teamsCnt[0]["cnt"].get<int64_t>()},
        {"totalTournaments", tournsCnt.empty() ? 0 : tournsCnt[0]["cnt"].get<int64_t>()},
        {"activeTournaments", activeTournsCnt.empty() ? 0 : activeTournsCnt[0]["cnt"].get<int64_t>()},
        {"completedMatches", completedMatchesCnt.empty() ? 0 : completedMatchesCnt[0]["cnt"].get<int64_t>()},
        {"upcomingMatches", upcomingMatchesCnt.empty() ? 0 : upcomingMatchesCnt[0]["cnt"].get<int64_t>()},
        {"openDisputes", disputesCnt.empty() ? 0 : disputesCnt[0]["cnt"].get<int64_t>()},
        {"gameBreakdown", gameBreakdown},
        {"recentActivity", logs}
    };
}

} // namespace Esports

