#include "../include/services/PlayerService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/TeamService.h"
#include "../include/services/NotificationService.h"

namespace Esports {

std::shared_ptr<PlayerService> PlayerService::s_instance = nullptr;

PlayerService::PlayerService() {}

std::shared_ptr<PlayerService> PlayerService::getInstance() {
    if (!s_instance) {
        s_instance = std::make_shared<PlayerService>();
    }
    return s_instance;
}

nlohmann::json PlayerService::getAllPlayers(const std::string& game, const std::string& search, int limit) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT p.*, u.username, u.full_name, u.country, u.avatar_url, "
        "t.name as team_name, t.logo_url as team_logo "
        "FROM players p "
        "JOIN users u ON p.user_id = u.id "
        "LEFT JOIN teams t ON p.team_id = t.id "
        "WHERE 1=1 ";

    std::vector<std::string> params;
    if (!game.empty()) {
        sql += " AND p.selected_game = ? ";
        params.push_back(game);
    }
    if (!search.empty()) {
        sql += " AND (u.full_name LIKE ? OR u.username LIKE ? OR p.game_id LIKE ?) ";
        params.push_back("%" + search + "%");
        params.push_back("%" + search + "%");
        params.push_back("%" + search + "%");
    }

    sql += " ORDER BY p.rating DESC, p.matches_won DESC LIMIT " + std::to_string(limit);
    return db->queryJson(sql, params);
}

nlohmann::json PlayerService::getPlayerById(int playerId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT p.*, u.username, u.email, u.full_name, u.phone_number, u.country, u.avatar_url, u.created_at as joined_platform, "
        "t.name as team_name, t.logo_url as team_logo, t.team_code "
        "FROM players p "
        "JOIN users u ON p.user_id = u.id "
        "LEFT JOIN teams t ON p.team_id = t.id "
        "WHERE p.id = ?";
    auto rows = db->queryJson(sql, {std::to_string(playerId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "Player not found"}};
    }
    auto pData = rows[0];
    pData["fullName"] = pData.value("full_name", "");
    pData["gameId"] = pData.value("game_id", "");
    pData["selectedGame"] = pData.value("selected_game", "");
    pData["playerRole"] = pData.value("player_role", "");
    pData["matchesPlayed"] = pData.value("matches_played", 0);
    pData["matchesWon"] = pData.value("matches_won", 0);
    pData["matchesLost"] = pData.value("matches_lost", 0);
    pData["mvpAwards"] = pData.value("mvp_awards", 0);

    if (!pData["team_id"].is_null() && pData["team_id"].get<int64_t>() > 0) {
        int tid = static_cast<int>(pData["team_id"].get<int64_t>());
        auto tRes = TeamService::getInstance()->getTeamById(tid);
        if (tRes.contains("team")) {
            pData["team"] = tRes["team"];
        }
    }
    return {{"success", true}, {"player", pData}};
}

nlohmann::json PlayerService::getPlayerByUserId(int userId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT p.*, u.username, u.email, u.full_name, u.phone_number, u.country, u.avatar_url, "
        "t.name as team_name, t.logo_url as team_logo, t.team_code, t.invitation_code as team_invite_code "
        "FROM players p "
        "JOIN users u ON p.user_id = u.id "
        "LEFT JOIN teams t ON p.team_id = t.id "
        "WHERE p.user_id = ?";
    auto rows = db->queryJson(sql, {std::to_string(userId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "Player record not found for this user."}};
    }
    auto pData = rows[0];
    pData["fullName"] = pData.value("full_name", "");
    pData["gameId"] = pData.value("game_id", "");
    pData["selectedGame"] = pData.value("selected_game", "");
    pData["playerRole"] = pData.value("player_role", "");
    pData["matchesPlayed"] = pData.value("matches_played", 0);
    pData["matchesWon"] = pData.value("matches_won", 0);
    pData["matchesLost"] = pData.value("matches_lost", 0);
    pData["mvpAwards"] = pData.value("mvp_awards", 0);

    if (!pData["team_id"].is_null() && pData["team_id"].get<int64_t>() > 0) {
        int tid = static_cast<int>(pData["team_id"].get<int64_t>());
        auto tRes = TeamService::getInstance()->getTeamById(tid);
        if (tRes.contains("team")) {
            pData["team"] = tRes["team"];
        }
    }
    return {{"success", true}, {"player", pData}};
}

nlohmann::json PlayerService::joinTeamWithInviteCode(int userId, const std::string& inviteCode) {
    auto db = DatabaseService::getInstance();

    if (inviteCode.empty()) {
        return {{"success", false}, {"message", "Invitation code is required."}};
    }

    // Find team by invitation code
    auto teamRows = db->queryJson("SELECT id, name, game_category, captain_id, max_players FROM teams WHERE invitation_code = ?", {inviteCode});
    if (teamRows.empty()) {
        return {{"success", false}, {"message", "Invalid invitation code. No team found."}};
    }

    int teamId = static_cast<int>(teamRows[0]["id"].get<int64_t>());
    std::string teamName = teamRows[0].value("name", "");
    std::string teamGame = teamRows[0].value("game_category", "");
    int64_t maxPlayers = teamRows[0]["max_players"].get<int64_t>();

    // Get player record
    auto playerRows = db->queryJson("SELECT id, team_id, selected_game FROM players WHERE user_id = ?", {std::to_string(userId)});
    if (playerRows.empty()) {
        return {{"success", false}, {"message", "Only registered players can join teams."}};
    }

    int playerId = static_cast<int>(playerRows[0]["id"].get<int64_t>());
    if (!playerRows[0]["team_id"].is_null() && playerRows[0]["team_id"].get<int64_t>() > 0) {
        return {{"success", false}, {"message", "You are already a member of a team. Please leave your current team first."}};
    }

    // Check roster count
    auto rosterRows = db->queryJson("SELECT COUNT(*) as cnt FROM team_members WHERE team_id = ?", {std::to_string(teamId)});
    if (!rosterRows.empty() && rosterRows[0]["cnt"].get<int64_t>() >= maxPlayers) {
        return {{"success", false}, {"message", "Team roster is already full (" + std::to_string(maxPlayers) + " players)."}};
    }

    // Add member
    return TeamService::getInstance()->addTeamMember(teamId, playerId, "Starter");
}

nlohmann::json PlayerService::leaveTeam(int userId) {
    auto db = DatabaseService::getInstance();
    auto playerRows = db->queryJson("SELECT id, team_id FROM players WHERE user_id = ?", {std::to_string(userId)});
    if (playerRows.empty() || playerRows[0]["team_id"].is_null() || playerRows[0]["team_id"].get<int64_t>() == 0) {
        return {{"success", false}, {"message", "You are not currently in any team."}};
    }

    int playerId = static_cast<int>(playerRows[0]["id"].get<int64_t>());
    int teamId = static_cast<int>(playerRows[0]["team_id"].get<int64_t>());

    return TeamService::getInstance()->removeTeamMember(teamId, playerId, userId);
}

nlohmann::json PlayerService::updatePlayerProfile(int userId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();

    std::string gameId = payload.value("gameId", "");
    std::string playerRole = payload.value("playerRole", "");
    std::string selectedGame = payload.value("selectedGame", "");

    db->executeUpdate(
        "UPDATE players SET "
        "game_id = COALESCE(NULLIF(?, ''), game_id), "
        "player_role = COALESCE(NULLIF(?, ''), player_role), "
        "selected_game = COALESCE(NULLIF(?, ''), selected_game) "
        "WHERE user_id = ?",
        {gameId, playerRole, selectedGame, std::to_string(userId)}
    );

    return {{"success", true}, {"message", "Player profile details updated successfully."}};
}

} // namespace Esports

