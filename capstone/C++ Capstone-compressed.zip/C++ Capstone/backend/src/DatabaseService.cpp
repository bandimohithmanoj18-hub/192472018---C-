#include "../include/services/DatabaseService.h"
#include "../include/services/Sha256.h"
#include <iostream>
#include <fstream>
#include <sstream>

namespace Esports {

std::shared_ptr<DatabaseService> DatabaseService::s_instance = nullptr;

DatabaseService::DatabaseService() : m_db(nullptr) {}

DatabaseService::~DatabaseService() {
    close();
}

std::shared_ptr<DatabaseService> DatabaseService::getInstance() {
    if (!s_instance) {
        s_instance = std::make_shared<DatabaseService>();
    }
    return s_instance;
}

bool DatabaseService::initialize(const std::string& dbPath) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_dbPath = dbPath;

    int rc = sqlite3_open(dbPath.c_str(), &m_db);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to open SQLite database: " << sqlite3_errmsg(m_db) << std::endl;
        return false;
    }

    // Enable foreign keys and WAL mode for high concurrency
    sqlite3_exec(m_db, "PRAGMA foreign_keys = ON;", nullptr, nullptr, nullptr);
    sqlite3_exec(m_db, "PRAGMA journal_mode = WAL;", nullptr, nullptr, nullptr);

    std::cout << "SQLite database initialized successfully at: " << dbPath << std::endl;
    return true;
}

void DatabaseService::close() {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_db) {
        sqlite3_close(m_db);
        m_db = nullptr;
    }
}

bool DatabaseService::execute(const std::string& sql) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_db) return false;

    char* errMsg = nullptr;
    int rc = sqlite3_exec(m_db, sql.c_str(), nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL Error: " << (errMsg ? errMsg : "Unknown") << " in SQL: " << sql.substr(0, 80) << std::endl;
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

int DatabaseService::executeInsert(const std::string& sql, const std::vector<std::string>& params) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_db) return -1;

    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(m_db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Prepare error: " << sqlite3_errmsg(m_db) << " in: " << sql << std::endl;
        return -1;
    }

    for (size_t i = 0; i < params.size(); i++) {
        if (params[i] == "NULL") {
            sqlite3_bind_null(stmt, static_cast<int>(i + 1));
        } else {
            sqlite3_bind_text(stmt, static_cast<int>(i + 1), params[i].c_str(), -1, SQLITE_TRANSIENT);
        }
    }

    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::cerr << "Step error: " << sqlite3_errmsg(m_db) << std::endl;
        sqlite3_finalize(stmt);
        return -1;
    }

    int insertId = static_cast<int>(sqlite3_last_insert_rowid(m_db));
    sqlite3_finalize(stmt);
    return insertId;
}

bool DatabaseService::executeUpdate(const std::string& sql, const std::vector<std::string>& params) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_db) return false;

    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(m_db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Prepare error: " << sqlite3_errmsg(m_db) << " in: " << sql << std::endl;
        return false;
    }

    for (size_t i = 0; i < params.size(); i++) {
        if (params[i] == "NULL") {
            sqlite3_bind_null(stmt, static_cast<int>(i + 1));
        } else {
            sqlite3_bind_text(stmt, static_cast<int>(i + 1), params[i].c_str(), -1, SQLITE_TRANSIENT);
        }
    }

    rc = sqlite3_step(stmt);
    bool ok = (rc == SQLITE_DONE || rc == SQLITE_OK);
    if (!ok) {
        std::cerr << "Step error: " << sqlite3_errmsg(m_db) << std::endl;
    }
    sqlite3_finalize(stmt);
    return ok;
}

nlohmann::json DatabaseService::queryJson(const std::string& sql, const std::vector<std::string>& params) {
    std::lock_guard<std::mutex> lock(m_mutex);
    nlohmann::json results = nlohmann::json::array();
    if (!m_db) return results;

    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(m_db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Prepare query error: " << sqlite3_errmsg(m_db) << " in: " << sql << std::endl;
        return results;
    }

    for (size_t i = 0; i < params.size(); i++) {
        if (params[i] == "NULL") {
            sqlite3_bind_null(stmt, static_cast<int>(i + 1));
        } else {
            sqlite3_bind_text(stmt, static_cast<int>(i + 1), params[i].c_str(), -1, SQLITE_TRANSIENT);
        }
    }

    int colCount = sqlite3_column_count(stmt);

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        nlohmann::json row = nlohmann::json::object();
        for (int col = 0; col < colCount; col++) {
            const char* colName = sqlite3_column_name(stmt, col);
            int colType = sqlite3_column_type(stmt, col);

            switch (colType) {
                case SQLITE_INTEGER:
                    row[colName] = sqlite3_column_int64(stmt, col);
                    break;
                case SQLITE_FLOAT:
                    row[colName] = sqlite3_column_double(stmt, col);
                    break;
                case SQLITE_TEXT: {
                    const char* text = reinterpret_cast<const char*>(sqlite3_column_text(stmt, col));
                    row[colName] = text ? std::string(text) : "";
                    break;
                }
                case SQLITE_NULL:
                    row[colName] = nullptr;
                    break;
                default: {
                    const char* text = reinterpret_cast<const char*>(sqlite3_column_text(stmt, col));
                    row[colName] = text ? std::string(text) : "";
                    break;
                }
            }
        }
        results.push_back(row);
    }

    sqlite3_finalize(stmt);
    return results;
}

void DatabaseService::logActivity(int userId, const std::string& action, const std::string& details, const std::string& ip) {
    std::string sql = "INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)";
    std::vector<std::string> params = {
        userId > 0 ? std::to_string(userId) : "1",
        action,
        details,
        ip
    };
    executeInsert(sql, params);
}

bool DatabaseService::runMigrations() {
    std::string ddl = R"(
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL CHECK(role IN ('admin', 'captain', 'player')),
        full_name VARCHAR(100) NOT NULL,
        phone_number VARCHAR(25),
        country VARCHAR(50) DEFAULT 'India',
        avatar_url VARCHAR(255) DEFAULT '/assets/images/default-avatar.svg',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        game_id VARCHAR(50) NOT NULL,
        selected_game VARCHAR(50) NOT NULL,
        player_role VARCHAR(50) DEFAULT 'Rifler / Assaulter',
        team_id INTEGER DEFAULT NULL,
        matches_played INTEGER DEFAULT 0,
        matches_won INTEGER DEFAULT 0,
        matches_lost INTEGER DEFAULT 0,
        mvp_awards INTEGER DEFAULT 0,
        rating REAL DEFAULT 1200.0,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_code VARCHAR(16) NOT NULL UNIQUE,
        name VARCHAR(100) NOT NULL UNIQUE,
        logo_url VARCHAR(255) DEFAULT '/assets/images/default-team.svg',
        captain_id INTEGER NOT NULL,
        game_category VARCHAR(50) NOT NULL,
        description TEXT,
        invitation_code VARCHAR(12) NOT NULL UNIQUE,
        max_players INTEGER DEFAULT 5,
        contact_email VARCHAR(100),
        contact_phone VARCHAR(25),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (captain_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS team_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id INTEGER NOT NULL,
        player_id INTEGER NOT NULL,
        role_in_team VARCHAR(50) DEFAULT 'Starter',
        joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(team_id, player_id),
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS tournaments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(150) NOT NULL,
        game_category VARCHAR(50) NOT NULL,
        description TEXT,
        format VARCHAR(50) NOT NULL CHECK(format IN ('Single Elimination', 'Double Elimination', 'Round Robin', 'Group Stage + Knockout')),
        status VARCHAR(30) NOT NULL DEFAULT 'Upcoming' CHECK(status IN ('Upcoming', 'Registration Open', 'Ongoing', 'Completed')),
        start_date DATETIME NOT NULL,
        end_date DATETIME NOT NULL,
        registration_deadline DATETIME NOT NULL,
        max_teams INTEGER NOT NULL DEFAULT 8,
        prize_pool REAL NOT NULL DEFAULT 0.0,
        banner_url VARCHAR(255) DEFAULT '/assets/images/default-banner.svg',
        rules TEXT,
        winner_team_id INTEGER DEFAULT NULL,
        runner_up_team_id INTEGER DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (winner_team_id) REFERENCES teams(id),
        FOREIGN KEY (runner_up_team_id) REFERENCES teams(id)
    );

    CREATE TABLE IF NOT EXISTS tournament_registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tournament_id INTEGER NOT NULL,
        team_id INTEGER NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending', 'Approved', 'Rejected')),
        registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_by INTEGER DEFAULT NULL,
        review_notes TEXT,
        reviewed_at DATETIME DEFAULT NULL,
        UNIQUE(tournament_id, team_id),
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE,
        FOREIGN KEY (reviewed_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tournament_id INTEGER NOT NULL,
        round_number INTEGER NOT NULL DEFAULT 1,
        match_number INTEGER NOT NULL DEFAULT 1,
        bracket_type VARCHAR(30) DEFAULT 'Winners',
        team_a_id INTEGER DEFAULT NULL,
        team_b_id INTEGER DEFAULT NULL,
        team_a_score INTEGER DEFAULT 0,
        team_b_score INTEGER DEFAULT 0,
        scheduled_time DATETIME NOT NULL,
        slot_info VARCHAR(100) DEFAULT 'Main Stage Arena 1',
        status VARCHAR(30) NOT NULL DEFAULT 'Upcoming' CHECK(status IN ('Upcoming', 'Live', 'Under Review', 'Completed')),
        winner_team_id INTEGER DEFAULT NULL,
        mvp_player_id INTEGER DEFAULT NULL,
        submitted_by INTEGER DEFAULT NULL,
        submission_notes TEXT,
        is_verified INTEGER NOT NULL DEFAULT 0,
        verified_by INTEGER DEFAULT NULL,
        next_match_id INTEGER DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (team_a_id) REFERENCES teams(id),
        FOREIGN KEY (team_b_id) REFERENCES teams(id),
        FOREIGN KEY (winner_team_id) REFERENCES teams(id),
        FOREIGN KEY (mvp_player_id) REFERENCES players(id),
        FOREIGN KEY (submitted_by) REFERENCES users(id),
        FOREIGN KEY (verified_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS match_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        match_id INTEGER NOT NULL,
        map_name VARCHAR(100),
        round_details TEXT,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        evidence_screenshot VARCHAR(255),
        FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS leaderboards (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tournament_id INTEGER DEFAULT NULL,
        team_id INTEGER NOT NULL,
        game_category VARCHAR(50) NOT NULL,
        matches_played INTEGER DEFAULT 0,
        wins INTEGER DEFAULT 0,
        losses INTEGER DEFAULT 0,
        draws INTEGER DEFAULT 0,
        points INTEGER DEFAULT 0,
        total_score INTEGER DEFAULT 0,
        score_against INTEGER DEFAULT 0,
        win_percentage REAL DEFAULT 0.0,
        recent_form VARCHAR(20) DEFAULT '-----',
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS disputes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        match_id INTEGER NOT NULL,
        raised_by INTEGER NOT NULL,
        team_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        evidence_url VARCHAR(255),
        status VARCHAR(20) NOT NULL DEFAULT 'Open' CHECK(status IN ('Open', 'Under Review', 'Resolved', 'Dismissed')),
        admin_notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME DEFAULT NULL,
        resolved_by INTEGER DEFAULT NULL,
        FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE,
        FOREIGN KEY (raised_by) REFERENCES users(id),
        FOREIGN KEY (team_id) REFERENCES teams(id),
        FOREIGN KEY (resolved_by) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title VARCHAR(150) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(30) DEFAULT 'general',
        is_read INTEGER DEFAULT 0,
        link_url VARCHAR(255) DEFAULT '#',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action VARCHAR(100) NOT NULL,
        details TEXT,
        ip_address VARCHAR(50) DEFAULT '127.0.0.1',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS prizes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tournament_id INTEGER NOT NULL,
        place INTEGER NOT NULL CHECK(place IN (1, 2, 3)),
        reward_title VARCHAR(100) NOT NULL,
        reward_amount REAL NOT NULL,
        team_id INTEGER DEFAULT NULL,
        FOREIGN KEY (tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE,
        FOREIGN KEY (team_id) REFERENCES teams(id)
    );

    CREATE TABLE IF NOT EXISTS sessions (
        token VARCHAR(64) PRIMARY KEY,
        user_id INTEGER NOT NULL,
        username VARCHAR(50) NOT NULL,
        role VARCHAR(20) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    )";

    return execute(ddl);
}

bool DatabaseService::seedDemoData() {
    auto usersCount = queryJson("SELECT COUNT(*) as cnt FROM users");
    if (!usersCount.empty() && usersCount[0]["cnt"].get<int64_t>() > 0) {
        std::cout << "Database already contains users. Skipping demo seeding." << std::endl;
        return true;
    }

    std::cout << "Seeding realistic demo data (8 teams, 30 players, 3 tournaments, matches, disputes)..." << std::endl;

    // Hash passwords using SHA256: 'Admin@123', 'Captain@123', 'Player@123'
    std::string adminHash = SHA256::hash("Admin@123");
    std::string captainHash = SHA256::hash("Captain@123");
    std::string playerHash = SHA256::hash("Player@123");

    // 1. Admin
    executeInsert(
        "INSERT INTO users (username, email, password_hash, role, full_name, phone_number, country, avatar_url) "
        "VALUES ('admin', 'admin@esportsarena.com', ?, 'admin', 'Alex Vance (Chief Tournament Director)', '+91 9876543210', 'India', '/assets/images/avatars/admin.svg')",
        {adminHash}
    );

    // 2. 8 Captains
    struct CaptainDef {
        std::string username, email, name, phone, country;
    };
    std::vector<CaptainDef> captains = {
        {"shahzam", "shahzam@sentinels.gg", "Shahzeeb Khan", "+1 555-0199", "USA"},
        {"boaster", "boaster@fnatic.com", "Jake Howlett", "+44 7700-900", "UK"},
        {"jonathan", "jonathan@godlike.in", "Jonathan Amaral", "+91 9823412345", "India"},
        {"mortal", "mortal@soulesports.in", "Naman Mathur", "+91 9811122233", "India"},
        {"aleksib", "aleksib@navi.gg", "Aleksi Virolainen", "+358 40-123456", "Finland"},
        {"karrigan", "karrigan@faze.gg", "Finn Andersen", "+45 20-304050", "Denmark"},
        {"ajay", "ajay@totalgaming.in", "Ajay Sharma", "+91 9844455566", "India"},
        {"shellzz", "shellzz@mancity.com", "Shaun Springette", "+44 7911-123456", "UK"}
    };

    for (const auto& cap : captains) {
        executeInsert(
            "INSERT INTO users (username, email, password_hash, role, full_name, phone_number, country, avatar_url) "
            "VALUES (?, ?, ?, 'captain', ?, ?, ?, '/assets/images/avatars/captain.svg')",
            {cap.username, cap.email, captainHash, cap.name, cap.phone, cap.country}
        );
    }

    // 3. 8 Teams
    struct TeamDef {
        std::string code, name, logo, game, desc, inv, email, phone;
        int captainUserId;
    };
    std::vector<TeamDef> teams = {
        {"SEN-VAL", "Sentinels", "/assets/images/teams/sentinels.svg", "Valorant", "North American elite championship Valorant roster.", "INV-SEN26", "contact@sentinels.gg", "+1 555-0199", 2},
        {"FNC-VAL", "Fnatic", "/assets/images/teams/fnatic.svg", "Valorant", "European powerhouse and Masters Tokyo champions.", "INV-FNC26", "team@fnatic.com", "+44 7700-900", 3},
        {"GDL-BGM", "GodLike Esports", "/assets/images/teams/godlike.svg", "BGMI", "India's premier tactical aggressive battle royale squad.", "INV-GDL26", "mgmt@godlike.in", "+91 9823412345", 4},
        {"SOU-BGM", "Soul Esports", "/assets/images/teams/soul.svg", "BGMI", "Fan-favorite champions with historic tournament dominance.", "INV-SOU26", "contact@soulesports.in", "+91 9811122233", 5},
        {"NAV-CS2", "Natus Vincere", "/assets/images/teams/navi.svg", "Counter-Strike 2", "Born to win. Major champions in CS2 global circuit.", "INV-NAV26", "pro@navi.gg", "+358 40-123456", 6},
        {"FAZ-CS2", "FaZe Clan", "/assets/images/teams/faze.svg", "Counter-Strike 2", "Legendary tactical squad known for historic comebacks.", "INV-FAZ26", "esports@fazeclan.com", "+45 20-304050", 7},
        {"TG-FF",   "Total Gaming Esports", "/assets/images/teams/totalgaming.svg", "Free Fire", "Highest rated Free Fire championship squad.", "INV-TG26", "esports@totalgaming.in", "+91 9844455566", 8},
        {"MC-FC",   "Man City Esports", "/assets/images/teams/mancity.svg", "FIFA / EA Sports FC", "Premier ePremier League and global FIFA champions.", "INV-MC26", "gaming@mancity.com", "+44 7911-123456", 9}
    };

    for (const auto& t : teams) {
        executeInsert(
            "INSERT INTO teams (team_code, name, logo_url, captain_id, game_category, description, invitation_code, max_players, contact_email, contact_phone) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 5, ?, ?)",
            {t.code, t.name, t.logo, std::to_string(t.captainUserId), t.game, t.desc, t.inv, t.email, t.phone}
        );
    }

    // 4. 30 Players (users + players table)
    struct PlayerSeed {
        std::string un, em, name, gameId, game, role;
        int teamId;
        int played, won, lost, mvps;
        double rating;
    };

    std::vector<PlayerSeed> demoPlayers = {
        // Sentinels (Team 1, Valorant)
        {"tenz", "tenz@sentinels.gg", "Tyson Ngo", "SEN_TenZ#NA1", "Valorant", "Duelist / Initiator", 1, 14, 11, 3, 5, 1480.0},
        {"zekken", "zekken@sentinels.gg", "Zachary Patrone", "SEN_Zekken#NA1", "Valorant", "Entry Fragger", 1, 14, 11, 3, 4, 1420.0},
        {"sacy", "sacy@sentinels.gg", "Gustavo Rossi", "SEN_Sacy#BR1", "Valorant", "Initiator / Support", 1, 14, 11, 3, 2, 1370.0},
        {"johnqt", "johnqt@sentinels.gg", "Amine Ouarid", "SEN_Johnqt#IGL", "Valorant", "In-Game Leader", 1, 14, 11, 3, 1, 1350.0},

        // Fnatic (Team 2, Valorant)
        {"derke", "derke@fnatic.com", "Nikita Sirmitev", "FNC_Derke#EU1", "Valorant", "Duelist / Op", 2, 16, 12, 4, 6, 1495.0},
        {"alfajer", "alfajer@fnatic.com", "Emir Beder", "FNC_Alfajer#TR1", "Valorant", "Sentinel / Anchor", 2, 16, 12, 4, 4, 1440.0},
        {"chronicle", "chronicle@fnatic.com", "Timofey Khromov", "FNC_Chronicle#EU", "Valorant", "Flex / Controller", 2, 16, 12, 4, 3, 1390.0},
        {"leo", "leo@fnatic.com", "Leo Jannesson", "FNC_Leo#SWE", "Valorant", "Initiator / Recon", 2, 16, 12, 4, 2, 1380.0},

        // GodLike Esports (Team 3, BGMI)
        {"neyoo", "neyoo@godlike.in", "Suraj Majumdar", "GDL_Neyoo#99", "BGMI", "Assaulter", 3, 20, 15, 5, 4, 1410.0},
        {"zgod", "zgod@godlike.in", "Abhishek Choudhary", "GDL_ZGOD#77", "BGMI", "Support / Healer", 3, 20, 15, 5, 2, 1340.0},
        {"shadow", "shadow@godlike.in", "Arjun Mandhalkar", "GDL_Shadow#IGL", "BGMI", "In-Game Leader", 3, 20, 15, 5, 1, 1320.0},
        {"spower", "spower@godlike.in", "Rudra B", "GDL_Spower#01", "BGMI", "Entry Fragger", 3, 20, 15, 5, 5, 1450.0},

        // Soul Esports (Team 4, BGMI)
        {"scout", "scout@soulesports.in", "Tanmay Singh", "SOU_ScoutOP#TX", "BGMI", "Flanker / DMR Specialist", 4, 18, 13, 5, 5, 1430.0},
        {"goblin", "goblin@soulesports.in", "Harsh Paudwal", "SOU_Goblin#99", "BGMI", "Aggressive Assaulter", 4, 18, 13, 5, 6, 1460.0},
        {"hector", "hector@soulesports.in", "Sohail Shaikh", "SOU_Hector#07", "BGMI", "Support / Granadier", 4, 18, 13, 5, 2, 1330.0},
        {"omega", "omega@soulesports.in", "Sahil Jakhar", "SOU_Omega#IGL", "BGMI", "In-Game Leader", 4, 18, 13, 5, 1, 1310.0},

        // Natus Vincere (Team 5, CS2)
        {"b1t", "b1t@navi.gg", "Valerij Vakhovsjkyj", "b1t_Headshot#UA", "Counter-Strike 2", "Rifler / Headshot Machine", 5, 22, 17, 5, 5, 1470.0},
        {"jl", "jl@navi.gg", "Justinas Lekavicius", "jL_Clutch#LT", "Counter-Strike 2", "Entry Fragger / Major MVP", 5, 22, 17, 5, 7, 1510.0},
        {"im", "im@navi.gg", "Mihai Ivan", "iM_Rifle#RO", "Counter-Strike 2", "Second Entry", 5, 22, 17, 5, 2, 1360.0},
        {"w0nderful", "w0nderful@navi.gg", "Ihor Zhdanov", "w0nderful#AWP", "Counter-Strike 2", "Main Sniper / AWP", 5, 22, 17, 5, 4, 1435.0},

        // FaZe Clan (Team 6, CS2)
        {"ropz", "ropz@faze.gg", "Robin Kool", "ropz_Lurker#EE", "Counter-Strike 2", "Lurker / Clutch King", 6, 21, 15, 6, 6, 1490.0},
        {"broky", "broky@faze.gg", "Helvijs Saukants", "broky_AWP#LV", "Counter-Strike 2", "Main Sniper / AWP", 6, 21, 15, 6, 5, 1450.0},
        {"rain", "rain@faze.gg", "Havard Nygaard", "rain_IronMan#NO", "Counter-Strike 2", "Entry Fragger", 6, 21, 15, 6, 3, 1380.0},
        {"frozen", "frozen@faze.gg", "David Cernansky", "frozen_Ice#SK", "Counter-Strike 2", "Rifler / Anchor", 6, 21, 15, 6, 4, 1410.0},

        // Total Gaming (Team 7, Free Fire)
        {"fozyajay", "fozy@totalgaming.in", "Fozy Ajay", "TG_Fozy#FF", "Free Fire", "Rusher", 7, 12, 9, 3, 3, 1350.0},
        {"mafiabala", "mafia@totalgaming.in", "Bala Gangadhar", "TG_Mafia#FF", "Free Fire", "Sniper", 7, 12, 9, 3, 2, 1320.0},
        {"daksh", "daksh@totalgaming.in", "Daksh Garg", "TG_Daksh#FF", "Free Fire", "Support", 7, 12, 9, 3, 1, 1290.0},

        // Man City (Team 8, FIFA)
        {"bonanno", "mati@mancity.com", "Matias Bonanno", "MCFC_Bonanno#eClub", "FIFA / EA Sports FC", "Solo Competitor", 8, 15, 12, 3, 4, 1440.0},

        // Free Agents (Unassigned / Can join teams using invite code)
        {"viper_aim", "viper@gmail.com", "Vikram Rathore", "ViperAim#IN", "Valorant", "Duelist / Operator", 0, 8, 5, 3, 1, 1250.0},
        {"cypher_queen", "ananya@gmail.com", "Ananya Deshmukh", "CypherQueen#99", "BGMI", "Assaulter / IGL", 0, 10, 7, 3, 2, 1280.0}
    };

    for (const auto& p : demoPlayers) {
        int uid = executeInsert(
            "INSERT INTO users (username, email, password_hash, role, full_name, phone_number, country, avatar_url) "
            "VALUES (?, ?, ?, 'player', ?, '+91 9000012345', 'India', '/assets/images/avatars/player.svg')",
            {p.un, p.em, playerHash, p.name}
        );

        int pid = executeInsert(
            "INSERT INTO players (user_id, game_id, selected_game, player_role, team_id, matches_played, matches_won, matches_lost, mvp_awards, rating) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            {
                std::to_string(uid), p.gameId, p.game, p.role,
                p.teamId > 0 ? std::to_string(p.teamId) : "NULL",
                std::to_string(p.played), std::to_string(p.won), std::to_string(p.lost),
                std::to_string(p.mvps), std::to_string(p.rating)
            }
        );

        if (p.teamId > 0) {
            executeInsert(
                "INSERT INTO team_members (team_id, player_id, role_in_team) VALUES (?, ?, 'Starter')",
                {std::to_string(p.teamId), std::to_string(pid)}
            );
        }
    }

    // 5. 3 Sample Tournaments
    // Tournament 1: Valorant Champions Invitational 2026 (Ongoing)
    int t1 = executeInsert(
        "INSERT INTO tournaments (name, game_category, description, format, status, start_date, end_date, registration_deadline, max_teams, prize_pool, banner_url, rules) "
        "VALUES ('Valorant Champions Invitational 2026', 'Valorant', 'Premier international 8-team showdown featuring the best tactical fps teams.', 'Single Elimination', 'Ongoing', '2026-11-01 10:00:00', '2026-11-10 22:00:00', '2026-10-28 23:59:59', 8, 50000.0, '/assets/images/tournaments/valorant.jpg', 'Standard VCT rulebook. Riot Vanguard anti-cheat strictly enforced. Best of 3 for quarterfinals and semifinals, Best of 5 for Grand Finals.')"
    );

    // Tournament 2: BGMI Masters Series Pro League (Registration Open)
    int t2 = executeInsert(
        "INSERT INTO tournaments (name, game_category, description, format, status, start_date, end_date, registration_deadline, max_teams, prize_pool, banner_url, rules) "
        "VALUES ('BGMI Masters Series Pro League 2026', 'BGMI', 'National high-stakes mobile battle royale league across Erangel and Miramar.', 'Group Stage + Knockout', 'Registration Open', '2026-11-15 14:00:00', '2026-11-25 21:00:00', '2026-11-12 18:00:00', 8, 75000.0, '/assets/images/tournaments/bgmi.jpg', 'Official BGIS points system (10 pts for WWCD, 1 pt per elimination). Strict device check and live telemetry recordings required.')"
    );

    // Tournament 3: CS2 Global Showdown Major (Completed)
    int t3 = executeInsert(
        "INSERT INTO tournaments (name, game_category, description, format, status, start_date, end_date, registration_deadline, max_teams, prize_pool, banner_url, rules, winner_team_id, runner_up_team_id) "
        "VALUES ('CS2 Global Showdown Major', 'Counter-Strike 2', 'World championship tier-1 CS2 bracket with historic rivalry finals.', 'Single Elimination', 'Completed', '2026-10-10 12:00:00', '2026-10-20 23:00:00', '2026-10-05 23:59:59', 8, 100000.0, '/assets/images/tournaments/cs2.jpg', 'Valve Major Ruleset, MR12, Overtime MR3 with $10,000 start cash. VAC and tournament anticheat mandatory.', 5, 6)"
    );

    // Tournament Registrations
    // For T1: Sentinels (1) and Fnatic (2) Approved
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 1, 'Approved', 1, 'Roster verified & eligible.')", {std::to_string(t1)});
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 2, 'Approved', 1, 'Roster verified & eligible.')", {std::to_string(t1)});

    // For T2: GodLike (3) Approved, Soul (4) Approved, Total Gaming (7) Pending
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 3, 'Approved', 1, 'Verified official BGMI tier-1 lineup.')", {std::to_string(t2)});
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 4, 'Approved', 1, 'Registration validated.')", {std::to_string(t2)});
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status) VALUES (?, 7, 'Pending')", {std::to_string(t2)});

    // For T3: NaVi (5) and FaZe (6) Approved
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 5, 'Approved', 1, 'Completed tournament participant.')", {std::to_string(t3)});
    executeInsert("INSERT INTO tournament_registrations (tournament_id, team_id, status, reviewed_by, review_notes) VALUES (?, 6, 'Approved', 1, 'Completed tournament participant.')", {std::to_string(t3)});

    // 6. Matches
    // Match 1: Valorant Invitational - Sentinels vs Fnatic (Live!)
    int m1 = executeInsert(
        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, team_a_score, team_b_score, scheduled_time, slot_info, status, is_verified) "
        "VALUES (?, 1, 1, 'Winners', 1, 2, 1, 1, '2026-11-01 18:30:00', 'Main Stage - Stream A', 'Live', 0)",
        {std::to_string(t1)}
    );

    // Match 2: BGMI Masters - GodLike vs Soul (Upcoming)
    int m2 = executeInsert(
        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, team_a_score, team_b_score, scheduled_time, slot_info, status, is_verified) "
        "VALUES (?, 1, 1, 'Group', 3, 4, 0, 0, '2026-11-15 17:00:00', 'Arena Stage 2', 'Upcoming', 0)",
        {std::to_string(t2)}
    );

    // Match 3: CS2 Major Grand Finals - NaVi vs FaZe (Completed)
    int m3 = executeInsert(
        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, team_a_score, team_b_score, scheduled_time, slot_info, status, winner_team_id, mvp_player_id, is_verified, verified_by, submission_notes) "
        "VALUES (?, 2, 1, 'Finals', 5, 6, 2, 1, '2026-10-20 20:00:00', 'Copenhagen Royal Arena', 'Completed', 5, 18, 1, 1, 'Map 1: Mirage (13-9 NaVi), Map 2: Nuke (11-13 FaZe), Map 3: Inferno (13-10 NaVi). Verified by Head Referee.')",
        {std::to_string(t3)}
    );

    // Match 4: Sentinels Semi-Finals Result Under Review (Demo Dispute scenario)
    int m4 = executeInsert(
        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, team_a_score, team_b_score, scheduled_time, slot_info, status, is_verified, submitted_by, submission_notes) "
        "VALUES (?, 1, 2, 'Winners', 1, 2, 13, 11, '2026-10-30 19:00:00', 'Broadcast Studio 1', 'Under Review', 0, 2, 'Score submitted by Captain ShahZaM: 13-11. Pending admin verification.')",
        {std::to_string(t1)}
    );

    // 7. Match Results Details
    executeInsert(
        "INSERT INTO match_results (match_id, map_name, round_details, evidence_screenshot) "
        "VALUES (?, 'Mirage & Inferno', 'NaVi won 2-1 against FaZe in a thrilling MR12 series.', '/assets/images/matches/cs2-result.jpg')",
        {std::to_string(m3)}
    );

    // 8. Sample Dispute
    executeInsert(
        "INSERT INTO disputes (match_id, raised_by, team_id, reason, evidence_url, status, admin_notes) "
        "VALUES (?, 3, 2, 'Server ping spike during Round 21 tactical buy. Requesting round replay according to section 4.2 of rulebook.', '/assets/images/disputes/ping-log.png', 'Open', 'Under admin review. Server telemetry being examined.')",
        {std::to_string(m4)}
    );

    // 9. Prizes for CS2 Major
    executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount, team_id) VALUES (?, 1, '1st Place Champions Cup + Major Ring', 60000.0, 5)", {std::to_string(t3)});
    executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount, team_id) VALUES (?, 2, 'Runner-up Silver Plaque', 25000.0, 6)", {std::to_string(t3)});
    executeInsert("INSERT INTO prizes (tournament_id, place, reward_title, reward_amount, team_id) VALUES (?, 3, '3rd Place Bronze Medal', 15000.0, 1)", {std::to_string(t3)});

    // 10. Notifications
    executeInsert("INSERT INTO notifications (user_id, title, message, type, link_url) VALUES (1, 'New Team Registration', 'Total Gaming registered for BGMI Masters Series Pro League. Action required.', 'registration', '/admin-dashboard.html')");
    executeInsert("INSERT INTO notifications (user_id, title, message, type, link_url) VALUES (2, 'Match Live Now', 'Sentinels vs Fnatic has started! Good luck captain.', 'match', '/scoreboard.html')");
    executeInsert("INSERT INTO notifications (user_id, title, message, type, link_url) VALUES (3, 'Dispute Filed', 'A dispute has been logged for match #4. Admin is investigating.', 'dispute', '/disputes.html')");

    // 11. Initial Activity Logs
    logActivity(1, "SYSTEM_INIT", "Database initialized and initial demo seed data injected.");
    logActivity(1, "TOURNAMENT_CREATED", "Tournament 'Valorant Champions Invitational 2026' initialized.");
    logActivity(2, "SCORE_SUBMITTED", "Captain ShahZaM submitted match result for Match #4.");

    // 12. Leaderboard Seed
    // Sentinels
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 1, 'Valorant', 8, 7, 1, 0, 21, 104, 72, 87.5, 'WWLWW')", {std::to_string(t1)});
    // Fnatic
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 2, 'Valorant', 8, 6, 2, 0, 18, 98, 80, 75.0, 'WLWWW')", {std::to_string(t1)});
    // NaVi
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 5, 'Counter-Strike 2', 10, 9, 1, 0, 27, 130, 85, 90.0, 'WWWWW')", {std::to_string(t3)});
    // FaZe
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 6, 'Counter-Strike 2', 10, 7, 3, 0, 21, 118, 102, 70.0, 'LWWLW')", {std::to_string(t3)});
    // GodLike
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 3, 'BGMI', 12, 9, 3, 0, 27, 154, 110, 75.0, 'WWWLL')", {std::to_string(t2)});
    // Soul
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (?, 4, 'BGMI', 12, 8, 4, 0, 24, 142, 118, 66.7, 'WWLWW')", {std::to_string(t2)});
    // Total Gaming
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (NULL, 7, 'Free Fire', 6, 4, 2, 0, 12, 68, 54, 66.7, 'LWWLW')");
    // Man City
    executeInsert("INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) VALUES (NULL, 8, 'FIFA / EA Sports FC', 8, 6, 1, 1, 19, 32, 14, 81.25, 'WWWDW')");

    std::cout << "Realistic demo data seeded successfully!" << std::endl;
    return true;
}

} // namespace Esports

