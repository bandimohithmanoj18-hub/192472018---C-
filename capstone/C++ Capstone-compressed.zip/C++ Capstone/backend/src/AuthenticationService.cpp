#include "../include/services/AuthenticationService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/Sha256.h"
#include <random>
#include <sstream>
#include <iomanip>
#include <chrono>

namespace Esports {

std::shared_ptr<AuthenticationService> AuthenticationService::s_instance = nullptr;

AuthenticationService::AuthenticationService() {}

std::shared_ptr<AuthenticationService> AuthenticationService::getInstance() {
    if (!s_instance) {
        s_instance = std::make_shared<AuthenticationService>();
    }
    return s_instance;
}

std::string AuthenticationService::hashPassword(const std::string& password) {
    // Generate 16-character random cryptographic salt
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dis;
    std::ostringstream oss;
    oss << std::hex << std::setfill('0') << std::setw(16) << dis(gen);
    std::string salt = oss.str();

    // Store as salt$sha256(salt + password)
    std::string digest = SHA256::hash(salt + ":" + password);
    return salt + "$" + digest;
}

bool AuthenticationService::verifyPassword(const std::string& password, const std::string& storedHash) {
    // Check if hash is in salt$digest format
    size_t dollar = storedHash.find('$');
    if (dollar != std::string::npos) {
        std::string salt = storedHash.substr(0, dollar);
        std::string expectedDigest = storedHash.substr(dollar + 1);
        std::string computedDigest = SHA256::hash(salt + ":" + password);
        return computedDigest == expectedDigest;
    }
    // Backward compatibility for legacy unsalted hashes (e.g. seeded demo accounts)
    return SHA256::hash(password) == storedHash;
}

std::string AuthenticationService::createSession(int userId, const std::string& username, const std::string& role) {
    std::lock_guard<std::mutex> lock(m_sessionMutex);

    // Generate random 32-character hex token
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dis;

    std::ostringstream oss;
    oss << std::hex << std::setfill('0')
        << std::setw(16) << dis(gen)
        << std::setw(16) << dis(gen);

    std::string token = "esp_" + oss.str();

    SessionInfo info;
    info.userId = userId;
    info.username = username;
    info.role = role;
    info.expiresAt = "2099-12-31"; // Persistent session lifetime

    // Fast in-memory cache
    m_sessions[token] = info;

    // Persist to SQLite sessions table
    auto db = DatabaseService::getInstance();
    if (db) {
        db->executeInsert(
            "INSERT OR REPLACE INTO sessions (token, user_id, username, role, expires_at) VALUES (?, ?, ?, ?, ?)",
            {token, std::to_string(userId), username, role, info.expiresAt}
        );
    }

    return token;
}

bool AuthenticationService::validateSession(const std::string& token, SessionInfo& outSession) {
    if (token.empty()) return false;
    std::lock_guard<std::mutex> lock(m_sessionMutex);

    // 1. Check in-memory session cache first
    auto it = m_sessions.find(token);
    if (it != m_sessions.end()) {
        outSession = it->second;
        return true;
    }

    // 2. Query persistent SQLite database (survives server restarts)
    auto db = DatabaseService::getInstance();
    if (db) {
        auto rows = db->queryJson("SELECT user_id, username, role, expires_at FROM sessions WHERE token = ?", {token});
        if (!rows.empty()) {
            outSession.userId = static_cast<int>(rows[0]["user_id"].get<int64_t>());
            outSession.username = rows[0].value("username", "");
            outSession.role = rows[0].value("role", "player");
            outSession.expiresAt = rows[0].value("expires_at", "2099-12-31");

            // Re-populate in-memory cache
            m_sessions[token] = outSession;
            return true;
        }
    }

    return false;
}

void AuthenticationService::invalidateSession(const std::string& token) {
    std::lock_guard<std::mutex> lock(m_sessionMutex);
    m_sessions.erase(token);
    auto db = DatabaseService::getInstance();
    if (db) {
        db->executeInsert("DELETE FROM sessions WHERE token = ?", {token});
    }
}

bool AuthenticationService::requireRole(const std::string& token, const std::string& requiredRole, SessionInfo& outSession) {
    if (!validateSession(token, outSession)) {
        return false;
    }
    if (requiredRole.empty() || outSession.role == "admin") {
        return true; // Admin has superuser access
    }
    return outSession.role == requiredRole;
}

nlohmann::json AuthenticationService::login(const std::string& usernameOrEmail, const std::string& password) {
    auto db = DatabaseService::getInstance();
    std::string sql = "SELECT * FROM users WHERE username = ? OR email = ?";
    auto rows = db->queryJson(sql, {usernameOrEmail, usernameOrEmail});

    if (rows.empty()) {
        return {
            {"success", false},
            {"message", "Invalid username/email or password"}
        };
    }

    auto userRow = rows[0];
    std::string dbHash = userRow.value("password_hash", "");

    if (!verifyPassword(password, dbHash)) {
        return {
            {"success", false},
            {"message", "Invalid username/email or password"}
        };
    }

    int userId = static_cast<int>(userRow["id"].get<int64_t>());
    std::string username = userRow.value("username", "");
    std::string role = userRow.value("role", "player");

    std::string token = createSession(userId, username, role);

    // Retrieve associated team if captain or player
    int teamId = 0;
    std::string teamName = "";
    if (role == "captain") {
        auto teamRows = db->queryJson("SELECT id, name FROM teams WHERE captain_id = ?", {std::to_string(userId)});
        if (!teamRows.empty()) {
            teamId = static_cast<int>(teamRows[0]["id"].get<int64_t>());
            teamName = teamRows[0].value("name", "");
        }
    } else if (role == "player") {
        auto playerRows = db->queryJson("SELECT team_id FROM players WHERE user_id = ?", {std::to_string(userId)});
        if (!playerRows.empty() && !playerRows[0]["team_id"].is_null()) {
            teamId = static_cast<int>(playerRows[0]["team_id"].get<int64_t>());
            auto teamRows = db->queryJson("SELECT name FROM teams WHERE id = ?", {std::to_string(teamId)});
            if (!teamRows.empty()) teamName = teamRows[0].value("name", "");
        }
    }

    db->logActivity(userId, "USER_LOGIN", "User logged in with role: " + role);

    return {
        {"success", true},
        {"message", "Login successful"},
        {"token", token},
        {"user", {
            {"id", userId},
            {"username", username},
            {"email", userRow.value("email", "")},
            {"role", role},
            {"fullName", userRow.value("full_name", "")},
            {"country", userRow.value("country", "India")},
            {"avatarUrl", userRow.value("avatar_url", "/assets/images/default-avatar.svg")},
            {"teamId", teamId},
            {"teamName", teamName}
        }}
    };
}

nlohmann::json AuthenticationService::registerPlayer(const nlohmann::json& p) {
    auto db = DatabaseService::getInstance();

    std::string username = p.value("username", "");
    std::string email = p.value("email", "");
    std::string password = p.value("password", "");
    std::string fullName = p.value("fullName", "");
    std::string phone = p.value("phoneNumber", "");
    std::string country = p.value("country", "India");
    std::string gameId = p.value("gameId", "");
    std::string selectedGame = p.value("selectedGame", "Valorant");
    std::string playerRole = p.value("playerRole", "Rifler / Assaulter");

    // Validation
    if (username.empty() || email.empty() || password.empty() || fullName.empty() || gameId.empty()) {
        return {{"success", false}, {"message", "All mandatory registration fields must be provided."}};
    }

    // Check duplicate username or email
    auto check = db->queryJson("SELECT id FROM users WHERE username = ? OR email = ?", {username, email});
    if (!check.empty()) {
        return {{"success", false}, {"message", "A user with this username or email already exists."}};
    }

    // Check duplicate gameId in the same game
    auto checkGameId = db->queryJson("SELECT id FROM players WHERE game_id = ? AND selected_game = ?", {gameId, selectedGame});
    if (!checkGameId.empty()) {
        return {{"success", false}, {"message", "Game ID is already registered for this game category."}};
    }

    std::string hashed = hashPassword(password);
    int userId = db->executeInsert(
        "INSERT INTO users (username, email, password_hash, role, full_name, phone_number, country, avatar_url) "
        "VALUES (?, ?, ?, 'player', ?, ?, ?, '/assets/images/avatars/player.svg')",
        {username, email, hashed, fullName, phone, country}
    );

    if (userId <= 0) {
        return {{"success", false}, {"message", "Database insertion failed."}};
    }

    int playerId = db->executeInsert(
        "INSERT INTO players (user_id, game_id, selected_game, player_role, matches_played, matches_won, matches_lost, mvp_awards, rating) "
        "VALUES (?, ?, ?, ?, 0, 0, 0, 0, 1200.0)",
        {std::to_string(userId), gameId, selectedGame, playerRole}
    );

    db->logActivity(userId, "REGISTER_PLAYER", "New player registered: " + username + " (" + gameId + ")");

    std::string token = createSession(userId, username, "player");

    return {
        {"success", true},
        {"message", "Player registration successful!"},
        {"token", token},
        {"user", {
            {"id", userId},
            {"playerId", playerId},
            {"username", username},
            {"email", email},
            {"role", "player"},
            {"fullName", fullName},
            {"gameId", gameId},
            {"selectedGame", selectedGame},
            {"playerRole", playerRole},
            {"country", country},
            {"avatarUrl", "/assets/images/avatars/player.svg"}
        }}
    };
}

nlohmann::json AuthenticationService::registerCaptain(const nlohmann::json& p) {
    auto db = DatabaseService::getInstance();

    std::string username = p.value("username", "");
    std::string email = p.value("email", "");
    std::string password = p.value("password", "");
    std::string fullName = p.value("fullName", "");
    std::string phone = p.value("phoneNumber", "");
    std::string country = p.value("country", "India");

    if (username.empty() || email.empty() || password.empty() || fullName.empty()) {
        return {{"success", false}, {"message", "Username, email, password, and full name are required."}};
    }

    auto check = db->queryJson("SELECT id FROM users WHERE username = ? OR email = ?", {username, email});
    if (!check.empty()) {
        return {{"success", false}, {"message", "A user with this username or email already exists."}};
    }

    std::string hashed = hashPassword(password);
    int userId = db->executeInsert(
        "INSERT INTO users (username, email, password_hash, role, full_name, phone_number, country, avatar_url) "
        "VALUES (?, ?, ?, 'captain', ?, ?, ?, '/assets/images/avatars/captain.svg')",
        {username, email, hashed, fullName, phone, country}
    );

    if (userId <= 0) {
        return {{"success", false}, {"message", "Database insertion failed."}};
    }

    db->logActivity(userId, "REGISTER_CAPTAIN", "New team captain registered: " + username);
    std::string token = createSession(userId, username, "captain");

    return {
        {"success", true},
        {"message", "Captain registration successful! You can now register your esports team."},
        {"token", token},
        {"user", {
            {"id", userId},
            {"username", username},
            {"email", email},
            {"role", "captain"},
            {"fullName", fullName},
            {"country", country},
            {"avatarUrl", "/assets/images/avatars/captain.svg"}
        }}
    };
}

nlohmann::json AuthenticationService::getCurrentUser(const std::string& token) {
    SessionInfo session;
    if (!validateSession(token, session)) {
        return {{"success", false}, {"message", "Unauthorized or invalid session token"}};
    }

    auto db = DatabaseService::getInstance();
    auto rows = db->queryJson("SELECT id, username, email, role, full_name, phone_number, country, avatar_url, created_at FROM users WHERE id = ?",
                              {std::to_string(session.userId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "User not found"}};
    }

    auto user = rows[0];
    int userId = session.userId;
    std::string role = session.role;

    nlohmann::json extra = nlohmann::json::object();
    if (role == "captain") {
        auto teamRows = db->queryJson("SELECT * FROM teams WHERE captain_id = ?", {std::to_string(userId)});
        if (!teamRows.empty()) {
            extra["team"] = teamRows[0];
        }
    } else if (role == "player") {
        auto pRows = db->queryJson("SELECT p.*, t.name as team_name, t.logo_url as team_logo FROM players p LEFT JOIN teams t ON p.team_id = t.id WHERE p.user_id = ?",
                                   {std::to_string(userId)});
        if (!pRows.empty()) {
            extra["player"] = pRows[0];
        }
    }

    return {
        {"success", true},
        {"user", user},
        {"extra", extra}
    };
}

nlohmann::json AuthenticationService::updateProfile(int userId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();

    std::string fullName = payload.value("fullName", "");
    std::string phone = payload.value("phoneNumber", "");
    std::string country = payload.value("country", "");
    std::string avatarUrl = payload.value("avatarUrl", "");

    db->executeUpdate(
        "UPDATE users SET full_name = COALESCE(NULLIF(?, ''), full_name), "
        "phone_number = COALESCE(NULLIF(?, ''), phone_number), "
        "country = COALESCE(NULLIF(?, ''), country), "
        "avatar_url = COALESCE(NULLIF(?, ''), avatar_url) WHERE id = ?",
        {fullName, phone, country, avatarUrl, std::to_string(userId)}
    );

    db->logActivity(userId, "UPDATE_PROFILE", "User updated profile details.");
    return {{"success", true}, {"message", "Profile updated successfully"}};
}

nlohmann::json AuthenticationService::changePassword(int userId, const std::string& oldPass, const std::string& newPass) {
    auto db = DatabaseService::getInstance();
    auto rows = db->queryJson("SELECT password_hash FROM users WHERE id = ?", {std::to_string(userId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "User not found"}};
    }

    std::string currentHash = rows[0].value("password_hash", "");
    if (!verifyPassword(oldPass, currentHash)) {
        return {{"success", false}, {"message", "Current password is incorrect."}};
    }

    if (newPass.length() < 6) {
        return {{"success", false}, {"message", "New password must be at least 6 characters long."}};
    }

    std::string newHash = hashPassword(newPass);
    db->executeUpdate("UPDATE users SET password_hash = ? WHERE id = ?", {newHash, std::to_string(userId)});
    db->logActivity(userId, "CHANGE_PASSWORD", "User successfully changed password.");

    return {{"success", true}, {"message", "Password changed successfully!"}};
}

} // namespace Esports

