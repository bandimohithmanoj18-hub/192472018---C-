#include "../include/services/MatchService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/NotificationService.h"

namespace Esports {

std::shared_ptr<MatchService> MatchService::s_instance = nullptr;

MatchService::MatchService() {}

std::shared_ptr<MatchService> MatchService::getInstance() {
    if (!s_instance) s_instance = std::make_shared<MatchService>();
    return s_instance;
}

nlohmann::json MatchService::getAllMatches(int tournamentId, const std::string& status, const std::string& game) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT m.*, t.name as tournament_name, t.game_category, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, "
        "w.name as winner_name, w.logo_url as winner_logo, "
        "mvpU.full_name as mvp_name "
        "FROM matches m "
        "JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "LEFT JOIN players mvpP ON m.mvp_player_id = mvpP.id "
        "LEFT JOIN users mvpU ON mvpP.user_id = mvpU.id "
        "WHERE 1=1 ";
    std::vector<std::string> params;
    if (tournamentId > 0) {
        sql += " AND m.tournament_id = ? ";
        params.push_back(std::to_string(tournamentId));
    }
    if (!status.empty()) {
        sql += " AND m.status = ? ";
        params.push_back(status);
    }
    if (!game.empty()) {
        sql += " AND t.game_category = ? ";
        params.push_back(game);
    }
    sql += " ORDER BY m.scheduled_time ASC";
    return db->queryJson(sql, params);
}

nlohmann::json MatchService::getMatchById(int matchId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT m.*, t.name as tournament_name, t.game_category, t.rules as tournament_rules, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, tA.team_code as team_a_code, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, tB.team_code as team_b_code, "
        "w.name as winner_name, w.logo_url as winner_logo, "
        "mvpU.full_name as mvp_name, mvpU.username as mvp_username, "
        "subU.full_name as submitted_by_name "
        "FROM matches m "
        "JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "LEFT JOIN players mvpP ON m.mvp_player_id = mvpP.id "
        "LEFT JOIN users mvpU ON mvpP.user_id = mvpU.id "
        "LEFT JOIN users subU ON m.submitted_by = subU.id "
        "WHERE m.id = ?";
    auto rows = db->queryJson(sql, {std::to_string(matchId)});
    if (rows.empty()) return {{"success", false}, {"message", "Match not found."}};
    return {{"success", true}, {"match", rows[0]}};
}

nlohmann::json MatchService::scheduleMatch(int adminUserId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();
    int tournamentId = payload.value("tournamentId", 0);
    int teamAId = payload.value("teamAId", 0);
    int teamBId = payload.value("teamBId", 0);
    std::string scheduledTime = payload.value("scheduledTime", "2026-11-20 18:00:00");
    std::string slotInfo = payload.value("slotInfo", "Main Stage Arena 1");
    int roundNumber = payload.value("roundNumber", 1);
    int matchNumber = payload.value("matchNumber", 1);
    std::string bracketType = payload.value("bracketType", "Winners");

    if (tournamentId == 0 || teamAId == 0 || teamBId == 0) {
        return {{"success", false}, {"message", "Tournament and both teams are required."}};
    }
    if (teamAId == teamBId) {
        return {{"success", false}, {"message", "A team cannot play against itself."}};
    }

    // Check duplicate in same tournament, round, match slot
    auto dupCheck = db->queryJson(
        "SELECT id FROM matches WHERE tournament_id = ? AND round_number = ? AND match_number = ?",
        {std::to_string(tournamentId), std::to_string(roundNumber), std::to_string(matchNumber)}
    );
    if (!dupCheck.empty()) {
        return {{"success", false}, {"message", "A match already exists in Round " + std::to_string(roundNumber) + ", Slot " + std::to_string(matchNumber) + "."}};
    }

    int mId = db->executeInsert(
        "INSERT INTO matches (tournament_id, round_number, match_number, bracket_type, team_a_id, team_b_id, scheduled_time, slot_info, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Upcoming')",
        {std::to_string(tournamentId), std::to_string(roundNumber), std::to_string(matchNumber),
         bracketType, std::to_string(teamAId), std::to_string(teamBId), scheduledTime, slotInfo}
    );

    // Notify both team captains
    auto tARow = db->queryJson("SELECT captain_id, name FROM teams WHERE id = ?", {std::to_string(teamAId)});
    auto tBRow = db->queryJson("SELECT captain_id, name FROM teams WHERE id = ?", {std::to_string(teamBId)});
    auto notif = NotificationService::getInstance();
    if (!tARow.empty()) {
        notif->sendNotification(static_cast<int>(tARow[0]["captain_id"].get<int64_t>()),
            "Match Scheduled", "Your match has been scheduled: " + tARow[0].value("name","") + " vs " + (tBRow.empty() ? "TBD" : tBRow[0].value("name","")) + " on " + scheduledTime,
            "match", "/scoreboard.html?id=" + std::to_string(mId));
    }
    if (!tBRow.empty()) {
        notif->sendNotification(static_cast<int>(tBRow[0]["captain_id"].get<int64_t>()),
            "Match Scheduled", "Your match has been scheduled on " + scheduledTime, "match", "/scoreboard.html?id=" + std::to_string(mId));
    }

    db->logActivity(adminUserId, "SCHEDULE_MATCH", "Scheduled match #" + std::to_string(mId) + " for tournament #" + std::to_string(tournamentId));
    return {{"success", true}, {"message", "Match scheduled successfully."}, {"matchId", mId}};
}

nlohmann::json MatchService::updateSchedule(int matchId, int adminUserId, const std::string& scheduledTime, const std::string& slotInfo) {
    auto db = DatabaseService::getInstance();
    db->executeUpdate("UPDATE matches SET scheduled_time = ?, slot_info = ? WHERE id = ?",
                      {scheduledTime, slotInfo, std::to_string(matchId)});
    db->logActivity(adminUserId, "UPDATE_SCHEDULE", "Rescheduled match #" + std::to_string(matchId) + " to " + scheduledTime);
    return {{"success", true}, {"message", "Match schedule updated."}};
}

nlohmann::json MatchService::assignTeams(int matchId, int adminUserId, int teamAId, int teamBId) {
    auto db = DatabaseService::getInstance();
    db->executeUpdate("UPDATE matches SET team_a_id = ?, team_b_id = ? WHERE id = ?",
                      {std::to_string(teamAId), std::to_string(teamBId), std::to_string(matchId)});
    return {{"success", true}, {"message", "Teams assigned to match."}};
}

nlohmann::json MatchService::getUpcomingMatches(int limit) {
    auto db = DatabaseService::getInstance();
    return db->queryJson(
        "SELECT m.*, t.name as tournament_name, t.game_category, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "WHERE m.status IN ('Upcoming', 'Live') "
        "ORDER BY m.scheduled_time ASC LIMIT ?",
        {std::to_string(limit)}
    );
}

nlohmann::json MatchService::getLiveMatches() {
    auto db = DatabaseService::getInstance();
    return db->queryJson(
        "SELECT m.*, t.name as tournament_name, t.game_category, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "WHERE m.status = 'Live' ORDER BY m.scheduled_time ASC"
    );
}

nlohmann::json MatchService::getMatchHistory(int teamId, int limit) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT m.*, t.name as tournament_name, t.game_category, "
        "tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, "
        "w.name as winner_name "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN teams w ON m.winner_team_id = w.id "
        "WHERE m.status = 'Completed' ";
    std::vector<std::string> params;
    if (teamId > 0) {
        sql += " AND (m.team_a_id = ? OR m.team_b_id = ?) ";
        params.push_back(std::to_string(teamId));
        params.push_back(std::to_string(teamId));
    }
    sql += " ORDER BY m.scheduled_time DESC LIMIT ?";
    params.push_back(std::to_string(limit));
    return db->queryJson(sql, params);
}

} // namespace Esports

