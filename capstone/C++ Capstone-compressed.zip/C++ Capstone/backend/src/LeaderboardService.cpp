#include "../include/services/LeaderboardService.h"
#include "../include/services/DatabaseService.h"
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace Esports {

std::shared_ptr<LeaderboardService> LeaderboardService::s_instance = nullptr;
LeaderboardService::LeaderboardService() {}
std::shared_ptr<LeaderboardService> LeaderboardService::getInstance() {
    if (!s_instance) s_instance = std::make_shared<LeaderboardService>();
    return s_instance;
}

// Core C++ ranking engine: recalculates from match data
bool LeaderboardService::recalculateLeaderboard(int tournamentId) {
    auto db = DatabaseService::getInstance();

    // Fetch all completed, verified matches (optionally for one tournament)
    std::string sql =
        "SELECT m.id, m.tournament_id, m.team_a_id, m.team_b_id, "
        "m.team_a_score, m.team_b_score, m.winner_team_id, t.game_category "
        "FROM matches m JOIN tournaments t ON m.tournament_id = t.id "
        "WHERE m.status = 'Completed' AND m.is_verified = 1 ";
    std::vector<std::string> params;
    if (tournamentId > 0) {
        sql += " AND m.tournament_id = ? ";
        params.push_back(std::to_string(tournamentId));
    }

    auto matches = db->queryJson(sql, params);

    // Build leaderboard map: teamId → LeaderboardEntry using STL unordered_map
    std::unordered_map<int, LeaderboardEntry> lbMap;

    for (const auto& m : matches) {
        if (m["team_a_id"].is_null() || m["team_b_id"].is_null()) continue;

        int tAId = static_cast<int>(m["team_a_id"].get<int64_t>());
        int tBId = static_cast<int>(m["team_b_id"].get<int64_t>());
        int scoreA = static_cast<int>(m["team_a_score"].get<int64_t>());
        int scoreB = static_cast<int>(m["team_b_score"].get<int64_t>());
        int winnerId = m["winner_team_id"].is_null() ? 0 : static_cast<int>(m["winner_team_id"].get<int64_t>());
        int tid = static_cast<int>(m["tournament_id"].get<int64_t>());
        std::string gameCategory = m.value("game_category", "");

        // Initialize entries if not present
        if (lbMap.find(tAId) == lbMap.end()) {
            auto teamRows = db->queryJson("SELECT name, logo_url FROM teams WHERE id = ?", {std::to_string(tAId)});
            std::string tName = teamRows.empty() ? "Team A" : teamRows[0].value("name","");
            std::string tLogo = teamRows.empty() ? "" : teamRows[0].value("logo_url","");
            lbMap[tAId] = LeaderboardEntry(tAId, tName, tLogo, gameCategory, tournamentId, 0, 0, 0, 0, 0, 0);
        }
        if (lbMap.find(tBId) == lbMap.end()) {
            auto teamRows = db->queryJson("SELECT name, logo_url FROM teams WHERE id = ?", {std::to_string(tBId)});
            std::string tName = teamRows.empty() ? "Team B" : teamRows[0].value("name","");
            std::string tLogo = teamRows.empty() ? "" : teamRows[0].value("logo_url","");
            lbMap[tBId] = LeaderboardEntry(tBId, tName, tLogo, gameCategory, tournamentId, 0, 0, 0, 0, 0, 0);
        }

        // Apply result: Win=3pts, Draw=1pt, Loss=0pt
        if (winnerId == tAId) {
            lbMap[tAId].addMatchResult('W', scoreA, scoreB);
            lbMap[tBId].addMatchResult('L', scoreB, scoreA);
        } else if (winnerId == tBId) {
            lbMap[tBId].addMatchResult('W', scoreB, scoreA);
            lbMap[tAId].addMatchResult('L', scoreA, scoreB);
        } else {
            // Draw
            lbMap[tAId].addMatchResult('D', scoreA, scoreB);
            lbMap[tBId].addMatchResult('D', scoreB, scoreA);
        }
    }

    // Sort entries using C++ STL sort with custom comparator
    std::vector<LeaderboardEntry> sorted;
    for (auto& pair : lbMap) sorted.push_back(pair.second);
    std::sort(sorted.begin(), sorted.end(), compareLeaderboardEntries);

    // Assign ranks and upsert into database
    for (int rank = 0; rank < static_cast<int>(sorted.size()); rank++) {
        auto& entry = sorted[rank];
        entry.setRank(rank + 1);

        // Format win_percentage to 1 decimal
        std::ostringstream wpStr;
        wpStr << std::fixed << std::setprecision(1) << entry.getWinPercentage();

        // Upsert: update if exists, insert if not
        std::string checkSql = (tournamentId > 0)
            ? "SELECT id FROM leaderboards WHERE team_id = ? AND tournament_id = ?"
            : "SELECT id FROM leaderboards WHERE team_id = ? AND tournament_id IS NULL";
        std::vector<std::string> checkParams = (tournamentId > 0)
            ? std::vector<std::string>{std::to_string(entry.getTeamId()), std::to_string(tournamentId)}
            : std::vector<std::string>{std::to_string(entry.getTeamId())};
        auto existing = db->queryJson(checkSql, checkParams);

        if (!existing.empty()) {
            std::string updSql = (tournamentId > 0)
                ? "UPDATE leaderboards SET matches_played = ?, wins = ?, losses = ?, draws = ?, "
                  "points = ?, total_score = ?, score_against = ?, win_percentage = ?, recent_form = ?, "
                  "updated_at = CURRENT_TIMESTAMP WHERE team_id = ? AND tournament_id = ?"
                : "UPDATE leaderboards SET matches_played = ?, wins = ?, losses = ?, draws = ?, "
                  "points = ?, total_score = ?, score_against = ?, win_percentage = ?, recent_form = ?, "
                  "updated_at = CURRENT_TIMESTAMP WHERE team_id = ? AND tournament_id IS NULL";
            std::vector<std::string> updParams = {
                std::to_string(entry.getMatchesPlayed()), std::to_string(entry.getWins()),
                std::to_string(entry.getLosses()), std::to_string(entry.getDraws()),
                std::to_string(entry.getPoints()), std::to_string(entry.getTotalScore()),
                std::to_string(entry.getScoreAgainst()), wpStr.str(),
                entry.getRecentForm(), std::to_string(entry.getTeamId())
            };
            if (tournamentId > 0) updParams.push_back(std::to_string(tournamentId));
            db->executeUpdate(updSql, updParams);
        } else {
            db->executeInsert(
                "INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                {tournamentId > 0 ? std::to_string(tournamentId) : "NULL",
                 std::to_string(entry.getTeamId()), entry.getGameCategory(),
                 std::to_string(entry.getMatchesPlayed()), std::to_string(entry.getWins()),
                 std::to_string(entry.getLosses()), std::to_string(entry.getDraws()),
                 std::to_string(entry.getPoints()), std::to_string(entry.getTotalScore()),
                 std::to_string(entry.getScoreAgainst()), wpStr.str(), entry.getRecentForm()}
            );
        }
    }

    return true;
}

nlohmann::json LeaderboardService::getGlobalLeaderboard(const std::string& gameCategory, int limit) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT l.*, t.name as team_name, t.logo_url as team_logo, t.game_category as team_game, "
        "t.team_code, u.full_name as captain_name "
        "FROM leaderboards l JOIN teams t ON l.team_id = t.id "
        "LEFT JOIN users u ON t.captain_id = u.id "
        "WHERE l.tournament_id IS NULL ";
    std::vector<std::string> params;
    if (!gameCategory.empty()) {
        sql += " AND l.game_category = ? ";
        params.push_back(gameCategory);
    }
    sql += " ORDER BY l.points DESC, l.win_percentage DESC, l.total_score DESC LIMIT ?";
    params.push_back(std::to_string(limit));
    return db->queryJson(sql, params);
}

nlohmann::json LeaderboardService::getTournamentLeaderboard(int tournamentId) {
    auto db = DatabaseService::getInstance();
    return db->queryJson(
        "SELECT l.*, t.name as team_name, t.logo_url as team_logo, t.game_category as team_game, "
        "t.team_code, u.full_name as captain_name "
        "FROM leaderboards l JOIN teams t ON l.team_id = t.id "
        "LEFT JOIN users u ON t.captain_id = u.id "
        "WHERE l.tournament_id = ? "
        "ORDER BY l.points DESC, l.win_percentage DESC, l.total_score DESC",
        {std::to_string(tournamentId)}
    );
}

nlohmann::json LeaderboardService::getTopThreeTeams(const std::string& gameCategory) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT l.*, t.name as team_name, t.logo_url as team_logo "
        "FROM leaderboards l JOIN teams t ON l.team_id = t.id "
        "WHERE l.tournament_id IS NULL ";
    std::vector<std::string> params;
    if (!gameCategory.empty()) { sql += " AND l.game_category = ? "; params.push_back(gameCategory); }
    sql += " ORDER BY l.points DESC, l.win_percentage DESC LIMIT 3";
    return db->queryJson(sql, params);
}

nlohmann::json LeaderboardService::getPlayerRankings(const std::string& gameCategory, int limit) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT p.*, u.full_name, u.username, u.avatar_url, u.country, "
        "t.name as team_name, t.logo_url as team_logo, "
        "CASE WHEN p.matches_played > 0 THEN ROUND(p.matches_won * 100.0 / p.matches_played, 1) ELSE 0 END as win_pct "
        "FROM players p JOIN users u ON p.user_id = u.id "
        "LEFT JOIN teams t ON p.team_id = t.id WHERE 1=1 ";
    std::vector<std::string> params;
    if (!gameCategory.empty()) { sql += " AND p.selected_game = ? "; params.push_back(gameCategory); }
    sql += " ORDER BY p.rating DESC, p.matches_won DESC LIMIT ?";
    params.push_back(std::to_string(limit));
    return db->queryJson(sql, params);
}

} // namespace Esports

