#include "../include/services/NotificationService.h"
#include "../include/services/DatabaseService.h"

namespace Esports {

std::shared_ptr<NotificationService> NotificationService::s_instance = nullptr;
NotificationService::NotificationService() {}
std::shared_ptr<NotificationService> NotificationService::getInstance() {
    if (!s_instance) s_instance = std::make_shared<NotificationService>();
    return s_instance;
}

bool NotificationService::sendNotification(int userId, const std::string& title, const std::string& message,
                                           const std::string& type, const std::string& linkUrl) {
    auto db = DatabaseService::getInstance();
    int id = db->executeInsert(
        "INSERT INTO notifications (user_id, title, message, type, link_url) VALUES (?, ?, ?, ?, ?)",
        {std::to_string(userId), title, message, type, linkUrl}
    );
    return id > 0;
}

bool NotificationService::notifyTeam(int teamId, const std::string& title, const std::string& message,
                                     const std::string& type, const std::string& linkUrl) {
    auto db = DatabaseService::getInstance();
    // Notify captain
    auto captainRows = db->queryJson("SELECT captain_id FROM teams WHERE id = ?", {std::to_string(teamId)});
    if (!captainRows.empty()) sendNotification(static_cast<int>(captainRows[0]["captain_id"].get<int64_t>()), title, message, type, linkUrl);
    // Notify players
    auto playerRows = db->queryJson("SELECT p.user_id FROM team_members tm JOIN players p ON tm.player_id = p.id WHERE tm.team_id = ?", {std::to_string(teamId)});
    for (const auto& r : playerRows) sendNotification(static_cast<int>(r["user_id"].get<int64_t>()), title, message, type, linkUrl);
    return true;
}

bool NotificationService::notifyAllAdmins(const std::string& title, const std::string& message,
                                          const std::string& type, const std::string& linkUrl) {
    auto db = DatabaseService::getInstance();
    auto admins = db->queryJson("SELECT id FROM users WHERE role = 'admin'");
    for (const auto& a : admins) sendNotification(static_cast<int>(a["id"].get<int64_t>()), title, message, type, linkUrl);
    return true;
}

bool NotificationService::notifyTournamentParticipants(int tournamentId, const std::string& title,
                                                       const std::string& message, const std::string& type) {
    auto db = DatabaseService::getInstance();
    auto teams = db->queryJson("SELECT team_id FROM tournament_registrations WHERE tournament_id = ? AND status = 'Approved'", {std::to_string(tournamentId)});
    for (const auto& t : teams) notifyTeam(static_cast<int>(t["team_id"].get<int64_t>()), title, message, type);
    return true;
}

nlohmann::json NotificationService::getUserNotifications(int userId, bool unreadOnly, int limit) {
    auto db = DatabaseService::getInstance();
    std::string sql = "SELECT * FROM notifications WHERE user_id = ? ";
    if (unreadOnly) sql += " AND is_read = 0 ";
    sql += " ORDER BY created_at DESC LIMIT ?";
    return db->queryJson(sql, {std::to_string(userId), std::to_string(limit)});
}

bool NotificationService::markAsRead(int notificationId, int userId) {
    auto db = DatabaseService::getInstance();
    return db->executeUpdate("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?",
                             {std::to_string(notificationId), std::to_string(userId)});
}

bool NotificationService::markAllAsRead(int userId) {
    auto db = DatabaseService::getInstance();
    return db->executeUpdate("UPDATE notifications SET is_read = 1 WHERE user_id = ?", {std::to_string(userId)});
}

} // namespace Esports

