#include "../include/services/TeamService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/NotificationService.h"
#include <random>
#include <sstream>
#include <iomanip>

namespace Esports {

std::shared_ptr<TeamService> TeamService::s_instance = nullptr;

TeamService::TeamService() {}

std::shared_ptr<TeamService> TeamService::getInstance() {
    if (!s_instance) {
        s_instance = std::make_shared<TeamService>();
    }
    return s_instance;
}

nlohmann::json TeamService::registerTeam(int captainUserId, const nlohmann::json& payload) {
    auto db = DatabaseService::getInstance();

    std::string name = payload.value("name", "");
    std::string gameCategory = payload.value("gameCategory", "Valorant");
    std::string description = payload.value("description", "");
    std::string logoUrl = payload.value("logoUrl", "/assets/images/default-team.svg");
    int maxPlayers = payload.value("maxPlayers", 5);
    std::string contactEmail = payload.value("contactEmail", "");
    std::string contactPhone = payload.value("contactPhone", "");

    if (name.empty() || gameCategory.empty()) {
        return {{"success", false}, {"message", "Team name and game category are required."}};
    }

    // Check duplicate team name
    auto checkName = db->queryJson("SELECT id FROM teams WHERE name = ?", {name});
    if (!checkName.empty()) {
        return {{"success", false}, {"message", "A team with this name already exists."}};
    }

    // Check if captain already owns a team in this game
    auto checkCaptain = db->queryJson("SELECT id FROM teams WHERE captain_id = ? AND game_category = ?",
                                      {std::to_string(captainUserId), gameCategory});
    if (!checkCaptain.empty()) {
        return {{"success", false}, {"message", "You already manage a team in " + gameCategory + "."}};
    }

    // Generate unique Team Code & Invitation Code
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(1000, 9999);
    int randNum = dis(gen);

    std::string prefix = gameCategory.substr(0, 3);
    for (auto& c : prefix) c = toupper(c);

    std::string teamCode = prefix + "-" + std::to_string(randNum);
    std::string invitationCode = "INV-" + prefix + std::to_string(randNum);

    int teamId = db->executeInsert(
        "INSERT INTO teams (team_code, name, logo_url, captain_id, game_category, description, invitation_code, max_players, contact_email, contact_phone) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        {teamCode, name, logoUrl, std::to_string(captainUserId), gameCategory, description, invitationCode, std::to_string(maxPlayers), contactEmail, contactPhone}
    );

    if (teamId <= 0) {
        return {{"success", false}, {"message", "Failed to insert team into database."}};
    }

    // Notify admins
    auto notif = NotificationService::getInstance();
    notif->notifyAllAdmins("New Team Created", "Team '" + name + "' registered for " + gameCategory + " by captain ID #" + std::to_string(captainUserId), "team", "/admin-dashboard.html");

    // Initialize leaderboard entry for this team
    db->executeInsert(
        "INSERT INTO leaderboards (tournament_id, team_id, game_category, matches_played, wins, losses, draws, points, total_score, score_against, win_percentage, recent_form) "
        "VALUES (NULL, ?, ?, 0, 0, 0, 0, 0, 0, 0, 0.0, '-----')",
        {std::to_string(teamId), gameCategory}
    );

    db->logActivity(captainUserId, "REGISTER_TEAM", "Created team: " + name + " (" + teamCode + ")");

    return {
        {"success", true},
        {"message", "Team registered successfully!"},
        {"teamId", teamId},
        {"teamCode", teamCode},
        {"invitationCode", invitationCode}
    };
}

nlohmann::json TeamService::getAllTeams(const std::string& game, const std::string& search) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT t.*, u.full_name as captain_name, u.username as captain_username, "
        "(SELECT COUNT(*) FROM team_members tm WHERE tm.team_id = t.id) as current_roster_count, "
        "COALESCE(l.points, 0) as total_points, COALESCE(l.wins, 0) as total_wins, COALESCE(l.losses, 0) as total_losses "
        "FROM teams t "
        "LEFT JOIN users u ON t.captain_id = u.id "
        "LEFT JOIN leaderboards l ON l.team_id = t.id AND l.tournament_id IS NULL "
        "WHERE 1=1 ";

    std::vector<std::string> params;
    if (!game.empty()) {
        sql += " AND t.game_category = ? ";
        params.push_back(game);
    }
    if (!search.empty()) {
        sql += " AND (t.name LIKE ? OR t.team_code LIKE ?) ";
        params.push_back("%" + search + "%");
        params.push_back("%" + search + "%");
    }

    sql += " ORDER BY total_points DESC, t.name ASC";
    return db->queryJson(sql, params);
}

nlohmann::json TeamService::getTeamById(int teamId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT t.*, u.full_name as captain_name, u.email as captain_email, u.phone_number as captain_phone "
        "FROM teams t "
        "LEFT JOIN users u ON t.captain_id = u.id "
        "WHERE t.id = ?";
    auto rows = db->queryJson(sql, {std::to_string(teamId)});

    if (rows.empty()) {
        return {{"success", false}, {"message", "Team not found"}};
    }

    auto teamData = rows[0];

    // Aliases for frontend compatibility
    teamData["logo"] = teamData.value("logo_url", "");
    teamData["logoUrl"] = teamData.value("logo_url", "");
    teamData["game"] = teamData.value("game_category", "");
    teamData["gameCategory"] = teamData.value("game_category", "");
    teamData["invitationCode"] = teamData.value("invitation_code", "");
    teamData["inviteCode"] = teamData.value("invitation_code", "");

    // Get team members
    std::string memberSql =
        "SELECT tm.id as membership_id, tm.role_in_team, tm.joined_at, "
        "p.id as player_id, p.game_id, p.selected_game, p.player_role, p.rating, "
        "p.matches_played, p.matches_won, p.matches_lost, p.mvp_awards, "
        "u.full_name, u.username, u.avatar_url, u.country "
        "FROM team_members tm "
        "JOIN players p ON tm.player_id = p.id "
        "JOIN users u ON p.user_id = u.id "
        "WHERE tm.team_id = ? "
        "ORDER BY tm.joined_at ASC";
    auto members = db->queryJson(memberSql, {std::to_string(teamId)});
    for (auto& m : members) {
        m["id"] = m["player_id"];
        m["role"] = m["role_in_team"];
        m["fullName"] = m.value("full_name", "");
    }
    teamData["members"] = members;
    teamData["players"] = members;
    teamData["roster"] = members;

    // Get team recent matches
    std::string matchSql =
        "SELECT m.*, tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, tr.name as tournament_name "
        "FROM matches m "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN tournaments tr ON m.tournament_id = tr.id "
        "WHERE m.team_a_id = ? OR m.team_b_id = ? "
        "ORDER BY m.scheduled_time DESC LIMIT 10";
    auto matches = db->queryJson(matchSql, {std::to_string(teamId), std::to_string(teamId)});
    teamData["recent_matches"] = matches;

    // Get team leaderboard stats
    auto lb = db->queryJson("SELECT * FROM leaderboards WHERE team_id = ? AND tournament_id IS NULL", {std::to_string(teamId)});
    teamData["stats"] = lb.empty() ? nlohmann::json::object() : lb[0];

    return {{"success", true}, {"team", teamData}};
}

nlohmann::json TeamService::getTeamByCaptainId(int captainUserId) {
    auto db = DatabaseService::getInstance();
    auto rows = db->queryJson("SELECT id FROM teams WHERE captain_id = ?", {std::to_string(captainUserId)});
    if (rows.empty()) {
        return {{"success", false}, {"message", "No team found for this captain."}};
    }
    int teamId = static_cast<int>(rows[0]["id"].get<int64_t>());
    return getTeamById(teamId);
}

nlohmann::json TeamService::updateTeam(int teamId, int captainUserId, const nlohmann::json& payload, bool isAdmin) {
    auto db = DatabaseService::getInstance();

    if (!isAdmin) {
        auto check = db->queryJson("SELECT id FROM teams WHERE id = ? AND captain_id = ?",
                                   {std::to_string(teamId), std::to_string(captainUserId)});
        if (check.empty()) {
            return {{"success", false}, {"message", "Unauthorized. You are not the captain of this team."}};
        }
    }

    std::string name = payload.value("name", "");
    std::string game = payload.value("gameCategory", payload.value("game", ""));
    std::string logoUrl = payload.value("logoUrl", payload.value("logo", ""));
    std::string description = payload.value("description", "");
    std::string contactEmail = payload.value("contactEmail", "");
    std::string contactPhone = payload.value("contactPhone", "");

    db->executeUpdate(
        "UPDATE teams SET "
        "name = COALESCE(NULLIF(?, ''), name), "
        "game_category = COALESCE(NULLIF(?, ''), game_category), "
        "logo_url = COALESCE(NULLIF(?, ''), logo_url), "
        "description = COALESCE(NULLIF(?, ''), description), "
        "contact_email = COALESCE(NULLIF(?, ''), contact_email), "
        "contact_phone = COALESCE(NULLIF(?, ''), contact_phone) "
        "WHERE id = ?",
        {name, game, logoUrl, description, contactEmail, contactPhone, std::to_string(teamId)}
    );

    db->logActivity(captainUserId, "UPDATE_TEAM", "Updated team details for team #" + std::to_string(teamId) + (name.empty() ? "" : (" (Name: " + name + ")")));
    return {{"success", true}, {"message", "Team details updated successfully."}};
}

nlohmann::json TeamService::addTeamMember(int teamId, int playerId, const std::string& roleInTeam) {
    auto db = DatabaseService::getInstance();

    // Check roster count limit
    auto countRow = db->queryJson("SELECT COUNT(*) as cnt, max_players FROM team_members tm JOIN teams t ON tm.team_id = t.id WHERE t.id = ? GROUP BY t.max_players", {std::to_string(teamId)});
    if (!countRow.empty()) {
        int64_t cnt = countRow[0]["cnt"].get<int64_t>();
        int64_t maxP = countRow[0]["max_players"].get<int64_t>();
        if (cnt >= maxP) {
            return {{"success", false}, {"message", "Team roster is already full (max " + std::to_string(maxP) + " players)."}};
        }
    }

    // Check if player is already in a team
    auto pRow = db->queryJson("SELECT team_id, user_id FROM players WHERE id = ?", {std::to_string(playerId)});
    if (pRow.empty()) {
        return {{"success", false}, {"message", "Player does not exist."}};
    }
    if (!pRow[0]["team_id"].is_null() && pRow[0]["team_id"].get<int64_t>() > 0) {
        return {{"success", false}, {"message", "Player is already assigned to a team. They must leave first."}};
    }

    // Insert membership
    int mId = db->executeInsert("INSERT INTO team_members (team_id, player_id, role_in_team) VALUES (?, ?, ?)",
                                {std::to_string(teamId), std::to_string(playerId), roleInTeam});
    if (mId <= 0) {
        return {{"success", false}, {"message", "Failed to add member to team."}};
    }

    // Update player's team_id
    db->executeUpdate("UPDATE players SET team_id = ? WHERE id = ?", {std::to_string(teamId), std::to_string(playerId)});

    // Notify player
    int playerUserId = static_cast<int>(pRow[0]["user_id"].get<int64_t>());
    auto notif = NotificationService::getInstance();
    notif->sendNotification(playerUserId, "Joined Team", "You have successfully joined the team roster!", "team", "/player-dashboard.html");

    return {{"success", true}, {"message", "Player successfully added to team roster."}};
}

nlohmann::json TeamService::removeTeamMember(int teamId, int playerId, int requestUserId) {
    auto db = DatabaseService::getInstance();

    // Check permission: must be captain or the player themselves
    auto teamRow = db->queryJson("SELECT captain_id FROM teams WHERE id = ?", {std::to_string(teamId)});
    auto playerRow = db->queryJson("SELECT user_id FROM players WHERE id = ?", {std::to_string(playerId)});

    if (teamRow.empty() || playerRow.empty()) {
        return {{"success", false}, {"message", "Invalid team or player."}};
    }

    int captainId = static_cast<int>(teamRow[0]["captain_id"].get<int64_t>());
    int playerUserId = static_cast<int>(playerRow[0]["user_id"].get<int64_t>());

    if (requestUserId != captainId && requestUserId != playerUserId) {
        return {{"success", false}, {"message", "Unauthorized action."}};
    }

    db->executeUpdate("DELETE FROM team_members WHERE team_id = ? AND player_id = ?",
                      {std::to_string(teamId), std::to_string(playerId)});
    db->executeUpdate("UPDATE players SET team_id = NULL WHERE id = ?", {std::to_string(playerId)});

    auto notif = NotificationService::getInstance();
    notif->sendNotification(playerUserId, "Roster Update", "You have left the team roster.", "team", "/player-dashboard.html");

    return {{"success", true}, {"message", "Player removed from roster."}};
}

nlohmann::json TeamService::getTeamTournaments(int teamId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT tr.id as registration_id, tr.tournament_id, tr.team_id, tr.status, tr.registered_at, tr.review_notes, "
        "t.name as tournament_name, t.name, t.game_category, t.game_category as game, "
        "t.format, t.status as tournament_status, t.prize_pool, t.prize_pool as prizePool, "
        "t.start_date, t.start_date as startDate, t.end_date, t.end_date as endDate, "
        "t.registration_deadline, t.banner_url "
        "FROM tournament_registrations tr "
        "JOIN tournaments t ON tr.tournament_id = t.id "
        "WHERE tr.team_id = ? "
        "ORDER BY tr.registered_at DESC";
    return db->queryJson(sql, {std::to_string(teamId)});
}

nlohmann::json TeamService::getTeamMatches(int teamId) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT m.*, tA.name as team_a_name, tA.logo_url as team_a_logo, "
        "tB.name as team_b_name, tB.logo_url as team_b_logo, tr.name as tournament_name "
        "FROM matches m "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "LEFT JOIN tournaments tr ON m.tournament_id = tr.id "
        "WHERE m.team_a_id = ? OR m.team_b_id = ? "
        "ORDER BY m.scheduled_time ASC";
    return db->queryJson(sql, {std::to_string(teamId), std::to_string(teamId)});
}

} // namespace Esports

