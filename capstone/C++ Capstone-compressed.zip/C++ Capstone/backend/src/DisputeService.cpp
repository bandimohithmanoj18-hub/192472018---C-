#include "../include/services/DisputeService.h"
#include "../include/services/DatabaseService.h"
#include "../include/services/NotificationService.h"

namespace Esports {

std::shared_ptr<DisputeService> DisputeService::s_instance = nullptr;
DisputeService::DisputeService() {}
std::shared_ptr<DisputeService> DisputeService::getInstance() {
    if (!s_instance) s_instance = std::make_shared<DisputeService>();
    return s_instance;
}

nlohmann::json DisputeService::raiseDispute(int matchId, int captainUserId, const std::string& reason, const std::string& evidenceUrl) {
    auto db = DatabaseService::getInstance();
    if (reason.empty()) return {{"success", false}, {"message", "Reason for dispute is required."}};

    auto teamRows = db->queryJson("SELECT id, name FROM teams WHERE captain_id = ?", {std::to_string(captainUserId)});
    if (teamRows.empty()) return {{"success", false}, {"message", "Only team captains can raise disputes."}};

    int teamId = static_cast<int>(teamRows[0]["id"].get<int64_t>());
    std::string teamName = teamRows[0].value("name", "");

    // Verify captain's team is actually in this match
    auto matchRows = db->queryJson("SELECT id, team_a_id, team_b_id FROM matches WHERE id = ?", {std::to_string(matchId)});
    if (matchRows.empty()) return {{"success", false}, {"message", "Match not found."}};
    int64_t tA = matchRows[0]["team_a_id"].is_null() ? 0 : matchRows[0]["team_a_id"].get<int64_t>();
    int64_t tB = matchRows[0]["team_b_id"].is_null() ? 0 : matchRows[0]["team_b_id"].get<int64_t>();
    if (teamId != tA && teamId != tB) return {{"success", false}, {"message", "You can only raise disputes for matches your team is participating in."}};

    int dId = db->executeInsert(
        "INSERT INTO disputes (match_id, raised_by, team_id, reason, evidence_url, status) VALUES (?, ?, ?, ?, ?, 'Open')",
        {std::to_string(matchId), std::to_string(captainUserId), std::to_string(teamId), reason, evidenceUrl}
    );

    // Notify admins
    auto notif = NotificationService::getInstance();
    notif->notifyAllAdmins("New Dispute Filed", "Team '" + teamName + "' has filed a dispute for Match #" + std::to_string(matchId) + ": " + reason.substr(0, 60) + "...", "dispute", "/admin-dashboard.html");

    // Mark match as Under Review
    db->executeUpdate("UPDATE matches SET status = 'Under Review' WHERE id = ? AND status != 'Completed'", {std::to_string(matchId)});

    db->logActivity(captainUserId, "RAISE_DISPUTE", "Dispute #" + std::to_string(dId) + " raised for match #" + std::to_string(matchId));
    return {{"success", true}, {"message", "Dispute submitted. Admin will review and respond."}, {"disputeId", dId}};
}

nlohmann::json DisputeService::getAllDisputes(const std::string& status) {
    auto db = DatabaseService::getInstance();
    std::string sql =
        "SELECT d.*, m.team_a_id, m.team_b_id, m.team_a_score, m.team_b_score, "
        "tA.name as team_a_name, tB.name as team_b_name, "
        "t.name as disputing_team_name, u.full_name as raised_by_name, u.username as raised_by_username, "
        "tour.name as tournament_name "
        "FROM disputes d "
        "JOIN matches m ON d.match_id = m.id "
        "LEFT JOIN teams tA ON m.team_a_id = tA.id "
        "LEFT JOIN teams tB ON m.team_b_id = tB.id "
        "JOIN teams t ON d.team_id = t.id "
        "JOIN users u ON d.raised_by = u.id "
        "JOIN tournaments tour ON m.tournament_id = tour.id ";
    std::vector<std::string> params;
    if (!status.empty()) { sql += " WHERE d.status = ? "; params.push_back(status); }
    sql += " ORDER BY d.created_at DESC";
    return db->queryJson(sql, params);
}

nlohmann::json DisputeService::getDisputeById(int disputeId) {
    auto db = DatabaseService::getInstance();
    auto rows = db->queryJson(
        "SELECT d.*, u.full_name as raised_by_name, t.name as team_name "
        "FROM disputes d JOIN users u ON d.raised_by = u.id JOIN teams t ON d.team_id = t.id "
        "WHERE d.id = ?",
        {std::to_string(disputeId)}
    );
    if (rows.empty()) return {{"success", false}, {"message", "Dispute not found."}};
    return {{"success", true}, {"dispute", rows[0]}};
}

nlohmann::json DisputeService::getDisputesByTeam(int teamId) {
    auto db = DatabaseService::getInstance();
    return db->queryJson(
        "SELECT d.*, u.full_name as raised_by_name, tour.name as tournament_name "
        "FROM disputes d JOIN users u ON d.raised_by = u.id "
        "JOIN matches m ON d.match_id = m.id JOIN tournaments tour ON m.tournament_id = tour.id "
        "WHERE d.team_id = ? ORDER BY d.created_at DESC",
        {std::to_string(teamId)}
    );
}

nlohmann::json DisputeService::resolveDispute(int disputeId, int adminUserId, const std::string& status, const std::string& adminNotes) {
    auto db = DatabaseService::getInstance();
    auto dRows = db->queryJson("SELECT d.*, t.name as team_name, u.id as captain_user_id FROM disputes d JOIN teams t ON d.team_id = t.id LEFT JOIN users u ON t.captain_id = u.id WHERE d.id = ?", {std::to_string(disputeId)});
    if (dRows.empty()) return {{"success", false}, {"message", "Dispute not found."}};

    db->executeUpdate(
        "UPDATE disputes SET status = ?, admin_notes = ?, resolved_at = CURRENT_TIMESTAMP, resolved_by = ? WHERE id = ?",
        {status, adminNotes, std::to_string(adminUserId), std::to_string(disputeId)}
    );

    // Notify captain
    int captainUserId = static_cast<int>(dRows[0]["captain_user_id"].get<int64_t>());
    auto notif = NotificationService::getInstance();
    notif->sendNotification(captainUserId, "Dispute " + status,
        "Your dispute has been " + status + ". Admin note: " + adminNotes, "dispute", "/disputes.html");

    db->logActivity(adminUserId, "RESOLVE_DISPUTE", "Resolved dispute #" + std::to_string(disputeId) + " as: " + status);
    return {{"success", true}, {"message", "Dispute resolved and captain notified."}};
}

} // namespace Esports

