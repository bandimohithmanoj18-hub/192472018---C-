@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Python is not on PATH.& pause & exit /b 1)
python -c "import flask" >nul 2>nul || (echo Flask is missing. Run: python -m pip install -r requirements.txt& pause & exit /b 1)
python seed_demo.py || (echo Demo seed failed.& pause & exit /b 1)
start "Arena Manager server" /D "%~dp0" cmd /k python app.py
timeout /t 3 /nobreak >nul
start "" "http://127.0.0.1:5000"
echo Arena Manager started. Keep the server console open; press Ctrl+C there to stop it.
