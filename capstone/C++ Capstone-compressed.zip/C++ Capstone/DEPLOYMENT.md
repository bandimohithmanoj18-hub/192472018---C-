# Esports Arena — Production Deployment Guide

This repository contains the complete production deployment infrastructure for the **Esports Arena Tournament Platform**.

---

## ☁️ Option 1: Vercel (Flask Demo)

The root `app.py` is detected as a Flask application. Static assets are mirrored under `public/assets`, and the local SQLite database is excluded from uploads.

1. In the Vercel project settings, add `ARENA_SECRET` as a private environment variable using a unique random value of at least 32 characters.
2. Optionally set `ARENA_DEMO_ENABLED=1` to initialize the shared demonstration accounts and sample records. Their password is `ArenaDemo2026!`; anyone can use these accounts, so only enable them for a public demo.
3. Deploy the project with the Vercel CLI (`vercel deploy --prod`) or connect the repository in Vercel.

**Storage limit:** Vercel Functions only provide temporary writable storage. This deployment uses a SQLite file in the function's temporary directory; accounts, settings, and tournament changes can disappear when an instance is recycled and may differ between instances. The local `database/` file is never uploaded. Use a durable external database before relying on this deployment for real users or records.

## ⚡ Option 2: Instant Public URL (Windows 1-Click)

Publish the application directly to the internet with a free, public `https://` domain using **Cloudflare Tunnel**:

1. Double-click [`deploy_public_tunnel.bat`](deploy_public_tunnel.bat) (or run `./deploy_public_tunnel.ps1` in PowerShell).
2. It automatically starts `backend\esports_server.exe` on port 8080 and launches Cloudflare Tunnel.
3. Your secure public URL will appear in the console:
   ```text
   +--------------------------------------------------------------------------------------------+
   |  Your quick Tunnel has been created! Visit it at (it may take some seconds to be ready):  |
   |  https://esports-arena-demo.trycloudflare.com                                              |
   +--------------------------------------------------------------------------------------------+
   ```
4. Share this link with anyone across the globe. Traffic is end-to-end encrypted with valid SSL.

---

## 🐳 Option 3: Docker Compose (Any Server: Ubuntu, Debian, macOS, Windows)

Run the full containerized stack (C++ backend container + Nginx reverse proxy):

```bash
# 1. Build and launch all containers
docker compose up -d --build

# 2. Inspect running services
docker compose ps

# 3. View live server logs
docker compose logs -f esports-app
```

The multi-stage [`Dockerfile`](Dockerfile) compiles the C++ backend on Linux, links against SQLite, and serves the static frontend with zero dependencies on the host machine.

---

## 🐧 Option 4: Dedicated Linux VPS (AWS EC2, DigitalOcean, Hetzner, Linode)

### 1. Compile the C++ Backend
```bash
sudo apt update && sudo apt install -y build-essential make
./build_linux.sh
```

### 2. Configure Systemd Service for 24/7 Uptime
Create `/etc/systemd/system/esports-arena.service`:
```ini
[Unit]
Description=Esports Arena C++ Backend
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/esports-arena
ExecStart=/var/www/esports-arena/backend/esports_server 8080
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now esports-arena
```

### 3. Configure Nginx with Rate Limiting & SSL
Copy the production configuration:
```bash
sudo cp nginx.conf /etc/nginx/sites-available/esportsarena
sudo ln -s /etc/nginx/sites-available/esportsarena /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
```
Obtain free SSL certificates via Certbot:
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d esportsarena.gg -d www.esportsarena.gg
```

---

## 🛡️ Production Security Hardening Included

1. **Database-Backed Persistent Sessions**:
   Active login sessions are stored in the SQLite `sessions` table and cached in memory. Users stay logged in even if the server is restarted.
2. **Cryptographic Salted Hashing**:
   New user registrations and password changes are hashed with a 16-character cryptographic salt (`salt$sha256(salt:password)`) to prevent rainbow table attacks.
3. **Nginx Rate Limiting**:
   - `/api/auth/login` is limited to 5 requests/sec with burst protection to prevent brute force.
   - General API endpoints are limited to 20 requests/sec per IP.
4. **Security Headers**:
   - `X-Frame-Options: SAMEORIGIN` (Clickjacking prevention)
   - `X-Content-Type-Options: nosniff` (MIME-sniffing prevention)
   - `Strict-Transport-Security` (HSTS enforcement)
   - `Content-Security-Policy` (XSS mitigation)
