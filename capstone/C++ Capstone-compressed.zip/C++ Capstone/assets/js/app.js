/**
 * app.js - Esports Arena Shared JS: API client, auth, toasts, utilities
 */
const API_BASE = (typeof window !== 'undefined' && window.location.origin && window.location.origin.startsWith('http')) 
  ? (window.location.origin + '/api') 
  : 'http://localhost:8080/api';

// ── Token Management ─────────────────────────────────────
const Auth = {
  getToken: () => localStorage.getItem('esports_token'),
  setToken: (t) => localStorage.setItem('esports_token', t),
  clearToken: () => localStorage.removeItem('esports_token'),
  getUser: () => { try { return JSON.parse(localStorage.getItem('esports_user') || 'null'); } catch { return null; } },
  setUser: (u) => localStorage.setItem('esports_user', JSON.stringify(u)),
  clearUser: () => localStorage.removeItem('esports_user'),
  isLoggedIn: () => !!localStorage.getItem('esports_token'),
  isAdmin: () => { const u = Auth.getUser(); return u && u.role === 'admin'; },
  isCaptain: () => { const u = Auth.getUser(); return u && (u.role === 'captain' || u.role === 'admin'); },
  logout: async () => {
    try { await api.post('/auth/logout'); } catch(e) {}
    Auth.clearToken(); Auth.clearUser();
    window.location.href = '/login.html';
  }
};

// ── API Client ────────────────────────────────────────────
const api = {
  _fetch: async (method, path, body = null) => {
    const headers = { 'Content-Type': 'application/json' };
    const token = Auth.getToken();
    if (token) headers['Authorization'] = 'Bearer ' + token;

    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    const cleanPath = path.startsWith('/api') ? path.substring(4) : path;
    const finalPath = (cleanPath.startsWith('/') ? '' : '/') + cleanPath;

    try {
      const res = await fetch(API_BASE + finalPath, opts);
      const data = await res.json();
      return api._hydrateKeys(data);
    } catch (e) {
      console.error('API Error:', e);
      return { success: false, message: 'Network error. Is the server running?' };
    }
  },
  get:    (path) => api._fetch('GET', path),
  post:   (path, body) => api._fetch('POST', path, body),
  put:    (path, body) => api._fetch('PUT', path, body),
  delete: (path) => api._fetch('DELETE', path),
  _hydrateKeys: (obj) => {
    if (Array.isArray(obj)) return obj.map(api._hydrateKeys);
    if (obj !== null && typeof obj === 'object') {
      const keys = Object.keys(obj);
      for (const key of keys) {
        obj[key] = api._hydrateKeys(obj[key]);
        const camel = key.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
        if (camel !== key && obj[camel] === undefined) {
          obj[camel] = obj[key];
        }
      }
      // Common compatibility aliases
      if (obj.winner_team_id !== undefined && obj.winnerId === undefined) obj.winnerId = obj.winner_team_id;
      if (obj.winnerTeamId !== undefined && obj.winnerId === undefined) obj.winnerId = obj.winnerTeamId;
      if (obj.game_category !== undefined && obj.game === undefined) obj.game = obj.game_category;
      if (obj.gameCategory !== undefined && obj.game === undefined) obj.game = obj.gameCategory;
      if (obj.is_read !== undefined) {
        if (obj.isRead === undefined) obj.isRead = obj.is_read;
        if (obj.read === undefined) obj.read = Boolean(obj.is_read);
      }
      if (obj.phone_number !== undefined && obj.phone === undefined) obj.phone = obj.phone_number;
      if (obj.phoneNumber !== undefined && obj.phone === undefined) obj.phone = obj.phoneNumber;
      if (obj.win_pct !== undefined && obj.winRate === undefined) obj.winRate = obj.win_pct;
    }
    return obj;
  }
};

// ── Toast Notifications ───────────────────────────────────
const Toast = {
  container: null,
  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(message, type = 'info', duration = 4000) {
    this.init();
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span style="flex:1">${message}</span><button onclick="this.parentElement.remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.1rem">×</button>`;
    this.container.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(100%)'; t.style.transition = 'all 0.3s'; setTimeout(() => t.remove(), 300); }, duration);
  },
  success: (m, d) => Toast.show(m, 'success', d),
  error:   (m, d) => Toast.show(m, 'error', d),
  info:    (m, d) => Toast.show(m, 'info', d),
  warning: (m, d) => Toast.show(m, 'warning', d)
};

// ── Loading State ─────────────────────────────────────────
const Loading = {
  show(el, msg = 'Loading...') {
    if (typeof el === 'string') {
      msg = el;
      el = null;
    }
    if (el && el.nodeType) {
      el._origHTML = el.innerHTML;
      el.innerHTML = `<span class="spinner" style="width:16px;height:16px;display:inline-block;vertical-align:middle"></span> ${msg}`;
      el.disabled = true;
    } else {
      Loading.overlay(msg);
    }
  },
  hide(el) {
    if (el && el.nodeType && el._origHTML !== undefined) {
      el.innerHTML = el._origHTML;
      el.disabled = false;
    } else {
      Loading.hideOverlay();
    }
  },
  overlay(msg = 'Loading...') {
    if (document.getElementById('global-loader')) return;
    const el = document.createElement('div');
    el.className = 'loading-overlay';
    el.id = 'global-loader';
    el.innerHTML = `<div class="spinner"></div><div class="loading-text" style="color:var(--text-primary);font-family:'Rajdhani',sans-serif;font-size:1.1rem;font-weight:600;margin-top:12px;">${msg}</div>`;
    document.body.appendChild(el);
  },
  hideOverlay() {
    const el = document.getElementById('global-loader');
    if (el) el.remove();
  }
};

// ── Modal Helpers ─────────────────────────────────────────
const Modal = {
  show(id) {
    const m = document.getElementById(id);
    if (m) { m.classList.add('show'); document.body.style.overflow = 'hidden'; }
  },
  hide(id) {
    const m = document.getElementById(id);
    if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
  },
  closeOnOverlay(id) {
    const m = document.getElementById(id);
    if (m) m.addEventListener('click', (e) => { if (e.target === m) Modal.hide(id); });
  }
};

// ── Form Utilities ────────────────────────────────────────
const Form = {
  serialize(formEl) {
    const data = {};
    new FormData(formEl).forEach((v, k) => { data[k] = v; });
    return data;
  },
  validate(rules) {
    let valid = true;
    for (const [field, rule] of Object.entries(rules)) {
      const el = document.getElementById(field) || document.querySelector(`[name="${field}"]`);
      const errEl = document.getElementById(field + '-error');
      if (!el) continue;
      let err = '';
      if (rule.required && !el.value.trim()) err = rule.required;
      else if (rule.minLength && el.value.length < rule.minLength) err = rule.minLength;
      else if (rule.pattern && !rule.pattern.test(el.value)) err = rule.patternMsg;
      if (errEl) errEl.textContent = err;
      if (err) { valid = false; el.style.borderColor = 'var(--accent-red)'; }
      else if (el.style) el.style.borderColor = '';
    }
    return valid;
  }
};

// ── Format Helpers ────────────────────────────────────────
const fmt = {
  date: (d) => { if (!d) return 'TBD'; try { return new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' }); } catch { return d; } },
  datetime: (d) => { if (!d) return 'TBD'; try { return new Date(d).toLocaleString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }); } catch { return d; } },
  currency: (n) => '₹' + Number(n || 0).toLocaleString('en-IN'),
  percent: (n) => (Number(n || 0)).toFixed(1) + '%',
  rating: (n) => Math.round(Number(n || 1200)).toLocaleString(),
  statusBadge(status) {
    const map = {
      'Approved': 'badge-approved', 'Completed': 'badge-completed',
      'Pending': 'badge-pending', 'Upcoming': 'badge-upcoming',
      'Rejected': 'badge-rejected', 'Dismissed': 'badge-dismissed',
      'Live': 'badge-live', 'Under Review': 'badge-review',
      'Open': 'badge-open', 'Registration Open': 'badge-pending',
      'Ongoing': 'badge-approved',
    };
    return `<span class="badge ${map[status]||'badge-player'}">${status}</span>`;
  },
  recentForm(form) {
    if (!form) return '';
    return form.split('').map(c => `<div class="form-dot ${c}">${c === '_' ? '' : c}</div>`).join('');
  },
  avatar: (url, name='?') => url || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=0d1f3c&color=00e5ff&bold=true`,
  teamLogo: (url, name='?') => url || `https://ui-avatars.com/api/?name=${encodeURIComponent(name.substring(0,2))}&background=091422&color=9b27ff&bold=true&size=64`,
  rankBadge(rank) {
    if (rank === 1) return `<div class="rank-badge gold">🥇</div>`;
    if (rank === 2) return `<div class="rank-badge silver">🥈</div>`;
    if (rank === 3) return `<div class="rank-badge bronze">🥉</div>`;
    return `<div class="rank-badge" style="background:var(--bg-secondary);border:1px solid var(--border-color)">${rank}</div>`;
  }
};

// ── Sidebar Builder ───────────────────────────────────────
function buildSidebar(activeLink) {
  const user = Auth.getUser();
  const role = user ? user.role : 'guest';
  const links = {
    guest: [
      { section: 'Discover' },
      { href: '/index.html', icon: '🏠', label: 'Home' },
      { href: '/tournaments.html', icon: '🏆', label: 'Tournaments' },
      { href: '/scoreboard.html', icon: '🎯', label: 'Scoreboard' },
      { href: '/leaderboard.html', icon: '🏅', label: 'Leaderboard' },
      { href: '/match-history.html', icon: '📜', label: 'Match History' },
      { section: 'Account' },
      { href: '/login.html', icon: '🔑', label: 'Sign In' },
      { href: '/register-player.html', icon: '🎮', label: 'Register Player' },
      { href: '/register-team.html', icon: '🛡️', label: 'Register Team' },
    ],
    admin: [
      { section: 'Overview' },
      { href: '/admin-dashboard.html', icon: '📊', label: 'Dashboard' },
      { href: '/tournaments.html', icon: '🏆', label: 'Tournaments' },
      { href: '/match-schedule.html', icon: '📅', label: 'Match Schedule' },
      { section: 'Management' },
      { href: '/admin-dashboard.html#teams', icon: '👥', label: 'Teams' },
      { href: '/admin-dashboard.html#players', icon: '🎮', label: 'Players' },
      { href: '/admin-dashboard.html#registrations', icon: '📋', label: 'Registrations' },
      { href: '/scoreboard.html', icon: '🎯', label: 'Scoreboard' },
      { href: '/leaderboard.html', icon: '🏅', label: 'Leaderboard' },
      { section: 'Tools' },
      { href: '/disputes.html', icon: '⚖️', label: 'Disputes' },
      { href: '/admin-reports.html', icon: '📈', label: 'Reports' },
      { href: '/notifications.html', icon: '🔔', label: 'Notifications' },
    ],
    captain: [
      { section: 'My Team' },
      { href: '/captain-dashboard.html', icon: '📊', label: 'Dashboard' },
      { href: '/captain-dashboard.html#team', icon: '🛡️', label: 'My Team' },
      { href: '/captain-dashboard.html#roster', icon: '👥', label: 'Roster' },
      { section: 'Competition' },
      { href: '/tournaments.html', icon: '🏆', label: 'Tournaments' },
      { href: '/scoreboard.html', icon: '🎯', label: 'Scoreboard' },
      { href: '/leaderboard.html', icon: '🏅', label: 'Leaderboard' },
      { href: '/match-history.html', icon: '📜', label: 'Match History' },
      { section: 'Other' },
      { href: '/disputes.html', icon: '⚖️', label: 'Disputes' },
      { href: '/notifications.html', icon: '🔔', label: 'Notifications' },
    ],
    player: [
      { section: 'My Profile' },
      { href: '/player-dashboard.html', icon: '📊', label: 'Dashboard' },
      { href: '/player-profile.html', icon: '👤', label: 'My Profile' },
      { section: 'Competition' },
      { href: '/tournaments.html', icon: '🏆', label: 'Tournaments' },
      { href: '/scoreboard.html', icon: '🎯', label: 'Scoreboard' },
      { href: '/leaderboard.html', icon: '🏅', label: 'Leaderboard' },
      { href: '/match-history.html', icon: '📜', label: 'Match History' },
      { section: 'Other' },
      { href: '/notifications.html', icon: '🔔', label: 'Notifications' },
    ]
  };

  const items = links[role] || links.guest;
  let html = `
    <a href="/index.html" class="sidebar-logo" title="Go to Esports Arena Home" style="text-decoration:none; display:flex; align-items:center; gap:12px; cursor:pointer;">
      <img src="/assets/images/favicon.svg" alt="Logo" width="32" height="32" style="flex-shrink:0;">
      <div>
        <div class="logo-text">ESPORTS ARENA</div>
        <div class="logo-sub">Tournament Management</div>
      </div>
    </a>
    <nav class="sidebar-nav">`;

  for (const item of items) {
    if (item.section) {
      html += `<div class="nav-section-title">${item.section}</div>`;
    } else {
      const active = item.href === activeLink ? 'active' : '';
      html += `<a href="${item.href}" class="nav-link ${active}">
        <span class="nav-icon">${item.icon}</span>
        <span>${item.label}</span>
      </a>`;
    }
  }

  html += `</nav>`;
  if (user) {
    html += `
    <div class="sidebar-user">
      <div class="user-avatar">
        <img src="${fmt.avatar(user.avatarUrl, user.fullName)}" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover">
      </div>
      <div class="user-info">
        <div class="user-name">${user.fullName || user.username}</div>
        <div class="user-role">${user.role}</div>
      </div>
      <button onclick="Auth.logout()" title="Logout" style="margin-left:auto;background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.1rem;transition:color 0.2s" onmouseover="this.style.color='var(--accent-red)'" onmouseout="this.style.color='var(--text-muted)'">⏻</button>
    </div>`;
  } else {
    html += `
    <div class="sidebar-user" style="display:flex; flex-direction:column; gap:8px; align-items:stretch; padding:16px;">
      <a href="/login.html" class="btn btn-sm btn-primary" style="text-align:center; text-decoration:none; display:block; padding:8px;">Sign In</a>
      <a href="/register-player.html" class="btn btn-sm btn-outline" style="text-align:center; text-decoration:none; display:block; padding:8px; border:1px solid var(--accent-cyan); color:var(--accent-cyan);">Join as Player</a>
    </div>`;
  }

  const sidebar = document.getElementById('sidebar');
  if (sidebar) {
    sidebar.innerHTML = html;

    // Mobile topbar injection for dashboards
    let mobileTopbar = document.getElementById('mobileTopbar');
    if (!mobileTopbar) {
      mobileTopbar = document.createElement('div');
      mobileTopbar.id = 'mobileTopbar';
      mobileTopbar.className = 'mobile-topbar';
      mobileTopbar.innerHTML = `
        <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Toggle navigation menu" title="Open Menu">☰</button>
        <a href="/index.html" class="logo-link" style="display:flex;align-items:center;gap:8px;text-decoration:none;">
          <img src="/assets/images/favicon.svg" alt="Logo" width="28" height="28">
          <span style="font-family:'Orbitron',monospace;font-weight:900;font-size:1.1rem;background:linear-gradient(135deg,var(--accent-cyan),var(--accent-purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent;">ESPORTS ARENA</span>
        </a>
        <a href="/notifications.html" style="font-size:1.2rem;text-decoration:none;" title="Notifications">🔔</a>
      `;
      const layout = document.querySelector('.dashboard-layout');
      if (layout) {
        layout.parentNode.insertBefore(mobileTopbar, layout);
      } else {
        document.body.prepend(mobileTopbar);
      }
    }

    let backdrop = document.getElementById('sidebarBackdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'sidebarBackdrop';
      backdrop.className = 'sidebar-backdrop';
      document.body.appendChild(backdrop);
    }

    const menuBtn = document.getElementById('mobileMenuBtn');
    if (menuBtn && backdrop) {
      menuBtn.onclick = (e) => {
        e.stopPropagation();
        sidebar.classList.toggle('open');
        backdrop.classList.toggle('active');
      };
      backdrop.onclick = () => {
        sidebar.classList.remove('open');
        backdrop.classList.remove('active');
      };
      // Close mobile sidebar on nav click
      sidebar.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
          sidebar.classList.remove('open');
          backdrop.classList.remove('active');
        });
      });
    }
  }
}

// ── Auth Guard ────────────────────────────────────────────
function requireLogin(allowedRoles = []) {
  if (!Auth.isLoggedIn()) {
    window.location.href = '/login.html?redirect=' + encodeURIComponent(window.location.pathname);
    return false;
  }
  if (allowedRoles.length > 0) {
    const user = Auth.getUser();
    if (!user || (!allowedRoles.includes(user.role) && user.role !== 'admin')) {
      Toast.error('Access denied. Insufficient permissions.');
      setTimeout(() => window.location.href = '/', 1500);
      return false;
    }
  }
  return true;
}

// ── Notification Badge Updater ────────────────────────────
async function updateNotifBadge() {
  if (!Auth.isLoggedIn()) return;
  try {
    const data = await api.get('/notifications?unread=true&limit=50');
    const badge = document.getElementById('notif-badge');
    if (badge) {
      const cnt = Array.isArray(data) ? data.length : 0;
      badge.textContent = cnt > 9 ? '9+' : cnt;
      badge.style.display = cnt > 0 ? 'flex' : 'none';
    }
  } catch(e) {}
}

// ── Tabs with URL Hash Support ────────────────────────────
function initTabs(containerSelector = '.tab-nav') {
  const switchByHash = () => {
    const hash = window.location.hash.replace('#', '');
    if (!hash) return;
    const targetBtn = document.querySelector(`${containerSelector} .tab-btn[data-tab="${hash}"]`);
    if (targetBtn) {
      targetBtn.click();
    }
  };

  document.querySelectorAll(containerSelector + ' .tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      btn.closest('.card, .tab-wrapper, section, div, main').querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      const panel = document.getElementById('tab-' + target);
      if (panel) panel.classList.add('active');
    });
  });

  window.addEventListener('hashchange', switchByHash);
  switchByHash();
}

// ── Global Init ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // 1. Auto-inject favicon if missing
  if (!document.querySelector("link[rel*='icon']")) {
    const fav = document.createElement('link');
    fav.rel = 'icon';
    fav.type = 'image/svg+xml';
    fav.href = '/assets/images/favicon.svg';
    document.head.appendChild(fav);
  }

  // 2. Dynamic Copyright Year
  const currentYear = new Date().getFullYear();
  document.querySelectorAll('.footer-copy, .footer-bottom p, #currentYear, #copyrightYear').forEach(el => {
    if (el.id === 'currentYear' || el.id === 'copyrightYear') {
      el.textContent = currentYear;
    } else {
      el.innerHTML = el.innerHTML.replace(/202[0-9]/g, currentYear);
    }
  });

  // 3. Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(m => {
    m.addEventListener('click', (e) => { if (e.target === m) m.classList.remove('show'); });
  });

  // 4. Init tabs if present
  if (document.querySelector('.tab-nav')) initTabs();

  // 5. Update notif badge
  updateNotifBadge();

  // 6. Auto-refresh live matches every 30s if on scoreboard page
  if (window.location.pathname.includes('scoreboard')) {
    setInterval(() => { if (typeof refreshScoreboard === 'function') refreshScoreboard(); }, 30000);
  }

  // 7. Initialize 3D Interactive UI Engine
  init3DEffects();
});

// ── 3D Interactive UI & Card Tilt Engine ─────────────────────
function init3DEffects() {
  // 1. Interactive 3D Hologram stage on hero section
  const stage = document.getElementById('hero3DStage');
  const rig = document.getElementById('hologramRig');
  if (stage && rig) {
    stage.addEventListener('mousemove', (e) => {
      const rect = stage.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      const rotateX = (-y / rect.height) * 35;
      const rotateY = (x / rect.width) * 35;
      rig.style.transform = `rotateX(${rotateX.toFixed(1)}deg) rotateY(${rotateY.toFixed(1)}deg) scale3d(1.1, 1.1, 1.1)`;
    });
    stage.addEventListener('mouseleave', () => {
      rig.style.transform = '';
    });
  }

  // 2. 3D Card Tilt Engine
  const attachCardTilt = (card) => {
    if (card._hasTilt) return;
    card._hasTilt = true;
    card.classList.add('card-3d');
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      const rotX = (-y / (rect.height / 2)) * 7;
      const rotY = (x / (rect.width / 2)) * 7;
      card.style.transform = `perspective(1000px) rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg) translateZ(12px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  };

  document.querySelectorAll('.card-3d, .t-card, .p-stat, .stat-card, .podium-card, .tournament-card, .match-card').forEach(attachCardTilt);

  // MutationObserver for cards rendered asynchronously
  const observer = new MutationObserver(() => {
    document.querySelectorAll('.card-3d, .t-card, .p-stat, .stat-card, .podium-card, .tournament-card, .match-card').forEach(attachCardTilt);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

