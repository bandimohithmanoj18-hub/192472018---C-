"""Flask/SQLite local application for the Arena Manager capstone demo."""
import os, sqlite3, secrets, json, tempfile
from pathlib import Path
from functools import wraps
from flask import Flask, g, request, session, jsonify, render_template_string, send_file, abort, render_template, send_from_directory, redirect
from werkzeug.security import generate_password_hash, check_password_hash

ROOT=Path(__file__).resolve().parent
IS_VERCEL=os.environ.get('VERCEL')=='1'
DEMO_LOGIN_ALLOWED=not IS_VERCEL or os.environ.get('ARENA_DEMO_ENABLED','').lower() in ('1','true','yes')
if IS_VERCEL:
    os.environ.setdefault('ARENA_DB',str(Path(tempfile.gettempdir())/'arena_manager.sqlite3'))
DB=Path(os.environ.get('ARENA_DB',ROOT/'database'/'arena_manager.sqlite3'))
secret=os.environ.get('ARENA_SECRET')
if IS_VERCEL and (not secret or len(secret)<32):
    raise RuntimeError('Set ARENA_SECRET to a private value of at least 32 characters in the Vercel project environment.')
app=Flask(__name__); app.secret_key=secret or 'local-demo-secret-change-in-production'
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Lax',SESSION_COOKIE_SECURE=IS_VERCEL,MAX_CONTENT_LENGTH=5*1024*1024)
SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,name TEXT NOT NULL,roles TEXT NOT NULL,phone TEXT,is_demo INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY,user_id INTEGER UNIQUE REFERENCES users(id),player_code TEXT UNIQUE NOT NULL,game TEXT NOT NULL,archived INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS teams(id INTEGER PRIMARY KEY,team_code TEXT UNIQUE NOT NULL,name TEXT UNIQUE NOT NULL,captain_id INTEGER REFERENCES users(id),game TEXT NOT NULL,roster_limit INTEGER DEFAULT 5,roster_locked INTEGER DEFAULT 0,archived INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS team_members(team_id INTEGER REFERENCES teams(id) ON DELETE CASCADE,player_id INTEGER REFERENCES players(id) ON DELETE CASCADE,PRIMARY KEY(team_id,player_id),UNIQUE(player_id));
CREATE TABLE IF NOT EXISTS team_join_requests(id INTEGER PRIMARY KEY,team_id INTEGER REFERENCES teams(id),player_id INTEGER REFERENCES players(id),status TEXT DEFAULT 'pending',UNIQUE(team_id,player_id));
CREATE TABLE IF NOT EXISTS invitations(id INTEGER PRIMARY KEY,code TEXT UNIQUE,kind TEXT,target_id INTEGER,created_by INTEGER REFERENCES users(id),expires_at TEXT,revoked INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS games(id INTEGER PRIMARY KEY,name TEXT UNIQUE,game_type TEXT DEFAULT 'head_to_head');
CREATE TABLE IF NOT EXISTS tournaments(id INTEGER PRIMARY KEY,owner_id INTEGER REFERENCES users(id),name TEXT,description TEXT DEFAULT '',game TEXT,format TEXT,game_type TEXT DEFAULT 'head_to_head',status TEXT DEFAULT 'Registration Open',start_date TEXT,end_date TEXT,registration_deadline TEXT,max_teams INTEGER DEFAULT 8,min_roster INTEGER DEFAULT 1,max_roster INTEGER DEFAULT 5,win_points INTEGER DEFAULT 3,draw_points INTEGER DEFAULT 1,loss_points INTEGER DEFAULT 0,elim_points INTEGER DEFAULT 1,invite_code TEXT UNIQUE,champion_id INTEGER REFERENCES teams(id));
CREATE TABLE IF NOT EXISTS tournament_teams(tournament_id INTEGER REFERENCES tournaments(id),team_id INTEGER REFERENCES teams(id),status TEXT DEFAULT 'pending',UNIQUE(tournament_id,team_id));
CREATE TABLE IF NOT EXISTS tournament_waitlist(id INTEGER PRIMARY KEY,tournament_id INTEGER REFERENCES tournaments(id),team_id INTEGER REFERENCES teams(id),position INTEGER,UNIQUE(tournament_id,team_id));
CREATE TABLE IF NOT EXISTS matches(id INTEGER PRIMARY KEY,tournament_id INTEGER REFERENCES tournaments(id),round_number INTEGER DEFAULT 1,team_a_id INTEGER REFERENCES teams(id),team_b_id INTEGER REFERENCES teams(id),scheduled_at TEXT,status TEXT DEFAULT 'scheduled',lobby TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS match_participants(match_id INTEGER REFERENCES matches(id),team_id INTEGER REFERENCES teams(id),PRIMARY KEY(match_id,team_id));
CREATE TABLE IF NOT EXISTS match_results(id INTEGER PRIMARY KEY,match_id INTEGER REFERENCES matches(id),team_id INTEGER REFERENCES teams(id),score INTEGER DEFAULT 0,eliminations INTEGER DEFAULT 0,placement INTEGER,verified INTEGER DEFAULT 0,submitted_by INTEGER REFERENCES users(id),UNIQUE(match_id,team_id));
CREATE TABLE IF NOT EXISTS result_evidence(id INTEGER PRIMARY KEY,result_id INTEGER REFERENCES match_results(id),filename TEXT);
CREATE TABLE IF NOT EXISTS result_disputes(id INTEGER PRIMARY KEY,match_id INTEGER REFERENCES matches(id),user_id INTEGER REFERENCES users(id),reason TEXT,status TEXT DEFAULT 'pending');
CREATE TABLE IF NOT EXISTS result_revisions(id INTEGER PRIMARY KEY,result_id INTEGER REFERENCES match_results(id),old_score INTEGER,new_score INTEGER,changed_by INTEGER REFERENCES users(id));
CREATE TABLE IF NOT EXISTS match_checkins(match_id INTEGER REFERENCES matches(id),team_id INTEGER REFERENCES teams(id),user_id INTEGER REFERENCES users(id),status TEXT DEFAULT 'checked_in',PRIMARY KEY(match_id,team_id));
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_id INTEGER REFERENCES users(id),message TEXT,read INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS user_preferences(user_id INTEGER PRIMARY KEY REFERENCES users(id),prefs TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS certificates(id INTEGER PRIMARY KEY,tournament_id INTEGER REFERENCES tournaments(id),team_id INTEGER REFERENCES teams(id),UNIQUE(tournament_id,team_id));
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY,user_id INTEGER,action TEXT);
'''
def getdb():
    if 'db' not in g:
        DB.parent.mkdir(parents=True,exist_ok=True); g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row; g.db.execute('PRAGMA foreign_keys=ON')
    return g.db
@app.teardown_appcontext
def close_db(_=None):
    c=g.pop('db',None)
    if c: c.close()
def init_db():
    with app.app_context():
        c=getdb(); c.executescript(SCHEMA)
        columns={r['name'] for r in c.execute('PRAGMA table_info(users)')}
        if 'phone' not in columns: c.execute('ALTER TABLE users ADD COLUMN phone TEXT')
        c.commit()
def user():
    if 'user' not in g: g.user=dict(getdb().execute('SELECT * FROM users WHERE id=?',(session.get('uid'),)).fetchone() or {})
    return g.user
def role_list(): return json.loads(user().get('roles','[]'))
def demo_write_allowed(owner_id):
    """Keep seeded demo accounts from changing rows owned by ordinary accounts."""
    if not user().get('is_demo') or owner_id is None: return True
    row=getdb().execute('SELECT is_demo FROM users WHERE id=?',(owner_id,)).fetchone()
    return bool(row and row['is_demo'])
def login_required(fn):
    @wraps(fn)
    def w(*a,**kw):
        if not user(): return jsonify(error='Sign in required'),401
        return fn(*a,**kw)
    return w
def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        def w(*a,**kw):
            if not user(): return jsonify(error='Sign in required'),401
            if not set(allowed).intersection(role_list()): return jsonify(error='Permission denied'),403
            return fn(*a,**kw)
        return w
    return deco
def audit(action): getdb().execute('INSERT INTO audit_logs(user_id,action) VALUES(?,?)',(user()['id'],action)); getdb().commit()

@app.get('/health')
def health(): return jsonify(ok=True,database=str(DB))
@app.get('/api/me')
def api_me(): return jsonify(user=user() or None)
@app.post('/api/register')
def register():
    d=request.get_json(force=True); email=d.get('email','').strip().lower(); pw=d.get('password',''); name=d.get('name','').strip()
    if '@' not in email or len(pw)<8 or not name: return jsonify(error='Name, valid email and password of at least 8 characters required.'),400
    try:
        phone=''.join(ch for ch in d.get('phone','') if ch.isdigit() or ch=='+')
        if phone and len(''.join(ch for ch in phone if ch.isdigit()))<7: return jsonify(error='Enter a valid phone number or leave it blank.'),400
        c=getdb().execute('INSERT INTO users(email,password_hash,name,roles,phone) VALUES(?,?,?,?,?)',(email,generate_password_hash(pw),name,'["Player"]',phone or None)); uid=c.lastrowid
        getdb().execute('INSERT INTO players(user_id,player_code,game) VALUES(?,?,?)',(uid,'P-'+secrets.token_hex(3).upper(),d.get('game','General'))); getdb().commit(); session['uid']=uid; return jsonify(ok=True)
    except sqlite3.IntegrityError: return jsonify(error='Email already registered.'),409
@app.post('/api/login')
def login():
    d=request.get_json(force=True); u=getdb().execute('SELECT * FROM users WHERE email=?',(d.get('email','').lower().strip(),)).fetchone()
    if not u or not check_password_hash(u['password_hash'],d.get('password','')): return jsonify(error='Email or password is incorrect.'),401
    session.clear(); session['uid']=u['id']; session.permanent=bool(d.get('remember')); return jsonify(ok=True,user=dict(u))
@app.post('/api/logout')
def logout(): session.clear(); return jsonify(ok=True)
@app.post('/api/demo-login')
def demo_login():
    if not DEMO_LOGIN_ALLOWED: return jsonify(error='Demo access is disabled.'),404
    u=getdb().execute("SELECT id FROM users WHERE email='administrator@arena.local'").fetchone()
    if not u: return jsonify(error='Run python seed_demo.py first.'),503
    session.clear(); session['uid']=u['id']; return jsonify(ok=True)

@app.get('/api/dashboard')
@login_required
def dashboard():
    c=getdb(); qs={'players':'SELECT count(*) FROM players WHERE archived=0','teams':'SELECT count(*) FROM teams WHERE archived=0',"active_tournaments":"SELECT count(*) FROM tournaments WHERE status IN ('Registration Open','Scheduled','In Progress')",'upcoming_matches':"SELECT count(*) FROM matches WHERE status='scheduled'",'completed_matches':"SELECT count(*) FROM matches WHERE status='completed'",'pending_results':'SELECT count(*) FROM match_results WHERE verified=0'}
    return jsonify(stats={k:c.execute(q).fetchone()[0] for k,q in qs.items()})
@app.get('/api/players')
@login_required
def players():
    q='%'+request.args.get('q','')+'%'; return jsonify(players=[dict(r) for r in getdb().execute('SELECT p.*,u.name FROM players p JOIN users u ON u.id=p.user_id WHERE p.archived=0 AND (u.name LIKE ? OR p.player_code LIKE ?)',(q,q))])
@app.post('/api/teams')
@login_required
def create_team():
    d=request.get_json(force=True); name=d.get('name','').strip(); limit=int(d.get('roster_limit',5))
    if not name or not 1<=limit<=50: return jsonify(error='Team name and roster limit 1–50 required.'),400
    try:
        c=getdb().execute('INSERT INTO teams(team_code,name,captain_id,game,roster_limit) VALUES(?,?,?,?,?)',('T-'+secrets.token_hex(3).upper(),name,user()['id'],d.get('game','General'),limit)); tid=c.lastrowid
        p=getdb().execute('SELECT id FROM players WHERE user_id=?',(user()['id'],)).fetchone()
        if p: getdb().execute('INSERT OR IGNORE INTO team_members(team_id,player_id) VALUES(?,?)',(tid,p['id']))
        getdb().commit(); audit('Team created'); return jsonify(id=tid),201
    except sqlite3.IntegrityError: return jsonify(error='Team name already exists.'),409
@app.get('/api/teams')
@login_required
def teams(): return jsonify(teams=[dict(r) for r in getdb().execute('SELECT t.*,u.name captain,(SELECT count(*) FROM team_members m WHERE m.team_id=t.id) roster_count FROM teams t JOIN users u ON u.id=t.captain_id WHERE t.archived=0')])
@app.post('/api/teams/<int:tid>/members')
@login_required
def add_member(tid):
    d=request.get_json(force=True); t=getdb().execute('SELECT * FROM teams WHERE id=?',(tid,)).fetchone(); p=getdb().execute('SELECT * FROM players WHERE id=?',(d.get('player_id'),)).fetchone()
    if not t or not p: return jsonify(error='Team or player not found.'),404
    if not demo_write_allowed(t['captain_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if t['captain_id']!=user()['id'] and 'Administrator' not in role_list(): return jsonify(error='Only captain can change roster.'),403
    if t['roster_locked'] or getdb().execute('SELECT count(*) FROM team_members WHERE team_id=?',(tid,)).fetchone()[0]>=t['roster_limit']: return jsonify(error='Roster locked or full.'),409
    try: getdb().execute('INSERT INTO team_members(team_id,player_id) VALUES(?,?)',(tid,p['id'])); getdb().commit(); return jsonify(ok=True),201
    except sqlite3.IntegrityError: return jsonify(error='Duplicate roster membership or player already rostered.'),409
@app.post('/api/teams/<int:tid>/invite')
@login_required
def team_invite(tid):
    t=getdb().execute('SELECT captain_id FROM teams WHERE id=?',(tid,)).fetchone()
    if not t or (t['captain_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    if not demo_write_allowed(t['captain_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    code=secrets.token_urlsafe(8); getdb().execute("INSERT INTO invitations(code,kind,target_id,created_by) VALUES(?,'team',?,?)",(code,tid,user()['id'])); getdb().commit(); return jsonify(code=code,url='/invite/'+code,qr_data='local://'+code)
@app.get('/api/invitations/<code>/qr')
@login_required
def invitation_qr(code):
    exists=getdb().execute('SELECT id FROM invitations WHERE code=? AND revoked=0',(code,)).fetchone() or getdb().execute('SELECT id FROM tournaments WHERE invite_code=?',(code,)).fetchone()
    if not exists: return jsonify(error='Invitation not found.'),404
    try:
        import qrcode
        from io import BytesIO
        image=qrcode.make(request.host_url.rstrip('/')+'/invite/'+code); output=BytesIO(); image.save(output,format='PNG'); output.seek(0)
        return send_file(output,mimetype='image/png',download_name='arena-invitation.png')
    except ImportError: return jsonify(error='Install requirements.txt to enable local QR image generation.'),503
@app.post('/api/tournament-invites/<code>/register')
@roles('Team Captain','Administrator')
def tournament_invite_register(code):
    d=request.get_json(force=True); t=getdb().execute('SELECT id FROM tournaments WHERE invite_code=?',(code,)).fetchone()
    if not t:return jsonify(error='Invalid tournament invitation code.'),404
    # Reuse the same validation and capacity/waitlist workflow as direct registration.
    actor_id=user()['id']
    with app.test_request_context(json={'team_id':d.get('team_id')}):
        session['uid']=actor_id; return registration(t['id'])
@app.get('/invite/<code>')
def invitation(code):
    i=getdb().execute('SELECT * FROM invitations WHERE code=? AND revoked=0',(code,)).fetchone()
    if not i:
        t=getdb().execute('SELECT id FROM tournaments WHERE invite_code=?',(code,)).fetchone()
        if not t:return render_template('404.html',current_year=__import__('datetime').datetime.now().year),404
        if not user():return redirect('/?invite='+code)
        return render_template('dashboard.html',me=user(),current_year=__import__('datetime').datetime.now().year,invite_code=code)
    if i['expires_at'] and i['expires_at'] < __import__('datetime').datetime.utcnow().isoformat():return render_template('404.html',current_year=__import__('datetime').datetime.now().year),404
    if not user(): return redirect('/?invite='+code)
    if i['kind']=='team':
        owner=getdb().execute('SELECT captain_id FROM teams WHERE id=?',(i['target_id'],)).fetchone()
        if owner and not demo_write_allowed(owner['captain_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
        p=getdb().execute('SELECT id FROM players WHERE user_id=?',(user()['id'],)).fetchone()
        if not p: return jsonify(error='Create a player profile first.'),400
        try: getdb().execute('INSERT INTO team_join_requests(team_id,player_id) VALUES(?,?)',(i['target_id'],p['id'])); getdb().commit()
        except sqlite3.IntegrityError: pass
        return jsonify(ok=True,message='Join request sent to captain.')
    return jsonify(ok=True)
@app.post('/api/team-requests/<int:rid>/review')
@roles('Team Captain','Administrator')
def review_join(rid):
    d=request.get_json(force=True); r=getdb().execute('SELECT r.*,t.captain_id,t.roster_limit,t.roster_locked FROM team_join_requests r JOIN teams t ON t.id=r.team_id WHERE r.id=?',(rid,)).fetchone()
    if not r or (r['captain_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    if d.get('decision')=='accepted':
        if r['roster_locked'] or getdb().execute('SELECT count(*) FROM team_members WHERE team_id=?',(r['team_id'],)).fetchone()[0]>=r['roster_limit']: return jsonify(error='Roster full or locked.'),409
        getdb().execute('INSERT OR IGNORE INTO team_members(team_id,player_id) VALUES(?,?)',(r['team_id'],r['player_id']))
    elif d.get('decision')!='rejected': return jsonify(error='Decision must be accepted/rejected.'),400
    getdb().execute('UPDATE team_join_requests SET status=? WHERE id=?',(d['decision'],rid)); getdb().commit(); return jsonify(ok=True)
@app.get('/api/team-requests')
@login_required
def team_requests():
    return jsonify(requests=[dict(r) for r in getdb().execute('SELECT r.id,r.status,t.name team,p.player_code,u.name player FROM team_join_requests r JOIN teams t ON t.id=r.team_id JOIN players p ON p.id=r.player_id JOIN users u ON u.id=p.user_id WHERE t.captain_id=? AND r.status="pending"',(user()['id'],))])

@app.post('/api/tournaments')
@roles('Administrator','Tournament Organizer')
def create_tournament():
    d=request.get_json(force=True); name=d.get('name','').strip(); fmt=d.get('format','round_robin')
    if not name or fmt not in ('round_robin','knockout','lobby'): return jsonify(error='Name and format round_robin/knockout/lobby required.'),400
    code=secrets.token_urlsafe(8); c=getdb().execute('INSERT INTO tournaments(owner_id,name,description,game,format,game_type,max_teams,invite_code) VALUES(?,?,?,?,?,?,?,?)',(user()['id'],name,d.get('description',''),d.get('game','General'),fmt,d.get('game_type','head_to_head'),int(d.get('max_teams',8)),code)); getdb().commit(); audit('Tournament created'); return jsonify(id=c.lastrowid,invite_code=code),201
@app.get('/api/tournaments')
@login_required
def tournaments(): return jsonify(tournaments=[dict(r) for r in getdb().execute('SELECT * FROM tournaments ORDER BY id DESC')])
@app.get('/api/tournaments/<int:tid>/registrations')
@roles('Administrator','Tournament Organizer')
def tournament_registrations(tid):
    t=getdb().execute('SELECT owner_id FROM tournaments WHERE id=?',(tid,)).fetchone()
    if not t or (t['owner_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    return jsonify(registrations=[dict(r) for r in getdb().execute('SELECT tt.team_id,tt.status,t.name,t.team_code FROM tournament_teams tt JOIN teams t ON t.id=tt.team_id WHERE tt.tournament_id=? ORDER BY t.name',(tid,))])
@app.post('/api/tournaments/<int:tid>/register')
@login_required
def registration(tid):
    d=request.get_json(force=True); team=getdb().execute('SELECT * FROM teams WHERE id=?',(d.get('team_id'),)).fetchone(); t=getdb().execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone()
    if not team or not t: return jsonify(error='Team or tournament not found.'),404
    if not demo_write_allowed(team['captain_id']) or not demo_write_allowed(t['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if team['captain_id']!=user()['id'] and 'Administrator' not in role_list(): return jsonify(error='Only captain can register.'),403
    if team['game']!=t['game']: return jsonify(error='Game mismatch.'),400
    try:
        count=getdb().execute("SELECT count(*) FROM tournament_teams WHERE tournament_id=? AND status='approved'",(tid,)).fetchone()[0]
        if count>=t['max_teams']:
            pos=getdb().execute('SELECT coalesce(max(position),0)+1 FROM tournament_waitlist WHERE tournament_id=?',(tid,)).fetchone()[0]; getdb().execute('INSERT INTO tournament_waitlist(tournament_id,team_id,position) VALUES(?,?,?)',(tid,team['id'],pos)); getdb().commit(); return jsonify(waitlisted=True,position=pos),201
        getdb().execute('INSERT INTO tournament_teams(tournament_id,team_id) VALUES(?,?)',(tid,team['id'])); getdb().commit(); return jsonify(status='pending'),201
    except sqlite3.IntegrityError: return jsonify(error='Already registered.'),409
@app.post('/api/registrations/<int:tid>/<int:teamid>/review')
@roles('Administrator','Tournament Organizer')
def review_registration(tid,teamid):
    d=request.get_json(force=True); t=getdb().execute('SELECT owner_id FROM tournaments WHERE id=?',(tid,)).fetchone()
    if not t or (t['owner_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    if not demo_write_allowed(t['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if d.get('status') not in ('approved','rejected'): return jsonify(error='Invalid status.'),400
    getdb().execute('UPDATE tournament_teams SET status=? WHERE tournament_id=? AND team_id=?',(d['status'],tid,teamid)); getdb().commit(); return jsonify(ok=True)
def round_robin(ids): return [(ids[i],ids[j]) for i in range(len(ids)) for j in range(i+1,len(ids))]
@app.post('/api/tournaments/<int:tid>/schedule')
@roles('Administrator','Tournament Organizer')
def schedule(tid):
    t=getdb().execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone()
    if not t or (t['owner_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    if not demo_write_allowed(t['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if getdb().execute('SELECT 1 FROM matches WHERE tournament_id=? LIMIT 1',(tid,)).fetchone(): return jsonify(error='Schedule already exists. Rescheduling is not available in this demo.'),409
    ids=[r['team_id'] for r in getdb().execute("SELECT team_id FROM tournament_teams WHERE tournament_id=? AND status='approved' ORDER BY team_id",(tid,))]
    pairs=round_robin(ids) if t['format']=='round_robin' else [(ids[i],ids[i+1] if i+1<len(ids) else None) for i in range(0,len(ids),2)]
    if t['game_type']=='battle_royale':
        c=getdb().execute('INSERT INTO matches(tournament_id,lobby) VALUES(?,?)',(tid,','.join(map(str,ids)))); getdb().executemany('INSERT INTO match_participants(match_id,team_id) VALUES(?,?)',[(c.lastrowid,x) for x in ids]); n=1
    else:
        for a,b in pairs: getdb().execute('INSERT INTO matches(tournament_id,team_a_id,team_b_id) VALUES(?,?,?)',(tid,a,b))
        n=len(pairs)
    getdb().commit(); return jsonify(match_count=n,byes=(len(ids)%2 if t['format']=='knockout' else 0))
@app.get('/api/matches')
@login_required
def matches(): return jsonify(matches=[dict(r) for r in getdb().execute('SELECT m.*,t.name tournament,a.name team_a,b.name team_b,(SELECT group_concat(team_id) FROM match_participants mp WHERE mp.match_id=m.id) participant_ids FROM matches m JOIN tournaments t ON t.id=m.tournament_id LEFT JOIN teams a ON a.id=m.team_a_id LEFT JOIN teams b ON b.id=m.team_b_id')])
@app.get('/api/matches/<int:mid>/results')
@login_required
def match_results(mid):
    rows=getdb().execute('SELECT r.*,t.name team FROM match_results r JOIN teams t ON t.id=r.team_id WHERE r.match_id=?',(mid,)).fetchall()
    return jsonify(results=[dict(r) for r in rows])
@app.post('/api/matches/<int:mid>/results')
@login_required
def submit_result(mid):
    m=getdb().execute('SELECT * FROM matches WHERE id=?',(mid,)).fetchone(); d=request.get_json(force=True)
    if not m or not d.get('results'): return jsonify(error='Match and results required.'),400
    owner=getdb().execute('SELECT owner_id FROM tournaments WHERE id=?',(m['tournament_id'],)).fetchone()
    if owner and not demo_write_allowed(owner['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    for x in d['results']:
        team_id=int(x.get('team_id',0))
        is_participant=team_id in (m['team_a_id'],m['team_b_id']) if m['team_a_id'] is not None else bool(getdb().execute('SELECT 1 FROM match_participants WHERE match_id=? AND team_id=?',(mid,team_id)).fetchone())
        captain=getdb().execute('SELECT captain_id FROM teams WHERE id=?',(team_id,)).fetchone()
        if not is_participant or not captain: return jsonify(error='Result team is not a match participant.'),400
        if captain['captain_id']!=user()['id'] and (not owner or owner['owner_id']!=user()['id']) and not set(('Administrator','Scorekeeper')).intersection(role_list()): return jsonify(error='Permission denied.'),403
        score=int(x.get('score',0)); el=int(x.get('eliminations',0)); place=x.get('placement')
        if score<0 or el<0 or (place is not None and int(place)<1): return jsonify(error='Invalid score, eliminations or placement.'),400
        old=getdb().execute('SELECT * FROM match_results WHERE match_id=? AND team_id=?',(mid,x['team_id'])).fetchone()
        if old:
            getdb().execute('INSERT INTO result_revisions(result_id,old_score,new_score,changed_by) VALUES(?,?,?,?)',(old['id'],old['score'],score,user()['id'])); getdb().execute('UPDATE match_results SET score=?,eliminations=?,placement=?,verified=0,submitted_by=? WHERE id=?',(score,el,place,user()['id'],old['id']))
        else: getdb().execute('INSERT INTO match_results(match_id,team_id,score,eliminations,placement,submitted_by) VALUES(?,?,?,?,?,?)',(mid,x['team_id'],score,el,place,user()['id']))
    getdb().execute("UPDATE matches SET status='under_review' WHERE id=?",(mid,)); getdb().commit(); return jsonify(ok=True)
@app.post('/api/matches/<int:mid>/verify')
@roles('Administrator','Tournament Organizer','Scorekeeper')
def verify_result(mid):
    m=getdb().execute('SELECT tournament_id FROM matches WHERE id=?',(mid,)).fetchone()
    if not m:return jsonify(error='Match not found.'),404
    owner=getdb().execute('SELECT owner_id FROM tournaments WHERE id=?',(m['tournament_id'],)).fetchone()
    if owner and not demo_write_allowed(owner['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if 'Administrator' not in role_list() and (not owner or owner['owner_id']!=user()['id']) and 'Scorekeeper' not in role_list():return jsonify(error='Only organizer/admin/scorekeeper can verify.'),403
    getdb().execute('UPDATE match_results SET verified=1 WHERE match_id=?',(mid,)); getdb().execute("UPDATE matches SET status='completed' WHERE id=?",(mid,)); getdb().commit(); return jsonify(ok=True)
@app.post('/api/matches/<int:mid>/checkin')
@roles('Team Captain','Administrator')
def checkin(mid):
    d=request.get_json(force=True); t=getdb().execute('SELECT captain_id FROM teams WHERE id=?',(d.get('team_id'),)).fetchone()
    if not t or (t['captain_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    try: getdb().execute('INSERT INTO match_checkins(match_id,team_id,user_id) VALUES(?,?,?)',(mid,d['team_id'],user()['id'])); getdb().commit(); return jsonify(ok=True),201
    except sqlite3.IntegrityError: return jsonify(error='Already checked in.'),409
@app.post('/api/matches/<int:mid>/disputes')
@login_required
def dispute(mid):
    reason=request.get_json(force=True).get('reason','').strip()
    if not reason: return jsonify(error='Reason required.'),400
    getdb().execute('INSERT INTO result_disputes(match_id,user_id,reason) VALUES(?,?,?)',(mid,user()['id'],reason)); getdb().commit(); return jsonify(ok=True),201
@app.get('/api/tournaments/<int:tid>/leaderboard')
@login_required
def leaderboard(tid):
    t=getdb().execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone()
    if not t: return jsonify(error='Tournament not found.'),404
    totals={}; rs=getdb().execute('SELECT r.*,m.team_a_id,m.team_b_id FROM match_results r JOIN matches m ON m.id=r.match_id WHERE m.tournament_id=? AND r.verified=1',(tid,)).fetchall()
    for r in rs:
        x=totals.setdefault(r['team_id'],dict(team_id=r['team_id'],played=0,wins=0,losses=0,eliminations=0,points=0,score_diff=0)); x['played']+=1; x['eliminations']+=r['eliminations']
        if t['game_type']=='battle_royale': x['points']+=r['score']+r['eliminations']*t['elim_points']
        else:
            opp=r['team_b_id'] if r['team_id']==r['team_a_id'] else r['team_a_id']; other=getdb().execute('SELECT score FROM match_results WHERE match_id=? AND team_id=? AND verified=1',(r['match_id'],opp)).fetchone()
            if other:
                x['score_diff']+=r['score']-other['score']; x['wins']+=r['score']>other['score']; x['losses']+=r['score']<other['score']; x['points']+=t['win_points'] if r['score']>other['score'] else t['draw_points'] if r['score']==other['score'] else t['loss_points']
    for x in totals.values(): x['team']=getdb().execute('SELECT name FROM teams WHERE id=?',(x['team_id'],)).fetchone()['name']
    out=sorted(totals.values(),key=lambda x:(-x['points'],-x['wins'],-x['score_diff'],-x['eliminations'],x['team']))
    for i,x in enumerate(out,1): x['rank']=i
    return jsonify(standings=out)
@app.post('/api/tournaments/<int:tid>/champion')
@roles('Administrator','Tournament Organizer')
def champion(tid):
    lb=leaderboard(tid).get_json().get('standings',[])
    if not lb: return jsonify(error='No verified results; champion cannot be declared.'),409
    t=getdb().execute('SELECT owner_id FROM tournaments WHERE id=?',(tid,)).fetchone()
    if t and not demo_write_allowed(t['owner_id']): return jsonify(error='Demo accounts cannot modify non-demo records.'),403
    if not t or (t['owner_id']!=user()['id'] and 'Administrator' not in role_list()): return jsonify(error='Permission denied.'),403
    getdb().execute("UPDATE tournaments SET champion_id=?,status='Completed' WHERE id=?",(lb[0]['team_id'],tid)); getdb().execute('INSERT OR IGNORE INTO certificates(tournament_id,team_id) VALUES(?,?)',(tid,lb[0]['team_id'])); getdb().commit(); return jsonify(champion=lb[0]['team'])
@app.get('/api/settings')
@login_required
def settings():
    r=getdb().execute('SELECT prefs FROM user_preferences WHERE user_id=?',(user()['id'],)).fetchone(); return jsonify(json.loads(r['prefs']) if r else {'theme':'dark','animations':True,'effects3d':True,'reduced_motion':False,'compact':False,'sidebar_collapsed':False,'transition_style':'morph','timezone':'Asia/Kolkata','date_format':'DD/MM/YYYY'})
@app.post('/api/settings')
@login_required
def save_settings():
    p=request.get_json(force=True)
    if p.get('transition_style','morph') not in ('morph','slide','flip'): return jsonify(error='Transition style must be morph, slide, or flip.'),400
    getdb().execute('INSERT INTO user_preferences(user_id,prefs) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET prefs=excluded.prefs',(user()['id'],json.dumps(p))); getdb().commit(); return jsonify(ok=True)
@app.get('/')
def home():
    year=__import__('datetime').datetime.now().year
    if user(): return render_template('dashboard.html',me=user(),current_year=year)
    demo_enabled=DEMO_LOGIN_ALLOWED and bool(getdb().execute("SELECT 1 FROM users WHERE email='administrator@arena.local' AND is_demo=1").fetchone())
    return render_template('login.html',current_year=year,invite_code=request.args.get('invite',''),demo_enabled=demo_enabled)
@app.get('/assets/<path:filename>')
def assets(filename): return send_from_directory(ROOT/'assets',filename)
@app.get('/help')
def help_page(): return render_template('help.html',me=user() or None,current_year=__import__('datetime').datetime.now().year)
@app.errorhandler(404)
def page_not_found(error):
    if request.path.startswith('/api/'): return jsonify(error='API endpoint not found.'),404
    return render_template('404.html',current_year=__import__('datetime').datetime.now().year),404
PAGE='''<!doctype html><meta name="viewport" content="width=device-width"><title>Arena Manager</title><style>body{margin:0;background:#07101e;color:#edf3ff;font:15px system-ui}.layout{display:grid;grid-template-columns:220px 1fr;min-height:100vh}aside{padding:22px;background:#0b1628;border-right:1px solid #263b56}h1,h2{color:#72c8ff}main{padding:28px}button,input{padding:10px;margin:4px;border-radius:8px;border:1px solid #38516f;background:#0b1729;color:white}button{cursor:pointer}.card{background:#111e32;border:1px solid #263b56;border-radius:14px;padding:18px;margin:10px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}.num{font-size:30px;color:#72c8ff}nav button{display:block;width:100%;text-align:left;background:transparent;border:0;color:#bdcce0}table{width:100%;border-collapse:collapse}td,th{text-align:left;border-bottom:1px solid #263b56;padding:8px}@media(max-width:700px){.layout{grid-template-columns:1fr}nav{display:flex;overflow:auto}nav button{white-space:nowrap}main{padding:14px}}</style><div class=layout><aside><h2>🏆 ARENA</h2><p>{{me.get('name','')}}</p><nav><button onclick="load('dashboard')">Overview</button><button onclick="load('players')">Players</button><button onclick="load('teams')">Teams</button><button onclick="load('tournaments')">Tournaments</button><button onclick="load('matches')">Fixtures and Results</button><button onclick="load('settings')">Settings</button></nav><button onclick="fetch('/api/logout',{method:'POST'}).then(()=>location.reload())">Sign out</button></aside><main><h1 id=title>Arena Manager</h1><section id=view></section></main></div><script>const api=async(p,m='GET',b)=>{let r=await fetch('/api/'+p,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});let d=await r.json();if(!r.ok)throw Error(d.error);return d};function table(a,cols){return '<table><tr>'+cols.map(x=>'<th>'+x+'</th>').join('')+'</tr>'+a.map(o=>'<tr>'+cols.map(x=>'<td>'+(o[x]??'—')+'</td>').join('')+'</tr>').join('')+'</table>'}async function load(n){title.textContent=n;try{let d=await api(n);if(n==='dashboard')view.innerHTML='<div class=grid>'+Object.entries(d.stats).map(([k,v])=>'<div class=card>'+k+'<div class=num>'+v+'</div></div>').join('')+'</div>';if(n==='players')view.innerHTML='<div class=card><input id=q placeholder="Search"><button onclick="search()">Search</button><div id=rows>'+table(d.players,['player_code','name','game'])+'</div></div>';if(n==='teams')view.innerHTML='<div class=card><button onclick="createTeam()">Create team</button>'+table(d.teams,['team_code','name','game','captain','roster_count'])+'</div>';if(n==='tournaments')view.innerHTML='<div class=card><button onclick="createTournament()">Create tournament</button>'+table(d.tournaments,['id','name','game','format','status','invite_code'])+'</div>';if(n==='matches')view.innerHTML='<div class=card>'+table(d.matches,['id','tournament','team_a','team_b','status'])+'</div>';if(n==='settings'){view.innerHTML='<div class=card>'+Object.entries(d).map(([k,v])=>'<label><input type=checkbox id="s_'+k+'" '+(v===true||v==='dark'?'checked':'')+'>'+k+'</label><br>').join('')+'<button onclick="save()">Save preferences</button></div>'}}catch(e){view.innerHTML='<div class=card>'+e.message+'</div>'}}async function search(){let d=await api('players?q='+encodeURIComponent(q.value));rows.innerHTML=table(d.players,['player_code','name','game'])}async function createTeam(){let name=prompt('Team name');if(name){await api('teams','POST',{name,game:prompt('Game','Valorant')});load('teams')}}async function createTournament(){let name=prompt('Tournament name');if(name){let d=await api('tournaments','POST',{name,game:prompt('Game','Valorant'),format:prompt('Format round_robin or knockout','round_robin')});alert('Registration code: '+d.invite_code);load('tournaments')}}async function save(){let p={};for(let k of ['theme','animations','effects3d','reduced_motion','compact','sidebar_collapsed']){let e=document.getElementById('s_'+k);if(e)p[k]=k==='theme'?(e.checked?'dark':'light'):e.checked}await api('settings','POST',p);alert('Saved')}load('dashboard');</script>'''
LOGIN='''<!doctype html><meta name="viewport" content="width=device-width"><title>Arena sign in</title><style>body{background:#07101e;color:white;font:16px system-ui;display:grid;place-items:center;height:100vh}.box{background:#111e32;padding:30px;border-radius:18px;width:320px}input,button{display:block;box-sizing:border-box;width:100%;padding:12px;margin:8px 0;border-radius:8px;background:#0b1729;color:white;border:1px solid #38516f}button{background:#287be4;cursor:pointer}</style><div class=box><h1>ARENA MANAGER</h1><form id=f><input id=email placeholder="Email"><input id=pw type=password placeholder="Password"><button>Sign in</button></form><button id=demo>Demo login</button><p id=msg></p></div><script>f.onsubmit=async e=>{e.preventDefault();let r=await fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:email.value,password:pw.value})});if(r.ok)location.href='/';else msg.textContent=(await r.json()).error};demo.onclick=async()=>{let r=await fetch('/api/demo-login',{method:'POST'});if(r.ok)location.href='/';else msg.textContent=(await r.json()).error}</script>'''
LOGIN=LOGIN.replace('<button id=demo>','<button id=create>Create account</button><button id=demo>').replace('demo.onclick=async()=>',"create.onclick=async()=>{let name=prompt('Name');let email=prompt('Email');let password=prompt('Password (8+ characters)');if(name&&email&&password){let r=await fetch('/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,password})});if(r.ok)location.href='/';else msg.textContent=(await r.json()).error}};demo.onclick=async()=>")
LOGIN=LOGIN.replace("let password=prompt('Password (8+ characters)');if(name", "let password=prompt('Password (8+ characters)');let phone=prompt('Phone (optional)')||'';if(name").replace('JSON.stringify({name,email,password})','JSON.stringify({name,email,password,phone})')
LOGIN=LOGIN.replace('<title>Arena sign in</title>','<title>Sign in · Arena Manager</title><meta name="description" content="Sign in or create an account for the local Arena Manager esports tournament app."><link rel="icon" href="/assets/images/favicon.svg" type="image/svg+xml">').replace('<h1>ARENA MANAGER</h1>','<a href="/" style="color:#72c8ff;text-decoration:none"><h1>ARENA MANAGER</h1></a>')
LOGIN=LOGIN.replace('<style>body{','<style>*{box-sizing:border-box}body{').replace('height:100vh','min-height:100svh;height:auto;overflow-x:hidden;padding:16px').replace('width:320px','width:min(380px,100%)')
LOGIN=LOGIN.replace('f.onsubmit=async', """function go(){const code=new URLSearchParams(location.search).get('invite');location.href=code?'/invite/'+encodeURIComponent(code):'/'};f.onsubmit=async""").replace("location.href='/'",'go()')
LOGIN=LOGIN.replace('<p id=msg></p></div>','<p id=msg role="status" aria-live="polite"></p><footer>© <span id="year"></span> Arena Manager · <a href="/help">Demo help</a></footer></div>').replace('</script>',"document.querySelector('#year').textContent=new Date().getFullYear();</script>")
if __name__=='__main__': init_db(); app.run(host='127.0.0.1',port=int(os.environ.get('PORT',5000)),debug=False)
elif IS_VERCEL:
    # Vercel's writable filesystem is temporary. Keep its demo database isolated
    # from the local SQLite file and initialize it for each fresh function instance.
    init_db()
    if os.environ.get('ARENA_DEMO_ENABLED','').lower() in ('1','true','yes'):
        from seed_demo import seed_demo
        seed_demo()
